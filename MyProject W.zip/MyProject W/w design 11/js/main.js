/* ============================================================
   ULTRA-PREMIUM CINEMATIC INDIAN WEDDING INVITATION
   Royal Slideshow Experience — main.js
   ============================================================ */

(function () {
    'use strict';

    /* ============================
       SLIDE THEME CONFIG
       ============================ */
    const SLIDE_THEMES = {
        welcome:   { label: 'Welcome',     particles: ['#FFD700','#FFA500','#FF1493','#C0C0C0'], bgParticleCount: 60 },
        haldi:     { label: 'Haldi',        particles: ['#FFD700','#FFA500','#FFE566','#FF8C00'], bgParticleCount: 50 },
        mehendi:   { label: 'Mehendi',      particles: ['#556B2F','#8FBC3F','#2E8B57','#ADFF2F'], bgParticleCount: 45 },
        sangeet:   { label: 'Sangeet',      particles: ['#FF1493','#9B59B6','#FF69B4','#6A0DAD','#FFD700'], bgParticleCount: 55 },
        wedding:   { label: 'Wedding',      particles: ['#DC143C','#FFD700','#FF4500','#8B0000'], bgParticleCount: 50 },
        reception: { label: 'Reception',    particles: ['#1E3A8A','#C0C0C0','#3B82F6','#E8E8E8'], bgParticleCount: 45 },
        lovestory: { label: 'Love Story',   particles: ['#FFD700','#FF69B4','#C0C0C0'], bgParticleCount: 30 },
        gallery:   { label: 'Gallery',      particles: ['#9B59B6','#FFD700','#FF69B4'], bgParticleCount: 25 },
        rsvp:      { label: 'RSVP',         particles: ['#DC143C','#FFD700','#FF69B4'], bgParticleCount: 25 }
    };

    /* ============================
       DOM REFERENCES
       ============================ */
    const canvas = document.getElementById('cinematic-canvas');
    const ctx = canvas.getContext('2d');
    const preloader = document.getElementById('preloader');
    const navDotsContainer = document.getElementById('navDots');
    const navDots = navDotsContainer.querySelectorAll('.nav-dot');
    const slideLabel = document.getElementById('slideLabel');
    const musicBtn = document.getElementById('music-toggle');
    const bgMusic = document.getElementById('bg-music');
    const rsvpModal = document.getElementById('rsvpModal');
    const rsvpModalClose = document.getElementById('rsvpModalClose');
    const rsvpEventName = document.getElementById('rsvpEventName');
    const successPopup = document.getElementById('successPopup');

    let currentTheme = 'welcome';
    let particlePool = [];

    /* ============================
       CANVAS RESIZE
       ============================ */
    function resizeCanvas() {
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
    }
    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);

    /* ============================
       PARTICLE SYSTEM
       ============================ */
    class Particle {
        constructor() {
            this.reset();
        }

        reset() {
            const theme = SLIDE_THEMES[currentTheme];
            const colors = theme ? theme.particles : ['#FFD700'];
            this.x = Math.random() * canvas.width;
            this.y = Math.random() * canvas.height;
            this.size = Math.random() * 2.5 + 0.5;
            this.speedX = (Math.random() - 0.5) * 0.5;
            this.speedY = (Math.random() - 0.5) * 0.5 - 0.2;
            this.color = colors[Math.floor(Math.random() * colors.length)];
            this.opacity = Math.random() * 0.6 + 0.2;
            this.life = Math.random() * 200 + 100;
            this.maxLife = this.life;
            this.twinkleSpeed = Math.random() * 0.02 + 0.005;
            this.twinklePhase = Math.random() * Math.PI * 2;
            this.type = Math.random() > 0.85 ? 'butterfly' : (Math.random() > 0.7 ? 'sparkle' : 'dot');
            if (this.type === 'butterfly') {
                this.wingPhase = Math.random() * Math.PI * 2;
                this.size = Math.random() * 3 + 2;
                this.speedY = -Math.abs(this.speedY) - 0.1;
            }
        }

        update() {
            this.x += this.speedX;
            this.y += this.speedY;
            this.life--;
            this.twinklePhase += this.twinkleSpeed;
            if (this.type === 'butterfly') {
                this.wingPhase += 0.08;
                this.x += Math.sin(this.wingPhase) * 0.8;
            }
            if (this.life <= 0 || this.x < -20 || this.x > canvas.width + 20 || this.y < -20 || this.y > canvas.height + 20) {
                this.reset();
            }
        }

        draw() {
            const twinkle = Math.sin(this.twinklePhase) * 0.3 + 0.7;
            const lifeRatio = this.life / this.maxLife;
            const alpha = this.opacity * twinkle * (lifeRatio > 0.8 ? 1 : lifeRatio / 0.8);
            ctx.save();
            ctx.globalAlpha = alpha;

            if (this.type === 'butterfly') {
                this.drawButterfly();
            } else if (this.type === 'sparkle') {
                this.drawSparkle();
            } else {
                this.drawDot();
            }

            ctx.restore();
        }

        drawDot() {
            ctx.beginPath();
            ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
            ctx.fillStyle = this.color;
            ctx.fill();
            // Glow
            ctx.beginPath();
            ctx.arc(this.x, this.y, this.size * 3, 0, Math.PI * 2);
            const grad = ctx.createRadialGradient(this.x, this.y, 0, this.x, this.y, this.size * 3);
            grad.addColorStop(0, this.color);
            grad.addColorStop(1, 'transparent');
            ctx.fillStyle = grad;
            ctx.globalAlpha *= 0.3;
            ctx.fill();
        }

        drawSparkle() {
            ctx.translate(this.x, this.y);
            ctx.rotate(this.twinklePhase);
            ctx.strokeStyle = this.color;
            ctx.lineWidth = 0.8;
            const s = this.size * 2;
            ctx.beginPath();
            ctx.moveTo(0, -s); ctx.lineTo(0, s);
            ctx.moveTo(-s, 0); ctx.lineTo(s, 0);
            ctx.moveTo(-s * 0.7, -s * 0.7); ctx.lineTo(s * 0.7, s * 0.7);
            ctx.moveTo(s * 0.7, -s * 0.7); ctx.lineTo(-s * 0.7, s * 0.7);
            ctx.stroke();
        }

        drawButterfly() {
            ctx.translate(this.x, this.y);
            const wing = Math.sin(this.wingPhase) * 0.5;
            ctx.scale(1, 1);
            ctx.fillStyle = this.color;
            // Left wing
            ctx.beginPath();
            ctx.ellipse(-this.size * wing, 0, this.size, this.size * 1.5, -0.3, 0, Math.PI * 2);
            ctx.globalAlpha *= 0.5;
            ctx.fill();
            // Right wing
            ctx.beginPath();
            ctx.ellipse(this.size * wing, 0, this.size, this.size * 1.5, 0.3, 0, Math.PI * 2);
            ctx.fill();
        }
    }

    /* Initialize Particles */
    function initParticles() {
        const count = SLIDE_THEMES[currentTheme]?.bgParticleCount || 40;
        // Resize pool
        while (particlePool.length < count) {
            particlePool.push(new Particle());
        }
        if (particlePool.length > count) {
            particlePool.length = count;
        }
    }

    /* Animate Canvas */
    function animateCanvas() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        particlePool.forEach(p => {
            p.update();
            p.draw();
        });
        requestAnimationFrame(animateCanvas);
    }

    initParticles();
    animateCanvas();

    /* ============================
       PRELOADER
       ============================ */
    function hidePreloader() {
        return new Promise(resolve => {
            setTimeout(() => {
                preloader.classList.add('hidden');
                setTimeout(resolve, 800);
            }, 2800);
        });
    }

    /* ============================
       SWIPER INITIALIZATION
       ============================ */
    let mainSwiper;

    function initSwiper() {
        mainSwiper = new Swiper('#mainSwiper', {
            direction: 'vertical',
            speed: 1200,
            mousewheel: {
                sensitivity: 1,
                releaseOnEdges: false
            },
            keyboard: {
                enabled: true
            },
            effect: 'creative',
            creativeEffect: {
                prev: {
                    translate: [0, '-30%', -200],
                    opacity: 0,
                    scale: 0.9
                },
                next: {
                    translate: [0, '100%', 0],
                    opacity: 0.8
                }
            },
            navigation: {
                nextEl: '.swiper-button-next',
                prevEl: '.swiper-button-prev',
            },
            on: {
                slideChange: onSlideChange,
                init: onSlideChange
            }
        });
    }

    /* ============================
       SLIDE CHANGE HANDLER
       ============================ */
    function onSlideChange() {
        const idx = mainSwiper ? mainSwiper.activeIndex : 0;
        const slide = document.querySelectorAll('.swiper-slide')[idx];
        const theme = slide?.dataset.theme || 'welcome';
        currentTheme = theme;

        // Update nav dots
        navDots.forEach((dot, i) => {
            dot.classList.toggle('active', i === idx);
        });

        // Update label
        const config = SLIDE_THEMES[theme];
        if (config) {
            slideLabel.textContent = config.label;
        }

        // Reinit particles for new theme
        initParticles();
        particlePool.forEach(p => p.reset());

        // Animate card entrance with GSAP
        const card = slide?.querySelector('.event-card');
        if (card && typeof gsap !== 'undefined') {
            gsap.fromTo(card,
                { opacity: 0, y: 60, scale: 0.92, rotateX: 8 },
                { opacity: 1, y: 0, scale: 1, rotateX: 0, duration: 1.2, ease: 'power3.out', delay: 0.3 }
            );
        }

        // Animate welcome content
        if (theme === 'welcome' && typeof gsap !== 'undefined') {
            const items = slide.querySelectorAll('[data-aos]');
            items.forEach((el, i) => {
                gsap.fromTo(el,
                    { opacity: 0, y: 30 },
                    { opacity: 1, y: 0, duration: 0.8, delay: 0.2 + i * 0.15, ease: 'power2.out' }
                );
            });
        }

        // Refresh AOS for scrollable slides
        if (typeof AOS !== 'undefined') {
            setTimeout(() => AOS.refresh(), 500);
        }
    }

    /* ============================
       NAV DOTS CLICK
       ============================ */
    navDots.forEach(dot => {
        dot.addEventListener('click', () => {
            const slideIdx = parseInt(dot.dataset.slide);
            if (mainSwiper) mainSwiper.slideTo(slideIdx);
        });
    });

    /* ============================
       EXPLORE BUTTON
       ============================ */
    document.querySelector('.explore-btn')?.addEventListener('click', () => {
        if (mainSwiper) mainSwiper.slideNext();
    });

    /* ============================
       COUNTDOWN TIMER
       ============================ */
    const WEDDING_DATE = new Date('February 15, 2027 11:30:00').getTime();

    function updateCountdown() {
        const now = Date.now();
        const diff = WEDDING_DATE - now;

        if (diff <= 0) {
            document.getElementById('cDays').textContent = '0';
            document.getElementById('cHours').textContent = '00';
            document.getElementById('cMins').textContent = '00';
            document.getElementById('cSecs').textContent = '00';
            return;
        }

        const days = Math.floor(diff / (1000 * 60 * 60 * 24));
        const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        const mins = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
        const secs = Math.floor((diff % (1000 * 60)) / 1000);

        document.getElementById('cDays').textContent = String(days).padStart(3, '0');
        document.getElementById('cHours').textContent = String(hours).padStart(2, '0');
        document.getElementById('cMins').textContent = String(mins).padStart(2, '0');
        document.getElementById('cSecs').textContent = String(secs).padStart(2, '0');
    }

    updateCountdown();
    setInterval(updateCountdown, 1000);

    /* ============================
       MUSIC CONTROLLER
       ============================ */
    let musicPlaying = false;

    musicBtn.addEventListener('click', () => {
        if (musicPlaying) {
            bgMusic.pause();
            musicBtn.classList.remove('playing');
        } else {
            bgMusic.play().catch(() => {});
            musicBtn.classList.add('playing');
        }
        musicPlaying = !musicPlaying;
    });

    /* ============================
       RSVP MODAL (Per-Event)
       ============================ */
    document.querySelectorAll('.btn-rsvp-trigger').forEach(btn => {
        btn.addEventListener('click', () => {
            const eventName = btn.dataset.event || 'Event';
            rsvpEventName.textContent = eventName;
            rsvpModal.classList.add('active');
        });
    });

    rsvpModalClose.addEventListener('click', () => {
        rsvpModal.classList.remove('active');
    });

    document.querySelector('.rsvp-modal-overlay')?.addEventListener('click', () => {
        rsvpModal.classList.remove('active');
    });

    // Modal Form Submit
    document.getElementById('rsvpModalForm')?.addEventListener('submit', (e) => {
        e.preventDefault();
        rsvpModal.classList.remove('active');
        showSuccess();
    });

    /* ============================
       MAIN RSVP FORM (Slide 8)
       ============================ */
    document.getElementById('rsvpForm')?.addEventListener('submit', (e) => {
        e.preventDefault();
        showSuccess();
        e.target.reset();
    });

    function showSuccess() {
        successPopup.classList.add('active');
        // Burst particles
        burstCelebration();
        setTimeout(() => {
            successPopup.classList.remove('active');
        }, 3500);
    }

    /* ============================
       CELEBRATION BURST
       ============================ */
    function burstCelebration() {
        const burstColors = ['#FFD700', '#FF1493', '#DC143C', '#C0C0C0', '#FF9933', '#9B59B6'];
        for (let i = 0; i < 50; i++) {
            const p = new Particle();
            p.x = canvas.width / 2 + (Math.random() - 0.5) * 100;
            p.y = canvas.height / 2;
            p.speedX = (Math.random() - 0.5) * 6;
            p.speedY = (Math.random() - 0.5) * 6 - 2;
            p.color = burstColors[Math.floor(Math.random() * burstColors.length)];
            p.life = Math.random() * 80 + 40;
            p.maxLife = p.life;
            p.size = Math.random() * 3 + 1;
            p.type = 'sparkle';
            particlePool.push(p);
        }
        // Clean up extra particles after burst fades
        setTimeout(() => {
            const target = SLIDE_THEMES[currentTheme]?.bgParticleCount || 40;
            if (particlePool.length > target + 10) {
                particlePool.length = target;
            }
        }, 4000);
    }

    /* ============================
       MOUSE PARALLAX (Desktop)
       ============================ */
    let mouseX = 0, mouseY = 0;
    const isMobile = /Android|iPhone|iPad|iPod/i.test(navigator.userAgent);

    if (!isMobile) {
        document.addEventListener('mousemove', (e) => {
            mouseX = (e.clientX / window.innerWidth - 0.5) * 2;
            mouseY = (e.clientY / window.innerHeight - 0.5) * 2;
        });

        function applyParallax() {
            const activeSlide = document.querySelector('.swiper-slide-active');
            if (!activeSlide) return;

            const bg = activeSlide.querySelector('.slide-bg');
            const content = activeSlide.querySelector('.slide-content');

            if (bg) {
                bg.style.transform = `translate(${mouseX * -8}px, ${mouseY * -8}px) scale(1.02)`;
            }
            if (content) {
                content.style.transform = `translate(${mouseX * 3}px, ${mouseY * 3}px)`;
            }

            requestAnimationFrame(applyParallax);
        }
        applyParallax();
    }

    /* ============================
       SPARKLE CURSOR TRAIL
       ============================ */
    if (!isMobile) {
        document.addEventListener('mousemove', (e) => {
            if (Math.random() > 0.7) {
                const p = new Particle();
                p.x = e.clientX;
                p.y = e.clientY;
                p.size = Math.random() * 2 + 0.5;
                p.speedX = (Math.random() - 0.5) * 1.5;
                p.speedY = Math.random() * -1.5 - 0.5;
                p.life = Math.random() * 30 + 15;
                p.maxLife = p.life;
                p.type = 'sparkle';
                p.opacity = 0.8;
                particlePool.push(p);

                // Clean up excess
                const max = (SLIDE_THEMES[currentTheme]?.bgParticleCount || 40) + 30;
                if (particlePool.length > max) {
                    particlePool.splice(0, particlePool.length - max);
                }
            }
        });
    }

    /* ============================
       FLOATING HEARTS (Continuous)
       ============================ */
    function spawnFloatingHeart() {
        if (currentTheme === 'welcome' || currentTheme === 'wedding' || currentTheme === 'lovestory') {
            const p = new Particle();
            p.x = Math.random() * canvas.width;
            p.y = canvas.height + 10;
            p.speedX = (Math.random() - 0.5) * 0.4;
            p.speedY = -(Math.random() * 0.8 + 0.3);
            p.color = ['#FF1493', '#FFD700', '#DC143C'][Math.floor(Math.random() * 3)];
            p.size = Math.random() * 2 + 1;
            p.life = 300;
            p.maxLife = 300;
            p.type = 'dot';
            p.opacity = 0.4;
            particlePool.push(p);
        }
    }
    setInterval(spawnFloatingHeart, 2000);

    /* ============================
       KEYBOARD NAVIGATION
       ============================ */
    document.addEventListener('keydown', (e) => {
        if (!mainSwiper) return;
        if (e.key === 'ArrowDown' || e.key === 'ArrowRight') mainSwiper.slideNext();
        if (e.key === 'ArrowUp' || e.key === 'ArrowLeft') mainSwiper.slidePrev();
    });

    /* ============================
       AUTO-PLAY SLIDESHOW (Optional)
       ============================ */
    let autoPlayInterval = null;
    let autoPlayActive = false;

    function toggleAutoPlay() {
        if (autoPlayActive) {
            clearInterval(autoPlayInterval);
            autoPlayActive = false;
        } else {
            autoPlayInterval = setInterval(() => {
                if (mainSwiper) {
                    if (mainSwiper.activeIndex >= mainSwiper.slides.length - 1) {
                        mainSwiper.slideTo(0);
                    } else {
                        mainSwiper.slideNext();
                    }
                }
            }, 6000);
            autoPlayActive = true;
        }
    }

    /* Double-tap to toggle autoplay on mobile */
    let lastTap = 0;
    document.addEventListener('touchend', (e) => {
        const now = Date.now();
        if (now - lastTap < 300) {
            toggleAutoPlay();
        }
        lastTap = now;
    });

    /* ============================
       GSAP TIMELINE FOR WELCOME
       ============================ */
    function animateWelcomeScene() {
        if (typeof gsap === 'undefined') return;

        const tl = gsap.timeline({ defaults: { ease: 'power2.out' } });

        tl.fromTo('.monogram-emblem', { opacity: 0, scale: 0.5 }, { opacity: 1, scale: 1, duration: 1.2 })
          .fromTo('.welcome-title .title-line', { opacity: 0, y: 40 }, { opacity: 1, y: 0, duration: 0.8, stagger: 0.2 }, '-=0.5')
          .fromTo('.title-weds', { opacity: 0, scale: 0 }, { opacity: 1, scale: 1, duration: 0.6 }, '-=0.3')
          .fromTo('.welcome-subtitle', { opacity: 0, y: 20 }, { opacity: 0.8, y: 0, duration: 0.7 }, '-=0.2')
          .fromTo('.welcome-date', { opacity: 0, y: 20 }, { opacity: 1, y: 0, duration: 0.7 }, '-=0.3')
          .fromTo('.countdown-timer', { opacity: 0, y: 20 }, { opacity: 1, y: 0, duration: 0.6 }, '-=0.2')
          .fromTo('.explore-btn', { opacity: 0, y: 20 }, { opacity: 1, y: 0, duration: 0.6 }, '-=0.2')
          .fromTo('.ornament-top, .ornament-bottom', { opacity: 0, scaleX: 0 }, { opacity: 0.4, scaleX: 1, duration: 0.8, stagger: 0.1 }, '-=0.8');
    }

    /* ============================
       INIT EVERYTHING
       ============================ */
    async function init() {
        // Wait for preloader
        await hidePreloader();

        // Init AOS
        if (typeof AOS !== 'undefined') {
            AOS.init({
                once: false,
                duration: 800,
                easing: 'ease-out-cubic',
                offset: 50
            });
        }

        // Init Swiper
        initSwiper();

        // Animate welcome scene
        animateWelcomeScene();
    }

    // Start when DOM ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

})();
