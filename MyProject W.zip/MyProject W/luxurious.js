/* ═══════════════════════════════════════════
   LUXURIOUS THEME — JavaScript
   Orchestral strings music, gold particles, shimmer
   ═══════════════════════════════════════════ */
(function(){
  'use strict';

  // ── GOLD DUST PARTICLES ──
  var dustEl = document.getElementById('goldDust');
  for(var i=0;i<30;i++){
    var p = document.createElement('div');
    p.className='gold-particle';
    var sz = 1+Math.random()*3;
    p.style.width=sz+'px';p.style.height=sz+'px';
    p.style.left=Math.random()*100+'%';
    p.style.bottom='-5px';
    p.style.background='#d4af37';
    p.style.boxShadow='0 0 '+(3+Math.random()*6)+'px rgba(212,175,55,'+(0.3+Math.random()*0.4)+')';
    p.style.animationDuration=(10+Math.random()*18)+'s';
    p.style.animationDelay=(Math.random()*15)+'s';
    dustEl.appendChild(p);
  }

  // ── SPARKLE BURST ──
  function sparkBurst(cx,cy,n){
    var cols=['#d4af37','#f5e6a3','#b8860b','#fffff0','#ffd700'];
    for(var i=0;i<(n||25);i++){
      var s=document.createElement('div');s.className='spark';
      s.style.left=cx+'px';s.style.top=cy+'px';
      var sz=2+Math.random()*4;s.style.width=sz+'px';s.style.height=sz+'px';
      var c=cols[Math.floor(Math.random()*cols.length)];
      s.style.background=c;s.style.boxShadow='0 0 8px '+c;
      document.body.appendChild(s);
      var a=Math.random()*Math.PI*2,d=40+Math.random()*150;
      gsap.to(s,{x:Math.cos(a)*d,y:Math.sin(a)*d,opacity:0,duration:.8+Math.random(),ease:'power2.out',onComplete:function(){if(s.parentNode)s.remove()}});
    }
  }

  // ── SPLASH ANIMATION ──
  gsap.from('.sp-crown',{opacity:0,scale:0,y:-30,duration:1,delay:.3,ease:'back.out(1.5)'});
  gsap.from('.sp-ornament',{scaleX:0,duration:.6,delay:.7});
  gsap.from('.sp-for',{opacity:0,y:10,duration:.5,delay:.9});
  gsap.from('.sp-name',{opacity:0,y:18,duration:.7,delay:1.1});
  gsap.from('.sp-sub',{opacity:0,y:8,duration:.4,delay:1.4});
  gsap.from('.sp-btn',{opacity:0,y:15,duration:.5,delay:1.7});

  // ── OPEN BUTTON ──
  document.getElementById('openBtn').addEventListener('click',function(){
    var splash=document.getElementById('splash'),main=document.getElementById('main');
    var cx=window.innerWidth/2,cy=window.innerHeight/2;
    var tl=gsap.timeline({onComplete:function(){splash.style.display='none';document.body.style.overflow='';initSR()}});
    tl.to('.sp-crown',{scale:4,opacity:0,y:-50,duration:.5});
    tl.add(function(){sparkBurst(cx,cy,70)},'-=.3');
    tl.to('#splash > *:not(.sp-crown)',{opacity:0,y:-10,duration:.3,stagger:.03},'-=.3');
    tl.to(splash,{opacity:0,duration:.4});
    tl.add(function(){main.classList.remove('hide')});
    tl.from(main,{opacity:0,duration:.5,ease:'power2.out'});
    tl.from('.hero-hex-wrap',{opacity:0,scale:0,rotation:30,duration:.7,ease:'back.out(2)'},'-=.2');
    tl.from('.hero-wish',{opacity:0,y:15,duration:.5},'-=.2');
    tl.from('.hero-name',{opacity:0,y:10,duration:.4},'-=.15');
    tl.from('.hero-msg',{opacity:0,y:10,duration:.4},'-=.15');
  });

  // ── SCROLL ANIMATIONS ──
  function initSR(){
    gsap.registerPlugin(ScrollTrigger);
    document.querySelectorAll('.sec-title').forEach(function(t){
      gsap.from(t,{scrollTrigger:{trigger:t,start:'top 85%'},opacity:0,y:25,duration:.7});
    });
    gsap.from('.tribute',{scrollTrigger:{trigger:'.tribute',start:'top 80%'},opacity:0,y:35,duration:.8});
    document.querySelectorAll('.hex-item').forEach(function(h,i){
      gsap.from(h,{scrollTrigger:{trigger:h,start:'top 85%'},opacity:0,scale:.5,rotation:15,duration:.5,delay:i*.08,ease:'back.out(1.3)'});
    });
    document.querySelectorAll('.achieve-card').forEach(function(a,i){
      gsap.from(a,{scrollTrigger:{trigger:a,start:'top 85%'},opacity:0,y:30,scale:.85,duration:.5,delay:i*.07,ease:'back.out(1.2)'});
    });
    gsap.from('.lux-quote',{scrollTrigger:{trigger:'.lux-quote',start:'top 82%'},opacity:0,y:25,duration:.7});
    gsap.from('.close-crown',{scrollTrigger:{trigger:'.close-crown',start:'top 85%'},opacity:0,scale:0,duration:.8,ease:'back.out(1.7)'});
  }

  // ── 3D TILT ──
  document.querySelectorAll('.hex-item,.achieve-card,.tribute,.hero-hex-wrap').forEach(function(el){
    el.addEventListener('mousemove',function(e){
      var r=el.getBoundingClientRect();
      var ry=((e.clientX-r.left-r.width/2)/(r.width/2))*8;
      var rx=((r.height/2-(e.clientY-r.top))/(r.height/2))*6;
      el.style.transform='perspective(800px) rotateY('+ry+'deg) rotateX('+rx+'deg) translateZ(10px) scale(1.03)';
      el.style.transition='transform .1s ease';
    });
    el.addEventListener('mouseleave',function(){el.style.transition='transform .5s ease';el.style.transform=''});
  });

  document.addEventListener('click',function(e){
    if(e.target.closest('.hex-item,.achieve-card,.hero-hex-wrap'))sparkBurst(e.clientX,e.clientY,15);
  });

  // ── ORCHESTRAL STRINGS MUSIC (Web Audio) ──
  var audioCtx=null, musicPlaying=false, musicInterval=null;

  function playStrings(){
    if(!audioCtx) audioCtx=new(window.AudioContext||window.webkitAudioContext)();
    // Majestic chord progression: Cm - Ab - Eb - Bb
    var chords=[
      [261.63,311.13,392],     // C minor
      [220,261.63,329.63],     // Ab major
      [311.13,392,493.88],     // Eb major
      [233.08,293.66,349.23],  // Bb major
      [261.63,329.63,392],     // C major resolve
    ];
    var t=audioCtx.currentTime+.1;
    chords.forEach(function(chord,ci){
      chord.forEach(function(f){
        var osc=audioCtx.createOscillator(),gain=audioCtx.createGain();
        osc.type='sawtooth';
        osc.frequency.setValueAtTime(f,t);
        // Low pass for warmth
        var filter=audioCtx.createBiquadFilter();
        filter.type='lowpass';filter.frequency.setValueAtTime(800,t);
        gain.gain.setValueAtTime(0,t);
        gain.gain.linearRampToValueAtTime(.025,t+.3);
        gain.gain.linearRampToValueAtTime(.02,t+1.5);
        gain.gain.exponentialRampToValueAtTime(.001,t+2.5);
        osc.connect(filter);filter.connect(gain);gain.connect(audioCtx.destination);
        osc.start(t);osc.stop(t+2.5);
      });
      t+=2.2;
    });
    return t-audioCtx.currentTime;
  }

  function toggleMusic(){
    if(musicPlaying){
      musicPlaying=false;if(musicInterval)clearInterval(musicInterval);
      document.getElementById('musicBtn').innerHTML='<i class="fa-solid fa-volume-xmark"></i>';
    }else{
      musicPlaying=true;
      var dur=playStrings();
      musicInterval=setInterval(function(){if(musicPlaying)playStrings()},dur*1000);
      document.getElementById('musicBtn').innerHTML='<i class="fa-solid fa-music"></i>';
    }
  }
  document.getElementById('musicBtn').addEventListener('click',toggleMusic);

  document.body.style.overflow='hidden';
})();
