/* ============================================================
   "CELESTIAL LUXE" — The Most Luxurious Wedding Invitation
   Bright · Colorful · Joyful · 3D · Eye-Stopping
   Fireworks · Confetti · Holographic · Glass · Neon Glow
   ============================================================ */
(function () {
  'use strict';

  /* ==========================================================
     CONFIG
     ========================================================== */
  var W = {
    bride: 'Ishita',
    groom: 'Kabir',
    brideFull: 'Maharani Ishita',
    groomFull: 'Maharaj Kabir',
    brideFamily: 'Sharma',
    groomFamily: 'Kapoor',
    brideFather: 'Shri Rajendra & Smt. Kavita Sharma',
    groomFather: 'Shri Vikram & Smt. Meera Kapoor',
    date: 'December 20, 2026',
    day: 'Saturday',
    time: '11:00 AM',
    venue: 'The Royal Palace, Jaipur',
    hashtag: '#IshitaWedsKabir',
    events: [
      { name:'Haldi', icon:'🌼', date:'Dec 18, 2026', time:'10:00 AM', place:'Sharma Haveli', desc:'Sacred turmeric blessings for radiance.', grad:'linear-gradient(135deg,#f59e0b,#fbbf24,#fcd34d)', bg:'#fffbeb' },
      { name:'Mehendi', icon:'✋', date:'Dec 18, 2026', time:'5:00 PM', place:"Queen's Garden", desc:'Intricate henna artistry under the stars.', grad:'linear-gradient(135deg,#10b981,#34d399,#6ee7b7)', bg:'#ecfdf5' },
      { name:'Sangeet', icon:'🎶', date:'Dec 19, 2026', time:'7:00 PM', place:'Grand Durbar Hall', desc:'Music, dance and magical celebration.', grad:'linear-gradient(135deg,#8b5cf6,#a78bfa,#c4b5fd)', bg:'#f5f3ff' },
      { name:'Wedding', icon:'💍', date:'Dec 20, 2026', time:'9 AM Baraat · 11 AM Pheras', place:'Royal Lakshmi Temple', desc:'The sacred union of two souls forever.', grad:'linear-gradient(135deg,#ef4444,#f87171,#fca5a5)', bg:'#fef2f2' },
      { name:'Reception', icon:'🥂', date:'Dec 20, 2026', time:'7:00 PM', place:'Palace Ballroom', desc:'A grand evening honoring the newlyweds.', grad:'linear-gradient(135deg,#3b82f6,#60a5fa,#93c5fd)', bg:'#eff6ff' }
    ]
  };

  /* ==========================================================
     FONTS
     ========================================================== */
  function loadFonts() {
    ['https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,700;0,900;1,400&family=Dancing+Script:wght@400;700&family=Cormorant+Garamond:ital,wght@0,300;0,400;0,600;1,300;1,400&family=Cinzel+Decorative:wght@400;700;900&family=Great+Vibes&family=EB+Garamond:ital,wght@0,400;0,600;1,400&family=Noto+Sans+Devanagari:wght@400;600&family=Poppins:wght@300;400;600;700&display=swap',
     'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css'
    ].forEach(function(u){var l=document.createElement('link');l.rel='stylesheet';l.href=u;document.head.appendChild(l)});
  }

  /* ==========================================================
     MEGA CSS — Bright, Colorful, 3D, Luxurious
     ========================================================== */
  function injectCSS() {
    var css = document.createElement('style');
    css.textContent = `
/* === RESET === */
*,*::before,*::after{margin:0;padding:0;box-sizing:border-box}
html{scroll-behavior:smooth}
body{
  font-family:'Poppins','EB Garamond',serif;
  background:#0a0a1a;color:#fff;
  overflow-x:hidden;min-height:100vh;
  perspective:1200px;
}
.lx-hide{display:none!important}

/* === ANIMATED RAINBOW BG === */
.lx-rainbow-bg{
  position:fixed;inset:0;z-index:0;
  background:linear-gradient(-45deg,#0a0a1a,#1a0530,#0d1b3e,#0a1628,#1a0a2e,#0a0a1a);
  background-size:600% 600%;
  animation:lxRainbowBg 20s ease infinite;
}
@keyframes lxRainbowBg{
  0%{background-position:0% 50%}25%{background-position:100% 0%}50%{background-position:100% 100%}75%{background-position:0% 100%}100%{background-position:0% 50%}
}

/* === FLOATING ELEMENTS CONTAINERS === */
#lx-particles,#lx-petals,#lx-hearts,#lx-stars{
  position:fixed;inset:0;pointer-events:none;overflow:hidden;
}
#lx-particles{z-index:1}
#lx-petals{z-index:2}
#lx-hearts{z-index:2}
#lx-stars{z-index:2}

/* === PARTICLES — MULTI-COLOR === */
.lx-ptcl{
  position:absolute;border-radius:50%;
  pointer-events:none;opacity:0;
  animation:lxPtclFloat linear infinite;
}
.lx-ptcl.c-gold{background:#ffd700;box-shadow:0 0 12px #ffd700,0 0 30px rgba(255,215,0,.4)}
.lx-ptcl.c-rose{background:#ff6b9d;box-shadow:0 0 12px #ff6b9d,0 0 30px rgba(255,107,157,.4)}
.lx-ptcl.c-cyan{background:#00e5ff;box-shadow:0 0 12px #00e5ff,0 0 30px rgba(0,229,255,.4)}
.lx-ptcl.c-lime{background:#76ff03;box-shadow:0 0 12px #76ff03,0 0 30px rgba(118,255,3,.4)}
.lx-ptcl.c-violet{background:#d500f9;box-shadow:0 0 12px #d500f9,0 0 30px rgba(213,0,249,.4)}
.lx-ptcl.c-orange{background:#ff9100;box-shadow:0 0 12px #ff9100,0 0 30px rgba(255,145,0,.4)}
@keyframes lxPtclFloat{
  0%{transform:translateY(0) translateX(0) scale(1);opacity:0}
  5%{opacity:.85}
  50%{transform:translateY(-55vh) translateX(40px) scale(.5);opacity:.5}
  100%{transform:translateY(-115vh) translateX(-30px) scale(.1);opacity:0}
}

/* === FLOATING PETALS === */
.lx-petal{
  position:absolute;width:20px;height:20px;
  pointer-events:none;opacity:0;
  animation:lxPetalDrift linear infinite;
}
.lx-petal::before{
  content:'';display:block;width:100%;height:100%;
  border-radius:60% 0 60% 0;transform:rotate(45deg);
}
.lx-petal.pt-hot::before{background:linear-gradient(135deg,#ff1744,#ff6d00)}
.lx-petal.pt-pink::before{background:linear-gradient(135deg,#e91e9c,#ff6090)}
.lx-petal.pt-gold::before{background:linear-gradient(135deg,#ffd700,#ffab00)}
.lx-petal.pt-cyan::before{background:linear-gradient(135deg,#00e5ff,#18ffff)}
.lx-petal.pt-lime::before{background:linear-gradient(135deg,#76ff03,#b2ff59)}
.lx-petal.pt-violet::before{background:linear-gradient(135deg,#d500f9,#ea80fc)}
@keyframes lxPetalDrift{
  0%{transform:translateY(-20px) rotate(0) scale(1);opacity:0}
  4%{opacity:.9}
  50%{transform:translateY(50vh) translateX(50px) rotate(180deg) scale(.7);opacity:.6}
  100%{transform:translateY(110vh) translateX(-40px) rotate(400deg) scale(.3);opacity:0}
}

/* === FLOATING HEARTS === */
.lx-heart{
  position:absolute;pointer-events:none;opacity:0;
  font-size:18px;
  animation:lxHeartFloat linear infinite;
}
@keyframes lxHeartFloat{
  0%{transform:translateY(0) scale(1) rotate(0);opacity:0}
  5%{opacity:.7}
  50%{transform:translateY(-50vh) translateX(30px) scale(.6) rotate(20deg);opacity:.4}
  100%{transform:translateY(-105vh) translateX(-20px) scale(.2) rotate(-15deg);opacity:0}
}

/* === FLOATING STARS === */
.lx-star{
  position:absolute;pointer-events:none;opacity:0;
  animation:lxStarTwinkle linear infinite;
}
@keyframes lxStarTwinkle{
  0%{transform:scale(0) rotate(0);opacity:0}
  10%{opacity:1;transform:scale(1) rotate(30deg)}
  50%{opacity:.3;transform:scale(.6) rotate(180deg)}
  80%{opacity:.8;transform:scale(1.2) rotate(300deg)}
  100%{opacity:0;transform:scale(0) rotate(360deg)}
}

/* ==================================
   SPLASH / OPENING SCREEN
   ================================== */
#lx-splash{
  position:fixed;inset:0;z-index:1000;
  display:flex;align-items:center;justify-content:center;flex-direction:column;
  background:
    radial-gradient(ellipse at 30% 20%,rgba(255,107,157,.08),transparent 50%),
    radial-gradient(ellipse at 70% 80%,rgba(0,229,255,.06),transparent 50%),
    radial-gradient(ellipse at 50% 50%,rgba(255,215,0,.05),transparent 40%),
    linear-gradient(180deg,#0a0a1a,#120828,#0a0a1a);
  overflow:hidden;
}

/* Spinning rings */
.lx-ring-container{position:relative;width:300px;height:300px;margin-bottom:25px}
.lx-ring{
  position:absolute;inset:0;border-radius:50%;
  border:2px solid transparent;
}
.lx-ring:nth-child(1){border-top-color:#ffd700;border-bottom-color:#ff6b9d;animation:lxSpin 8s linear infinite}
.lx-ring:nth-child(2){inset:15px;border-left-color:#00e5ff;border-right-color:#d500f9;animation:lxSpin 12s linear infinite reverse}
.lx-ring:nth-child(3){inset:30px;border-top-color:#76ff03;border-bottom-color:#ff9100;animation:lxSpin 6s linear infinite;border-style:dashed}
.lx-ring:nth-child(4){inset:45px;border-left-color:#ffd700;border-right-color:#e91e63;animation:lxSpin 15s linear infinite reverse;border-style:dotted}
.lx-ring:nth-child(5){inset:60px;border-color:rgba(255,215,0,.15);animation:lxSpin 20s linear infinite}
@keyframes lxSpin{to{transform:rotate(360deg)}}

/* Center diamond */
.lx-center-diamond{
  position:absolute;top:50%;left:50%;
  width:100px;height:100px;
  transform:translate(-50%,-50%) rotate(45deg);
  background:linear-gradient(135deg,rgba(255,215,0,.15),rgba(255,107,157,.1),rgba(0,229,255,.1));
  border:2px solid rgba(255,215,0,.3);
  box-shadow:0 0 40px rgba(255,215,0,.15),0 0 80px rgba(255,107,157,.08),inset 0 0 30px rgba(255,215,0,.05);
  animation:lxDiamondPulse 3s ease-in-out infinite;
}
.lx-center-diamond::before{
  content:'💑';position:absolute;top:50%;left:50%;
  transform:translate(-50%,-50%) rotate(-45deg);
  font-size:36px;
  filter:drop-shadow(0 0 15px rgba(255,215,0,.5));
}
@keyframes lxDiamondPulse{
  0%,100%{box-shadow:0 0 40px rgba(255,215,0,.15),0 0 80px rgba(255,107,157,.08);transform:translate(-50%,-50%) rotate(45deg) scale(1)}
  50%{box-shadow:0 0 60px rgba(255,215,0,.3),0 0 100px rgba(255,107,157,.15);transform:translate(-50%,-50%) rotate(45deg) scale(1.05)}
}

.lx-splash-hindi{
  font-family:'Noto Sans Devanagari',sans-serif;
  font-size:clamp(14px,3.5vw,22px);
  letter-spacing:3px;margin-bottom:10px;
  background:linear-gradient(90deg,#ffd700,#ff6b9d,#00e5ff,#ffd700);
  background-size:300% 100%;
  -webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text;
  animation:lxTextShimmer 4s linear infinite;
  text-shadow:none;
}
@keyframes lxTextShimmer{0%{background-position:0% 50%}100%{background-position:300% 50%}}

.lx-splash-names{
  font-family:'Great Vibes',cursive;
  font-size:clamp(46px,12vw,80px);
  background:linear-gradient(135deg,#ffd700,#ff6b9d,#00e5ff,#76ff03,#d500f9,#ffd700);
  background-size:500% 500%;
  -webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text;
  animation:lxNamesGlow 6s ease infinite;
  filter:drop-shadow(0 0 20px rgba(255,215,0,.3));
  line-height:1.2;
}
@keyframes lxNamesGlow{0%{background-position:0% 50%}50%{background-position:100% 50%}100%{background-position:0% 50%}}

.lx-splash-sub{
  font-family:'Cinzel',serif;font-size:clamp(10px,2.5vw,14px);
  letter-spacing:5px;text-transform:uppercase;
  color:rgba(255,255,255,.5);margin-top:5px;
}

.lx-open-btn{
  margin-top:35px;padding:18px 55px;
  border:none;border-radius:60px;cursor:pointer;
  font-family:'Cinzel Decorative',serif;font-size:clamp(11px,2.5vw,15px);
  letter-spacing:4px;text-transform:uppercase;color:#fff;
  background:linear-gradient(135deg,#ffd700,#ff6b9d,#d500f9,#00e5ff);
  background-size:300% 300%;
  animation:lxBtnGrad 4s ease infinite,lxBtnGlow 2s ease-in-out infinite;
  box-shadow:0 5px 30px rgba(255,215,0,.3),0 5px 60px rgba(255,107,157,.15);
  transition:transform .3s ease;
  position:relative;overflow:hidden;
}
.lx-open-btn:hover{transform:scale(1.08) translateY(-2px)}
.lx-open-btn::before{
  content:'';position:absolute;inset:-2px;border-radius:62px;padding:2px;
  background:linear-gradient(135deg,#ffd700,#ff6b9d,#00e5ff,#76ff03,#d500f9);
  background-size:400% 400%;animation:lxBtnGrad 3s ease infinite;
  -webkit-mask:linear-gradient(#fff 0 0) content-box,linear-gradient(#fff 0 0);
  -webkit-mask-composite:exclude;mask-composite:exclude;
  pointer-events:none;
}
@keyframes lxBtnGrad{0%{background-position:0% 50%}50%{background-position:100% 50%}100%{background-position:0% 50%}}
@keyframes lxBtnGlow{0%,100%{box-shadow:0 5px 30px rgba(255,215,0,.3),0 5px 60px rgba(255,107,157,.15)}50%{box-shadow:0 5px 50px rgba(255,215,0,.5),0 5px 80px rgba(255,107,157,.3)}}

/* ==================================
   MAIN INVITATION
   ================================== */
#lx-main{position:relative;z-index:5}

/* SPARK */
.lx-spark{position:fixed;border-radius:50%;pointer-events:none;z-index:9999}

/* ==================================
   GLASS CARD — Glassmorphism base
   ================================== */
.lx-glass{
  background:linear-gradient(135deg,rgba(255,255,255,.08),rgba(255,255,255,.02));
  backdrop-filter:blur(20px);-webkit-backdrop-filter:blur(20px);
  border:1px solid rgba(255,255,255,.12);
  border-radius:24px;
  box-shadow:0 8px 40px rgba(0,0,0,.3),inset 0 1px 0 rgba(255,255,255,.1);
  transition:transform .5s cubic-bezier(.25,.46,.45,.94),box-shadow .5s ease;
}
.lx-glass:hover{
  transform:translateY(-8px) scale(1.01);
  box-shadow:0 20px 60px rgba(0,0,0,.4),0 0 40px rgba(255,215,0,.08),inset 0 1px 0 rgba(255,255,255,.15);
}

/* ==================================
   SECTION STYLING
   ================================== */
.lx-section{
  position:relative;padding:100px 24px;overflow:hidden;
}
/* Alternating bright gradient backgrounds */
.lx-sec-1{background:linear-gradient(180deg,#0a0a1a 0%,#120828 50%,#0a0a1a 100%)}
.lx-sec-2{background:linear-gradient(180deg,#0a0a1a 0%,#0d1b2e 50%,#0a0a1a 100%)}
.lx-sec-3{background:linear-gradient(180deg,#0a0a1a 0%,#1a0e28 50%,#0a0a1a 100%)}
.lx-sec-4{background:linear-gradient(180deg,#0a0a1a 0%,#0a1e20 50%,#0a0a1a 100%)}
.lx-sec-5{background:linear-gradient(180deg,#0a0a1a 0%,#1e0a18 50%,#0a0a1a 100%)}

/* Neon glow borders on sections */
.lx-section::before{
  content:'';position:absolute;top:0;left:10%;right:10%;height:1px;
  background:linear-gradient(90deg,transparent,rgba(255,215,0,.4),rgba(255,107,157,.4),rgba(0,229,255,.4),transparent);
}
.lx-section::after{
  content:'';position:absolute;bottom:0;left:10%;right:10%;height:1px;
  background:linear-gradient(90deg,transparent,rgba(213,0,249,.3),rgba(255,145,0,.3),rgba(118,255,3,.3),transparent);
}

/* SECTION TITLE */
.lx-title{
  font-family:'Cinzel Decorative',serif;
  font-size:clamp(26px,6vw,46px);
  text-align:center;
  background:linear-gradient(135deg,#ffd700,#ff6b9d,#00e5ff,#ffd700);
  background-size:400% 400%;
  -webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text;
  animation:lxTitleShift 8s ease infinite;
  letter-spacing:3px;margin-bottom:8px;
  filter:drop-shadow(0 0 10px rgba(255,215,0,.2));
}
@keyframes lxTitleShift{0%{background-position:0% 50%}50%{background-position:100% 50%}100%{background-position:0% 50%}}

.lx-subtitle{
  font-family:'EB Garamond',serif;font-style:italic;
  font-size:clamp(14px,3vw,20px);
  color:rgba(255,255,255,.55);text-align:center;
  margin-bottom:50px;
}

/* Ornate Divider */
.lx-divider{
  display:flex;align-items:center;justify-content:center;gap:15px;
  margin:15px auto 30px;
}
.lx-div-line{
  width:80px;height:2px;
  background:linear-gradient(90deg,transparent,#ffd700,#ff6b9d,transparent);
  border-radius:2px;
}
.lx-div-gem{
  font-size:20px;
  filter:drop-shadow(0 0 8px rgba(255,215,0,.5));
  animation:lxGemSpin 6s linear infinite;
}
@keyframes lxGemSpin{0%{transform:rotate(0)}100%{transform:rotate(360deg)}}

/* ==================================
   3D ORNATE CORNERS
   ================================== */
.lx-corner{
  position:absolute;width:50px;height:50px;z-index:3;pointer-events:none;
}
.lx-corner::before,.lx-corner::after{
  content:'';position:absolute;
  background:linear-gradient(90deg,#ffd700,#ff6b9d);
  border-radius:2px;
}
.lx-corner::before{width:100%;height:2px}
.lx-corner::after{width:2px;height:100%}
.lx-c-tl{top:15px;left:15px}.lx-c-tl::before{top:0;left:0}.lx-c-tl::after{top:0;left:0}
.lx-c-tr{top:15px;right:15px}.lx-c-tr::before{top:0;right:0}.lx-c-tr::after{top:0;right:0}
.lx-c-bl{bottom:15px;left:15px}.lx-c-bl::before{bottom:0;left:0}.lx-c-bl::after{bottom:0;left:0}
.lx-c-br{bottom:15px;right:15px}.lx-c-br::before{bottom:0;right:0}.lx-c-br::after{bottom:0;right:0}

/* ==================================
   HERO SECTION
   ================================== */
#lx-hero{
  min-height:100vh;display:flex;align-items:center;justify-content:center;
  flex-direction:column;text-align:center;padding:60px 20px;
  perspective:1000px;
}
.lx-hero-badge{
  font-family:'Noto Sans Devanagari',sans-serif;
  font-size:clamp(14px,3vw,20px);
  background:linear-gradient(90deg,#ffd700,#ff6b9d,#00e5ff,#ffd700);
  background-size:300% 100%;
  -webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text;
  animation:lxTextShimmer 4s linear infinite;
  letter-spacing:3px;margin-bottom:30px;
}

/* PHOTO CIRCLES — 3D GLOW */
.lx-hero-photos{
  display:flex;align-items:center;justify-content:center;
  gap:clamp(15px,5vw,60px);margin-bottom:30px;flex-wrap:wrap;
  perspective:800px;
}
.lx-photo{
  position:relative;border-radius:50%;overflow:visible;
  display:flex;align-items:center;justify-content:center;flex-direction:column;
  cursor:pointer;transition:all .5s cubic-bezier(.25,.46,.45,.94);
  transform-style:preserve-3d;
}
.lx-photo:hover{transform:scale(1.1) rotateY(10deg) translateZ(20px)}
.lx-photo-circle{
  width:clamp(140px,28vw,200px);height:clamp(140px,28vw,200px);
  border-radius:50%;overflow:hidden;
  display:flex;align-items:center;justify-content:center;flex-direction:column;
  position:relative;
  background:linear-gradient(145deg,#1a1035,#0a0a20);
}
/* Multi-color animated border */
.lx-photo::before{
  content:'';position:absolute;inset:-4px;border-radius:50%;
  background:conic-gradient(from 0deg,#ffd700,#ff6b9d,#00e5ff,#76ff03,#d500f9,#ff9100,#ffd700);
  animation:lxSpin 4s linear infinite;
  z-index:-1;
}
.lx-photo::after{
  content:'';position:absolute;inset:-12px;border-radius:50%;
  border:1px solid rgba(255,215,0,.15);
  animation:lxRingPulse 3s ease-in-out infinite;
}
@keyframes lxRingPulse{0%,100%{opacity:.3;transform:scale(1)}50%{opacity:.6;transform:scale(1.04)}}
.lx-photo-circle img{width:100%;height:100%;object-fit:cover;position:absolute;inset:0;border-radius:50%}
.lx-photo-icon{font-size:28px;opacity:.4;
  background:linear-gradient(135deg,#ffd700,#ff6b9d);-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text;
}
.lx-photo-label{font-family:'Cinzel',serif;font-size:9px;letter-spacing:2px;text-transform:uppercase;color:rgba(255,255,255,.3);margin-top:4px}

.lx-hero-amp{
  font-family:'Great Vibes',cursive;font-size:clamp(50px,10vw,90px);
  background:linear-gradient(180deg,#ff6b9d,#ffd700,#00e5ff);
  -webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text;
  filter:drop-shadow(0 0 15px rgba(255,107,157,.3));
  animation:lxPulse 3s ease-in-out infinite;
}
@keyframes lxPulse{0%,100%{transform:scale(1)}50%{transform:scale(1.1)}}

.lx-hero-names{
  font-family:'Great Vibes',cursive;
  font-size:clamp(50px,13vw,90px);
  background:linear-gradient(135deg,#ffd700,#fff,#ff6b9d,#fff,#00e5ff,#fff,#ffd700);
  background-size:600% 600%;
  -webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text;
  animation:lxNamesGlow 8s ease infinite;
  filter:drop-shadow(0 0 25px rgba(255,215,0,.25));
  line-height:1.2;margin-bottom:12px;
}
.lx-hero-tagline{
  font-family:'EB Garamond',serif;font-style:italic;
  font-size:clamp(16px,3.5vw,24px);
  color:rgba(255,255,255,.6);margin-bottom:20px;
}
.lx-hero-date-box{
  display:inline-block;padding:12px 40px;border-radius:50px;
  border:1px solid rgba(255,215,0,.25);
  background:linear-gradient(135deg,rgba(255,215,0,.08),rgba(255,107,157,.05),rgba(0,229,255,.05));
  backdrop-filter:blur(10px);
  margin-bottom:8px;
}
.lx-hero-date{
  font-family:'Cinzel',serif;font-size:clamp(13px,2.8vw,18px);
  letter-spacing:4px;text-transform:uppercase;
  background:linear-gradient(90deg,#ffd700,#ff6b9d,#ffd700);
  background-size:200% 100%;
  -webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text;
  animation:lxTextShimmer 3s linear infinite;
}
.lx-hero-venue{
  font-family:'EB Garamond',serif;font-style:italic;
  font-size:clamp(14px,3vw,18px);color:rgba(255,255,255,.45);
  margin-top:6px;
}
.lx-scroll-hint{
  position:absolute;bottom:25px;left:50%;transform:translateX(-50%);
  animation:lxBounce 2s ease-in-out infinite;
}
.lx-scroll-hint i{
  font-size:22px;
  background:linear-gradient(180deg,#ffd700,#ff6b9d);
  -webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text;
}
@keyframes lxBounce{0%,100%{transform:translateX(-50%) translateY(0)}50%{transform:translateX(-50%) translateY(10px)}}

/* ==================================
   FAMILY CARDS — 3D Glass
   ================================== */
.lx-families{
  display:flex;align-items:stretch;justify-content:center;
  gap:clamp(20px,4vw,50px);flex-wrap:wrap;max-width:900px;margin:0 auto;
  perspective:1000px;
}
.lx-fam-card{
  flex:1;min-width:260px;max-width:380px;padding:40px 25px;text-align:center;
  position:relative;overflow:hidden;
  transform-style:preserve-3d;transition:transform .6s ease,box-shadow .6s ease;
}
.lx-fam-card:hover{
  transform:translateY(-12px) rotateX(5deg) rotateY(-3deg) scale(1.03);
  box-shadow:0 30px 70px rgba(0,0,0,.4),0 0 50px rgba(255,215,0,.1);
}
/* Holographic top stripe */
.lx-fam-card::before{
  content:'';position:absolute;top:0;left:0;right:0;height:3px;
  background:linear-gradient(90deg,#ffd700,#ff6b9d,#00e5ff,#76ff03,#d500f9,#ffd700);
  background-size:300% 100%;animation:lxTextShimmer 4s linear infinite;
}
.lx-fam-emoji{font-size:48px;margin-bottom:15px;display:block;
  filter:drop-shadow(0 0 10px rgba(255,215,0,.3));
  animation:lxPulse 4s ease-in-out infinite;
}
.lx-fam-name{
  font-family:'Cinzel Decorative',serif;font-size:clamp(14px,3vw,18px);
  background:linear-gradient(135deg,#ffd700,#ff6b9d);
  -webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text;
  letter-spacing:2px;margin-bottom:10px;
}
.lx-fam-parents{font-size:15px;color:rgba(255,255,255,.75);line-height:1.8;margin-bottom:12px}
.lx-fam-present{font-style:italic;font-size:14px;color:rgba(255,255,255,.4);margin-bottom:8px}
.lx-fam-person{
  font-family:'Great Vibes',cursive;font-size:clamp(30px,7vw,44px);
}
.lx-bride-c{
  background:linear-gradient(135deg,#ff6b9d,#ff1744,#e91e63);
  -webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text;
  filter:drop-shadow(0 0 10px rgba(255,107,157,.3));
}
.lx-groom-c{
  background:linear-gradient(135deg,#00e5ff,#18ffff,#00b8d4);
  -webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text;
  filter:drop-shadow(0 0 10px rgba(0,229,255,.3));
}

/* ==================================
   STORY — PHOTO + TEXT GRID
   ================================== */
.lx-story-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:40px;max-width:1000px;margin:0 auto;align-items:center}
.lx-photo-rect{
  width:100%;aspect-ratio:4/5;border-radius:20px;overflow:hidden;
  position:relative;cursor:pointer;
  background:linear-gradient(145deg,#1a1035,#0a0a20);
  display:flex;align-items:center;justify-content:center;flex-direction:column;
  transform-style:preserve-3d;
  transition:transform .6s ease,box-shadow .6s ease;
}
.lx-photo-rect::before{
  content:'';position:absolute;inset:-2px;border-radius:22px;
  background:conic-gradient(from 0deg,#ffd700,#ff6b9d,#00e5ff,#76ff03,#d500f9,#ffd700);
  animation:lxSpin 6s linear infinite;z-index:-1;
}
.lx-photo-rect:hover{transform:scale(1.04) rotateY(5deg) rotateX(-3deg) translateZ(15px);box-shadow:0 20px 60px rgba(0,0,0,.5)}
.lx-photo-rect img{width:100%;height:100%;object-fit:cover;position:absolute;inset:0;border-radius:20px}
.lx-story-text{text-align:center}
.lx-story-text h3{
  font-family:'Great Vibes',cursive;font-size:clamp(34px,7vw,52px);
  background:linear-gradient(135deg,#ffd700,#ff6b9d);
  -webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text;
  margin-bottom:18px;
}
.lx-story-text p{font-size:clamp(15px,3vw,18px);color:rgba(255,255,255,.75);line-height:1.8}
.lx-story-text .lx-quote{
  font-style:italic;margin-top:20px;
  background:linear-gradient(90deg,#ff6b9d,#ffd700);
  -webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text;
  font-size:clamp(16px,3.2vw,21px);
}

/* ==================================
   EVENT CARDS — 3D Bright Cards
   ================================== */
.lx-events-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:30px;max-width:1200px;margin:0 auto}
.lx-event{
  border-radius:24px;overflow:hidden;
  transform-style:preserve-3d;
  transition:transform .5s cubic-bezier(.25,.46,.45,.94),box-shadow .5s ease;
  cursor:pointer;position:relative;
  background:linear-gradient(180deg,rgba(255,255,255,.06),rgba(255,255,255,.02));
  backdrop-filter:blur(15px);
  border:1px solid rgba(255,255,255,.08);
}
.lx-event:hover{
  transform:translateY(-15px) rotateX(8deg) rotateY(-4deg) scale(1.04) translateZ(20px);
  box-shadow:0 30px 80px rgba(0,0,0,.5),0 0 50px var(--evt-glow,.15);
}
.lx-event-top{
  width:100%;aspect-ratio:16/10;overflow:hidden;position:relative;
  display:flex;align-items:center;justify-content:center;flex-direction:column;
}
.lx-event-top img{width:100%;height:100%;object-fit:cover;position:absolute;inset:0}
.lx-event-bar{position:absolute;bottom:0;left:0;right:0;height:4px}
.lx-event-body{padding:24px 20px}
.lx-event-icon{font-size:32px;margin-bottom:8px;display:block;
  filter:drop-shadow(0 0 8px rgba(255,215,0,.4));
}
.lx-event-name{
  font-family:'Cinzel Decorative',serif;font-size:clamp(16px,3.5vw,22px);
  background:linear-gradient(135deg,#ffd700,#ff6b9d);
  -webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text;
  letter-spacing:2px;margin-bottom:12px;
}
.lx-event-det{display:flex;align-items:center;gap:10px;font-size:14px;color:rgba(255,255,255,.6);margin-bottom:6px}
.lx-event-det i{width:16px;text-align:center;font-size:12px;
  background:linear-gradient(135deg,#ffd700,#ff6b9d);-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text;
}
.lx-event-desc{font-style:italic;font-size:15px;color:rgba(255,255,255,.5);margin-top:12px;line-height:1.6}

/* ==================================
   COUNTDOWN — 3D Neon Boxes
   ================================== */
.lx-countdown{display:flex;align-items:center;justify-content:center;gap:clamp(12px,3vw,30px);flex-wrap:wrap;margin:40px auto 0}
.lx-cd-box{
  text-align:center;padding:20px 15px;min-width:80px;
  border-radius:16px;
  background:linear-gradient(145deg,rgba(255,255,255,.06),rgba(255,255,255,.02));
  backdrop-filter:blur(15px);
  border:1px solid rgba(255,215,0,.12);
  box-shadow:0 8px 30px rgba(0,0,0,.3);
  transform-style:preserve-3d;
  transition:transform .3s ease;
}
.lx-cd-box:hover{transform:translateY(-5px) rotateX(10deg) scale(1.05)}
.lx-cd-num{
  display:block;font-family:'Playfair Display',serif;
  font-size:clamp(38px,8vw,62px);font-weight:900;
  background:linear-gradient(180deg,#ffd700,#ff6b9d);
  -webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text;
  line-height:1;
}
.lx-cd-label{
  font-family:'Cinzel',serif;font-size:clamp(9px,2vw,12px);
  letter-spacing:3px;text-transform:uppercase;
  color:rgba(255,255,255,.4);margin-top:6px;
}
.lx-cd-sep{
  font-size:clamp(28px,6vw,48px);font-weight:300;
  background:linear-gradient(180deg,#ffd700,#ff6b9d);
  -webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text;
  opacity:.4;
}

/* ==================================
   GALLERY — 3D Hover Grid
   ================================== */
.lx-gallery{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:20px;max-width:1000px;margin:0 auto}
.lx-gal-item{
  aspect-ratio:1;border-radius:20px;overflow:hidden;position:relative;
  cursor:pointer;
  display:flex;align-items:center;justify-content:center;flex-direction:column;
  background:linear-gradient(145deg,#1a1035,#0a0a20);
  transform-style:preserve-3d;
  transition:transform .5s cubic-bezier(.25,.46,.45,.94),box-shadow .5s ease;
}
.lx-gal-item::before{
  content:'';position:absolute;inset:-2px;border-radius:22px;
  background:conic-gradient(from 0deg,#ffd700,#ff6b9d,#00e5ff,#76ff03,#d500f9,#ffd700);
  animation:lxSpin 8s linear infinite;z-index:-1;opacity:.5;
  transition:opacity .3s ease;
}
.lx-gal-item:hover::before{opacity:1}
.lx-gal-item:hover{
  transform:scale(1.08) rotateY(8deg) rotateX(-5deg) translateZ(25px);
  box-shadow:0 20px 60px rgba(0,0,0,.5),0 0 40px rgba(255,215,0,.1);
}
.lx-gal-item img{width:100%;height:100%;object-fit:cover;position:absolute;inset:0;border-radius:20px}

/* ==================================
   CLOSING SECTION
   ================================== */
.lx-close-quote{
  font-family:'EB Garamond',serif;font-style:italic;
  font-size:clamp(18px,4vw,28px);text-align:center;
  max-width:600px;margin:0 auto 40px;line-height:1.6;
  background:linear-gradient(135deg,rgba(255,255,255,.8),rgba(255,255,255,.5));
  -webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text;
}
.lx-close-crest{text-align:center;margin-bottom:30px}
.lx-crest-letter{
  font-family:'Great Vibes',cursive;font-size:clamp(44px,9vw,65px);
  background:linear-gradient(135deg,#ffd700,#ff6b9d);
  -webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text;
}
.lx-crest-crown{
  font-size:clamp(30px,6vw,45px);margin:0 14px;display:inline-block;
  filter:drop-shadow(0 0 10px rgba(255,215,0,.4));
  animation:lxPulse 3s ease-in-out infinite;
}
.lx-close-msg{
  font-size:clamp(15px,3vw,19px);text-align:center;
  max-width:520px;margin:0 auto 25px;line-height:1.7;
  color:rgba(255,255,255,.65);
}
.lx-hashtag{
  font-family:'Dancing Script',cursive;font-size:clamp(28px,7vw,48px);
  text-align:center;
  background:linear-gradient(135deg,#ffd700,#ff6b9d,#00e5ff,#76ff03,#d500f9);
  background-size:500% 500%;
  -webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text;
  animation:lxNamesGlow 6s ease infinite;
  filter:drop-shadow(0 0 15px rgba(255,215,0,.2));
  margin-bottom:25px;
}
.lx-ornament{text-align:center;font-size:20px;letter-spacing:14px;color:#ffd700;margin-bottom:25px;
  filter:drop-shadow(0 0 8px rgba(255,215,0,.3));
}
.lx-signed{font-style:italic;font-size:15px;text-align:center;color:rgba(255,255,255,.4);line-height:1.8}
.lx-stamp{
  width:100px;height:100px;margin:35px auto 0;
  border-radius:50%;display:flex;align-items:center;justify-content:center;
  font-family:'Cinzel',serif;font-size:10px;text-align:center;letter-spacing:1px;line-height:1.4;
  position:relative;
  background:conic-gradient(from 0deg,rgba(255,215,0,.15),rgba(255,107,157,.1),rgba(0,229,255,.1),rgba(255,215,0,.15));
  border:2px solid rgba(255,215,0,.3);
  box-shadow:0 0 30px rgba(255,215,0,.1);
  animation:lxSpin 20s linear infinite;
  color:rgba(255,215,0,.7);
}
.lx-stamp-inner{animation:lxSpin 20s linear infinite reverse}
.lx-stamp::before{content:'';position:absolute;inset:5px;border:1px dashed rgba(255,215,0,.2);border-radius:50%}

/* ==================================
   MUSIC BUTTON
   ================================== */
#lx-music{
  position:fixed;bottom:20px;right:20px;z-index:100;
  width:52px;height:52px;border-radius:50%;border:none;cursor:pointer;
  background:linear-gradient(135deg,rgba(255,215,0,.15),rgba(255,107,157,.1));
  backdrop-filter:blur(15px);
  color:#ffd700;font-size:22px;
  display:flex;align-items:center;justify-content:center;
  transition:all .3s ease;
  box-shadow:0 5px 25px rgba(0,0,0,.4),0 0 15px rgba(255,215,0,.1);
}
#lx-music:hover{transform:scale(1.15);box-shadow:0 5px 25px rgba(0,0,0,.4),0 0 30px rgba(255,215,0,.25)}
#lx-music.playing{animation:lxMusicPulse 1.5s ease-in-out infinite}
@keyframes lxMusicPulse{
  0%,100%{box-shadow:0 5px 25px rgba(0,0,0,.4),0 0 15px rgba(255,215,0,.1)}
  50%{box-shadow:0 5px 25px rgba(0,0,0,.4),0 0 40px rgba(255,215,0,.35),0 0 80px rgba(255,107,157,.1)}
}

/* ==================================
   CONFETTI (for opening)
   ================================== */
.lx-confetti{
  position:fixed;pointer-events:none;z-index:1001;
  width:10px;height:10px;
}

/* ==================================
   FIREWORK
   ================================== */
.lx-fw{
  position:fixed;pointer-events:none;z-index:1001;
  width:6px;height:6px;border-radius:50%;
}

/* ==================================
   RESPONSIVE
   ================================== */
@media(max-width:768px){
  .lx-hero-photos{gap:12px}
  .lx-families{flex-direction:column;align-items:center}
  .lx-fam-card{min-width:auto;width:100%;max-width:340px}
  .lx-story-grid{grid-template-columns:1fr}
  .lx-events-grid{grid-template-columns:1fr}
  .lx-gallery{grid-template-columns:repeat(2,1fr)}
  .lx-section{padding:70px 16px}
}
@media(max-width:480px){
  .lx-photo-circle{width:110px;height:110px}
  .lx-gallery{grid-template-columns:repeat(2,1fr);gap:12px}
}
`;
    document.head.appendChild(css);
  }

  /* ==========================================================
     AUDIO ENGINE
     ========================================================== */
  var audioCtx = null;
  function ac() {
    if (!audioCtx) audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    return audioCtx;
  }
  function tone(f, dur, type, vol) {
    try {
      var c = ac(), o = c.createOscillator(), g = c.createGain();
      o.connect(g); g.connect(c.destination);
      o.type = type || 'sine'; o.frequency.value = f;
      g.gain.setValueAtTime(vol || 0.05, c.currentTime);
      g.gain.exponentialRampToValueAtTime(0.001, c.currentTime + dur);
      o.start(); o.stop(c.currentTime + dur);
    } catch (_) {}
  }

  /* Celebratory Shehnai */
  function playShehnai() {
    var m = [
      {f:523.25,d:.5,t:0},{f:587.33,d:.4,t:350},{f:659.25,d:.5,t:600},
      {f:698.46,d:.7,t:900},{f:783.99,d:.4,t:1400},{f:698.46,d:.3,t:1700},
      {f:659.25,d:.8,t:1900},{f:523.25,d:1,t:2500},
      {f:783.99,d:.6,t:3200},{f:880,d:.5,t:3600},{f:783.99,d:.4,t:3900},
      {f:698.46,d:.6,t:4200},{f:659.25,d:1.2,t:4600}
    ];
    m.forEach(function(n){
      setTimeout(function(){
        tone(n.f, n.d+.4, 'sawtooth', .02);
        tone(n.f*1.005, n.d+.4, 'sawtooth', .012);
        tone(n.f*2, n.d+.2, 'sine', .008);
      }, n.t);
    });
  }

  /* Sparkle sound */
  function playSparkle() {
    [1318.51,1567.98,2093,2637.02,3135.96].forEach(function(f,i){
      setTimeout(function(){tone(f,.35,'sine',.025)}, i*50);
    });
  }

  /* Bell chime */
  function playChime() {
    tone(1174.66,.8,'sine',.035);
    setTimeout(function(){tone(1567.98,.6,'sine',.025)},100);
    setTimeout(function(){tone(2093,.4,'sine',.02)},200);
  }

  /* Tinkle */
  function playTinkle() { tone(1800+Math.random()*1200,.12,'sine',.018) }

  /* Firework boom */
  function playBoom() {
    tone(80,.3,'square',.06);
    setTimeout(function(){tone(120,.15,'sawtooth',.04)},30);
    setTimeout(function(){
      [1046.5,1318.51,1567.98,2093,2637].forEach(function(f,i){
        setTimeout(function(){tone(f,.5,'sine',.02)},i*40);
      });
    },100);
  }

  /* Ambient music — dreamy sitar/tanpura */
  var ambNodes=[], ambPlaying=false;
  function startAmbient(){
    if(ambPlaying)return;
    try{
      var c=ac();
      [130.81,196,261.63].forEach(function(f){
        var o=c.createOscillator(),g=c.createGain();
        o.type='sine';o.frequency.value=f;
        o.connect(g);g.connect(c.destination);g.gain.value=.01;o.start();
        ambNodes.push({o:o,g:g});
      });
      [523.25,659.25,783.99,1046.5].forEach(function(f,i){
        var o=c.createOscillator(),g=c.createGain();
        var lfo=c.createOscillator(),lg=c.createGain();
        o.type='triangle';o.frequency.value=f;
        lfo.type='sine';lfo.frequency.value=.06+i*.02;
        lg.gain.value=.005;lfo.connect(lg);lg.connect(g.gain);
        o.connect(g);g.connect(c.destination);g.gain.value=.007;
        o.start();lfo.start();
        ambNodes.push({o:o,g:g,l:lfo});
      });
      ambPlaying=true;
    }catch(_){}
  }
  function stopAmbient(){
    ambNodes.forEach(function(n){try{n.o.stop();if(n.l)n.l.stop()}catch(_){}});
    ambNodes=[];ambPlaying=false;
  }

  /* ==========================================================
     BUILD PAGE HTML
     ========================================================== */
  function buildPage() {
    document.body.innerHTML = '';
    document.body.style.overflow = 'hidden';
    var h = '';

    /* BG + Floating containers */
    h += '<div class="lx-rainbow-bg"></div>';
    h += '<div id="lx-particles"></div>';
    h += '<div id="lx-petals"></div>';
    h += '<div id="lx-hearts"></div>';
    h += '<div id="lx-stars"></div>';

    /* === SPLASH === */
    h += '<section id="lx-splash">';
    h += '<div class="lx-ring-container">';
    for(var i=0;i<5;i++) h += '<div class="lx-ring"></div>';
    h += '<div class="lx-center-diamond"></div>';
    h += '</div>';
    h += '<p class="lx-splash-hindi">॥ श्री गणेशाय नमः ॥</p>';
    h += '<div class="lx-splash-names">'+W.bride+' & '+W.groom+'</div>';
    h += '<p class="lx-splash-sub">Request the Honour of Your Presence</p>';
    h += '<button class="lx-open-btn" id="lxOpen">✦ Open Invitation ✦</button>';
    h += '</section>';

    /* === MAIN === */
    h += '<div id="lx-main" class="lx-hide">';

    /* HERO */
    h += '<section id="lx-hero" class="lx-section lx-sec-1">';
    h += corners();
    h += '<p class="lx-hero-badge">॥ श्री गणेशाय नमः ॥</p>';
    h += '<div class="lx-hero-photos">';
    h += photoCircle('Bride');
    h += '<span class="lx-hero-amp">&</span>';
    h += photoCircle('Groom');
    h += '</div>';
    h += '<h1 class="lx-hero-names">'+W.bride+' & '+W.groom+'</h1>';
    h += '<p class="lx-hero-tagline">"Two souls, one eternal journey of love"</p>';
    h += divider();
    h += '<div class="lx-hero-date-box"><span class="lx-hero-date">'+W.day+' · '+W.date+'</span></div>';
    h += '<p class="lx-hero-venue">'+W.venue+'</p>';
    h += '<div class="lx-scroll-hint"><i class="fa-solid fa-chevron-down"></i></div>';
    h += '</section>';

    /* FAMILIES */
    h += '<section class="lx-section lx-sec-2">';
    h += corners();
    h += '<h2 class="lx-title">The Noble Families</h2>';
    h += divider();
    h += '<p class="lx-subtitle">Together in a joyous celebration of love</p>';
    h += '<div class="lx-families">';
    h += '<div class="lx-fam-card lx-glass">';
    h += '<span class="lx-fam-emoji">👸</span>';
    h += '<h3 class="lx-fam-name">House '+W.brideFamily+'</h3>';
    h += '<p class="lx-fam-parents">'+W.brideFather+'</p>';
    h += '<p class="lx-fam-present">Lovingly present their daughter</p>';
    h += '<h2 class="lx-fam-person lx-bride-c">'+W.brideFull+'</h2>';
    h += '</div>';
    h += '<div class="lx-fam-card lx-glass">';
    h += '<span class="lx-fam-emoji">🤴</span>';
    h += '<h3 class="lx-fam-name">House '+W.groomFamily+'</h3>';
    h += '<p class="lx-fam-parents">'+W.groomFather+'</p>';
    h += '<p class="lx-fam-present">Proudly present their son</p>';
    h += '<h2 class="lx-fam-person lx-groom-c">'+W.groomFull+'</h2>';
    h += '</div>';
    h += '</div>';
    h += '</section>';

    /* STORY + PHOTOS */
    h += '<section class="lx-section lx-sec-3">';
    h += corners();
    h += '<h2 class="lx-title">Our Love Story</h2>';
    h += divider();
    h += '<p class="lx-subtitle">Written in the stars, sealed by destiny</p>';
    h += '<div class="lx-story-grid">';
    h += '<div class="lx-photo-rect" title="Couple Photo"><i class="fa-solid fa-heart lx-photo-icon" style="font-size:42px"></i><span class="lx-photo-label">Couple Photo</span></div>';
    h += '<div class="lx-story-text"><h3>A Journey of Love</h3><p>From the first glance to forever, our story is one written by fate and friendship — every moment together has led us to this beautiful beginning.</p><p class="lx-quote">"In all the world, there is no heart for me like yours."</p></div>';
    h += '</div>';
    h += '<div class="lx-story-grid" style="margin-top:50px">';
    h += '<div class="lx-story-text"><h3>Pre-Wedding Bliss</h3><p>Every celebration, every shared smile — this chapter of engagement and joy has been magical beyond words. The best is yet to come.</p><p class="lx-quote">"The best thing to hold onto in life is each other."</p></div>';
    h += '<div class="lx-photo-rect" title="Pre-Wedding Photo"><i class="fa-solid fa-ring lx-photo-icon" style="font-size:42px"></i><span class="lx-photo-label">Pre-Wedding Photo</span></div>';
    h += '</div>';
    h += '</section>';

    /* EVENTS */
    h += '<section class="lx-section lx-sec-4">';
    h += corners();
    h += '<h2 class="lx-title">The Grand Festivities</h2>';
    h += divider();
    h += '<p class="lx-subtitle">Five days of grandeur, tradition & celebration</p>';
    h += '<div class="lx-events-grid">';
    W.events.forEach(function(e){
      h += '<div class="lx-event lx-glass" style="--evt-glow:'+e.grad+'">';
      h += '<div class="lx-event-top" style="background:'+e.bg+'" title="'+e.name+' Photo">';
      h += '<i class="fa-solid fa-image lx-photo-icon" style="font-size:36px"></i>';
      h += '<span class="lx-photo-label">'+e.name+' Photo</span>';
      h += '<div class="lx-event-bar" style="background:'+e.grad+'"></div>';
      h += '</div>';
      h += '<div class="lx-event-body">';
      h += '<span class="lx-event-icon">'+e.icon+'</span>';
      h += '<h3 class="lx-event-name">'+e.name+'</h3>';
      h += '<div class="lx-event-det"><i class="fa-solid fa-calendar"></i><span>'+e.date+'</span></div>';
      h += '<div class="lx-event-det"><i class="fa-solid fa-clock"></i><span>'+e.time+'</span></div>';
      h += '<div class="lx-event-det"><i class="fa-solid fa-location-dot"></i><span>'+e.place+'</span></div>';
      h += '<p class="lx-event-desc">'+e.desc+'</p>';
      h += '</div></div>';
    });
    h += '</div>';
    h += '</section>';

    /* COUNTDOWN */
    h += '<section class="lx-section lx-sec-5">';
    h += corners();
    h += '<h2 class="lx-title">Counting Down to Forever</h2>';
    h += divider();
    h += '<p class="lx-subtitle">Every second brings us closer to our dream</p>';
    h += '<div class="lx-countdown">';
    h += cdBox('lxDays','Days') + '<span class="lx-cd-sep">:</span>';
    h += cdBox('lxHrs','Hours') + '<span class="lx-cd-sep">:</span>';
    h += cdBox('lxMins','Minutes') + '<span class="lx-cd-sep">:</span>';
    h += cdBox('lxSecs','Seconds');
    h += '</div>';
    h += '</section>';

    /* GALLERY */
    h += '<section class="lx-section lx-sec-1">';
    h += corners();
    h += '<h2 class="lx-title">Precious Moments</h2>';
    h += divider();
    h += '<p class="lx-subtitle">A glimpse of our beautiful journey</p>';
    h += '<div class="lx-gallery">';
    var gLabels=['Bride Portrait','Groom Portrait','Together Forever','Ring Ceremony','Family Joy','Our Journey'];
    var gIcons=['fa-user-tie','fa-user','fa-heart','fa-gem','fa-people-group','fa-camera'];
    gLabels.forEach(function(l,i){
      h += '<div class="lx-gal-item" title="'+l+'">';
      h += '<i class="fa-solid '+gIcons[i]+' lx-photo-icon" style="font-size:32px"></i>';
      h += '<span class="lx-photo-label">'+l+'</span>';
      h += '</div>';
    });
    h += '</div>';
    h += '</section>';

    /* CLOSING */
    h += '<section class="lx-section lx-sec-3" style="padding-bottom:120px">';
    h += corners();
    h += '<p class="lx-close-quote">"A love story for the ages — written by destiny, sealed by the stars, and blessed by the heavens."</p>';
    h += '<div class="lx-close-crest">';
    h += '<span class="lx-crest-letter">'+W.bride[0]+'</span>';
    h += '<span class="lx-crest-crown">♛</span>';
    h += '<span class="lx-crest-letter">'+W.groom[0]+'</span>';
    h += '</div>';
    h += '<p class="lx-close-msg">Your gracious presence shall be the most treasured gift at this royal celebration of love.</p>';
    h += '<div class="lx-hashtag">'+W.hashtag+'</div>';
    h += '<div class="lx-ornament">⚜ ✦ 👑 ✦ ⚜</div>';
    h += '<p class="lx-signed">With Eternal Love & Royal Regards,<br>The '+W.brideFamily+' & '+W.groomFamily+' Families</p>';
    h += '<div class="lx-stamp"><span class="lx-stamp-inner">SEALED<br>&<br>BLESSED<br>2026</span></div>';
    h += '</section>';

    h += '</div>'; // #lx-main

    h += '<button id="lx-music" class="lx-hide" title="Toggle Music"><i class="fa-solid fa-music"></i></button>';

    document.body.innerHTML = h;
  }

  function corners(){return '<div class="lx-corner lx-c-tl"></div><div class="lx-corner lx-c-tr"></div><div class="lx-corner lx-c-bl"></div><div class="lx-corner lx-c-br"></div>'}
  function divider(){return '<div class="lx-divider"><span class="lx-div-line"></span><span class="lx-div-gem">💎</span><span class="lx-div-line"></span></div>'}
  function cdBox(id,label){return '<div class="lx-cd-box"><span class="lx-cd-num" id="'+id+'">00</span><span class="lx-cd-label">'+label+'</span></div>'}
  function photoCircle(label){
    return '<div class="lx-photo"><div class="lx-photo-circle"><i class="fa-solid fa-camera lx-photo-icon"></i><span class="lx-photo-label">'+label+'</span></div></div>';
  }

  /* ==========================================================
     FLOATING EFFECTS — Particles, Petals, Hearts, Stars
     ========================================================== */
  function spawnParticles(n){
    var c=document.getElementById('lx-particles');if(!c)return;
    var cls=['c-gold','c-rose','c-cyan','c-lime','c-violet','c-orange'];
    for(var i=0;i<(n||60);i++){
      var p=document.createElement('div');
      p.className='lx-ptcl '+cls[Math.floor(Math.random()*cls.length)];
      p.style.left=Math.random()*100+'%';p.style.bottom='-10px';
      var s=1.5+Math.random()*4.5;
      p.style.width=s+'px';p.style.height=s+'px';
      p.style.animationDuration=(10+Math.random()*20)+'s';
      p.style.animationDelay=(Math.random()*18)+'s';
      c.appendChild(p);
    }
  }
  function spawnPetals(n){
    var c=document.getElementById('lx-petals');if(!c)return;
    var cls=['pt-hot','pt-pink','pt-gold','pt-cyan','pt-lime','pt-violet'];
    for(var i=0;i<(n||30);i++){
      var p=document.createElement('div');
      p.className='lx-petal '+cls[Math.floor(Math.random()*cls.length)];
      p.style.left=Math.random()*100+'%';p.style.top='-20px';
      var s=12+Math.random()*16;
      p.style.width=s+'px';p.style.height=s+'px';
      p.style.animationDuration=(14+Math.random()*18)+'s';
      p.style.animationDelay=(Math.random()*22)+'s';
      c.appendChild(p);
    }
  }
  function spawnHearts(n){
    var c=document.getElementById('lx-hearts');if(!c)return;
    var colors=['#ff1744','#ff6b9d','#e91e63','#ff4081','#ffd700','#00e5ff'];
    for(var i=0;i<(n||15);i++){
      var h=document.createElement('div');
      h.className='lx-heart';h.textContent='❤';
      h.style.left=Math.random()*100+'%';h.style.bottom='-20px';
      h.style.color=colors[Math.floor(Math.random()*colors.length)];
      h.style.fontSize=(14+Math.random()*18)+'px';
      h.style.animationDuration=(12+Math.random()*16)+'s';
      h.style.animationDelay=(Math.random()*20)+'s';
      h.style.filter='drop-shadow(0 0 6px '+h.style.color+')';
      c.appendChild(h);
    }
  }
  function spawnStars(n){
    var c=document.getElementById('lx-stars');if(!c)return;
    var syms=['✦','✧','⭐','★','✨'];
    var colors=['#ffd700','#00e5ff','#ff6b9d','#76ff03','#d500f9','#ff9100'];
    for(var i=0;i<(n||20);i++){
      var s=document.createElement('div');
      s.className='lx-star';
      s.textContent=syms[Math.floor(Math.random()*syms.length)];
      s.style.left=Math.random()*100+'%';
      s.style.top=Math.random()*100+'%';
      s.style.fontSize=(10+Math.random()*18)+'px';
      s.style.color=colors[Math.floor(Math.random()*colors.length)];
      s.style.animationDuration=(3+Math.random()*6)+'s';
      s.style.animationDelay=(Math.random()*8)+'s';
      s.style.filter='drop-shadow(0 0 4px '+s.style.color+')';
      c.appendChild(s);
    }
  }

  /* ==========================================================
     SPARK BURST — Multi-color
     ========================================================== */
  function sparkBurst(cx,cy,count){
    var colors=['#ffd700','#ff6b9d','#00e5ff','#76ff03','#d500f9','#ff9100','#ff1744','#18ffff','#ffc107','#e040fb'];
    for(var i=0;i<(count||40);i++){
      var s=document.createElement('div');
      s.className='lx-spark';
      s.style.left=cx+'px';s.style.top=cy+'px';
      var sz=2+Math.random()*6;
      s.style.width=sz+'px';s.style.height=sz+'px';
      var col=colors[Math.floor(Math.random()*colors.length)];
      s.style.background=col;s.style.boxShadow='0 0 8px '+col+',0 0 20px '+col;
      s.style.borderRadius='50%';
      document.body.appendChild(s);
      var angle=Math.random()*Math.PI*2;
      var dist=60+Math.random()*250;
      gsap.to(s,{x:Math.cos(angle)*dist,y:Math.sin(angle)*dist,opacity:0,duration:.8+Math.random()*1.2,ease:'power2.out',onComplete:function(){if(s.parentNode)s.remove()}});
    }
  }

  /* ==========================================================
     CONFETTI EXPLOSION
     ========================================================== */
  function confettiBurst(cx,cy,count){
    var colors=['#ffd700','#ff1744','#00e5ff','#76ff03','#d500f9','#ff6b9d','#ff9100','#e040fb','#1de9b6','#ffc107'];
    for(var i=0;i<(count||80);i++){
      var c=document.createElement('div');
      c.className='lx-confetti';
      c.style.left=cx+'px';c.style.top=cy+'px';
      c.style.background=colors[Math.floor(Math.random()*colors.length)];
      var w=6+Math.random()*10;
      var h=4+Math.random()*8;
      c.style.width=w+'px';c.style.height=h+'px';
      c.style.borderRadius=Math.random()>.5?'50%':'2px';
      document.body.appendChild(c);
      var angle=Math.random()*Math.PI*2;
      var dist=100+Math.random()*350;
      gsap.to(c,{
        x:Math.cos(angle)*dist,
        y:Math.sin(angle)*dist+Math.random()*200,
        rotation:Math.random()*720,
        opacity:0,
        duration:1+Math.random()*2,
        ease:'power2.out',
        onComplete:function(){if(c.parentNode)c.remove()}
      });
    }
  }

  /* ==========================================================
     FIREWORKS
     ========================================================== */
  function firework(cx,cy){
    var colors=['#ffd700','#ff1744','#00e5ff','#76ff03','#d500f9','#ff6b9d'];
    var col=colors[Math.floor(Math.random()*colors.length)];
    for(var i=0;i<50;i++){
      var p=document.createElement('div');
      p.className='lx-fw';
      p.style.left=cx+'px';p.style.top=cy+'px';
      p.style.background=col;
      p.style.boxShadow='0 0 6px '+col+',0 0 15px '+col;
      document.body.appendChild(p);
      var angle=(i/50)*Math.PI*2;
      var dist=80+Math.random()*160;
      gsap.to(p,{
        x:Math.cos(angle)*dist,
        y:Math.sin(angle)*dist,
        opacity:0,
        duration:.7+Math.random()*.8,
        ease:'power2.out',
        onComplete:function(){if(p.parentNode)p.remove()}
      });
    }
    playBoom();
  }

  function fireworkShow(){
    var w=window.innerWidth,h=window.innerHeight;
    var spots=[
      {x:w*.2,y:h*.25,d:0},{x:w*.8,y:h*.2,d:300},{x:w*.5,y:h*.15,d:600},
      {x:w*.3,y:h*.35,d:900},{x:w*.7,y:h*.3,d:1200},{x:w*.5,y:h*.4,d:1500}
    ];
    spots.forEach(function(s){setTimeout(function(){firework(s.x,s.y)},s.d)});
  }

  /* ==========================================================
     SPLASH ANIMATION
     ========================================================== */
  function animateSplash(){
    var tl=gsap.timeline({delay:.3});
    tl.from('.lx-ring-container',{opacity:0,scale:.3,duration:1.5,ease:'power2.out'});
    tl.from('.lx-center-diamond',{opacity:0,scale:0,rotation:180,duration:1,ease:'back.out(1.5)'},'-=1');
    tl.from('.lx-splash-hindi',{opacity:0,y:15,duration:.5},'-=.5');
    tl.from('.lx-splash-names',{opacity:0,y:20,duration:.7},'-=.3');
    tl.from('.lx-splash-sub',{opacity:0,y:10,duration:.4},'-=.3');
    tl.from('.lx-open-btn',{opacity:0,scale:.7,duration:.5,ease:'back.out(1.7)'},'-=.2');
  }

  /* ==========================================================
     OPEN INVITATION — The Big Reveal
     ========================================================== */
  function openInvitation(){
    var splash=document.getElementById('lx-splash');
    var main=document.getElementById('lx-main');
    var music=document.getElementById('lx-music');
    var cx=window.innerWidth/2, cy=window.innerHeight/2;

    playShehnai();

    var tl=gsap.timeline({
      onComplete:function(){
        splash.style.display='none';
        document.body.style.overflow='';
        music.classList.remove('lx-hide');
        music.classList.add('playing');
        startAmbient();
        initCountdown();
        initScrollReveals();
        // Delayed firework show
        setTimeout(fireworkShow,600);
      }
    });

    // Rings explode outward
    tl.to('.lx-ring',{scale:3,opacity:0,stagger:.05,duration:.6,ease:'power2.in'});
    tl.to('.lx-center-diamond',{scale:5,opacity:0,rotation:360,duration:.6,ease:'power2.in'},'-=.5');

    // Confetti + Sparks
    tl.add(function(){
      confettiBurst(cx,cy,100);
      sparkBurst(cx,cy,60);
      playSparkle();
    },'-=.3');

    // Text fades
    tl.to('.lx-splash-hindi,.lx-splash-names,.lx-splash-sub,.lx-open-btn',
      {opacity:0,y:-20,duration:.3,stagger:.04},'-=.4');

    // Splash fade
    tl.to(splash,{opacity:0,duration:.4});

    // Main reveal
    tl.add(function(){
      main.classList.remove('lx-hide');
      sparkBurst(cx,cy*.7,50);
    });
    tl.from(main,{opacity:0,y:30,duration:.8,ease:'power2.out'});

    // Hero entrance
    tl.from('.lx-hero-badge',{opacity:0,y:-15,duration:.5},'-=.5');
    tl.from('.lx-photo',{opacity:0,scale:.3,rotateY:60,duration:.8,stagger:.2,ease:'back.out(1.5)'},'-=.3');
    tl.from('.lx-hero-amp',{opacity:0,scale:0,duration:.4,ease:'back.out(2)'},'-=.3');
    tl.from('.lx-hero-names',{opacity:0,y:20,duration:.7},'-=.2');
    tl.from('.lx-hero-tagline',{opacity:0,y:10,duration:.4},'-=.2');
    tl.from('#lx-hero .lx-divider',{scaleX:0,duration:.5},'-=.2');
    tl.from('.lx-hero-date-box',{opacity:0,scale:.8,duration:.5,ease:'back.out(1.5)'},'-=.2');
    tl.from('.lx-hero-venue',{opacity:0,y:10,duration:.3},'-=.2');
    tl.from('.lx-scroll-hint',{opacity:0,duration:.4},'-=.1');
    tl.from('#lx-hero .lx-corner',{opacity:0,scale:0,duration:.3,stagger:.06,ease:'back.out(2)'},'-=.6');

    // Another confetti wave
    tl.add(function(){
      confettiBurst(cx,cy*.5,50);
    },'-=.5');
  }

  /* ==========================================================
     COUNTDOWN
     ========================================================== */
  function initCountdown(){
    var t=new Date(W.date+' '+W.time).getTime();
    function upd(){
      var d=Math.max(0,t-Date.now());
      sv('lxDays',Math.floor(d/864e5));
      sv('lxHrs',Math.floor(d%864e5/36e5));
      sv('lxMins',Math.floor(d%36e5/6e4));
      var s=Math.floor(d%6e4/1e3);
      var el=document.getElementById('lxSecs');
      if(el){var p=el.textContent,n=String(s).padStart(2,'0');if(p!==n){el.textContent=n;if(typeof gsap!=='undefined')gsap.from(el,{y:-6,opacity:.3,duration:.2})}}
    }
    function sv(id,v){var e=document.getElementById(id);if(e)e.textContent=String(v).padStart(id==='lxDays'?3:2,'0')}
    upd();setInterval(upd,1000);
  }

  /* ==========================================================
     SCROLL REVEALS
     ========================================================== */
  function initScrollReveals(){
    if(typeof gsap==='undefined'||typeof ScrollTrigger==='undefined')return;
    gsap.registerPlugin(ScrollTrigger);

    // Section corners
    document.querySelectorAll('.lx-section').forEach(function(sec){
      sec.querySelectorAll('.lx-corner').forEach(function(c,i){
        gsap.from(c,{scrollTrigger:{trigger:sec,start:'top 80%'},opacity:0,scale:0,duration:.4,delay:i*.08,ease:'back.out(2)'});
      });
    });

    // Titles
    document.querySelectorAll('.lx-title').forEach(function(t){
      gsap.from(t,{scrollTrigger:{trigger:t,start:'top 85%'},opacity:0,y:30,rotateX:30,duration:.8,ease:'power3.out'});
    });

    // Dividers
    document.querySelectorAll('.lx-divider').forEach(function(d){
      gsap.from(d,{scrollTrigger:{trigger:d,start:'top 88%'},scaleX:0,duration:.6});
    });

    // Subtitles
    document.querySelectorAll('.lx-subtitle').forEach(function(s){
      gsap.from(s,{scrollTrigger:{trigger:s,start:'top 88%'},opacity:0,y:15,duration:.5});
    });

    // Family cards — 3D entrance
    document.querySelectorAll('.lx-fam-card').forEach(function(card,i){
      gsap.from(card,{
        scrollTrigger:{trigger:card,start:'top 85%'},
        opacity:0,y:60,rotateX:30,rotateY:i===0?-20:20,scale:.85,
        duration:.9,delay:i*.2,ease:'power3.out',
        onStart:function(){
          var r=card.getBoundingClientRect();
          sparkBurst(r.left+r.width/2,r.top+r.height/2,12);
          playTinkle();
        }
      });
    });

    // Story grids
    document.querySelectorAll('.lx-story-grid').forEach(function(grid,i){
      var kids=grid.children;
      gsap.from(kids[0],{scrollTrigger:{trigger:grid,start:'top 80%'},opacity:0,x:i%2===0?-60:60,rotateY:i%2===0?-15:15,duration:.9,ease:'power3.out'});
      gsap.from(kids[1],{scrollTrigger:{trigger:grid,start:'top 80%'},opacity:0,x:i%2===0?60:-60,rotateY:i%2===0?15:-15,duration:.9,delay:.15,ease:'power3.out'});
    });

    // Event cards — 3D staggered
    document.querySelectorAll('.lx-event').forEach(function(card,i){
      gsap.from(card,{
        scrollTrigger:{trigger:card,start:'top 85%'},
        opacity:0,y:70,rotateX:25,scale:.9,
        duration:.8,delay:i*.12,ease:'power3.out',
        onStart:function(){
          playChime();
          var r=card.getBoundingClientRect();
          sparkBurst(r.left+r.width/2,r.top+10,8);
        }
      });
    });

    // Countdown boxes  
    document.querySelectorAll('.lx-cd-box').forEach(function(b,i){
      gsap.from(b,{
        scrollTrigger:{trigger:'.lx-countdown',start:'top 85%'},
        opacity:0,scale:.3,rotateY:90,duration:.7,delay:i*.15,ease:'back.out(1.5)'
      });
    });

    // Gallery items — 3D pop
    document.querySelectorAll('.lx-gal-item').forEach(function(item,i){
      gsap.from(item,{
        scrollTrigger:{trigger:item,start:'top 85%'},
        opacity:0,scale:.5,rotateX:20,rotateY:(i%2===0?-15:15),
        duration:.7,delay:i*.1,ease:'back.out(1.3)',
        onStart:function(){playTinkle()}
      });
    });

    // Closing
    gsap.from('.lx-close-quote',{scrollTrigger:{trigger:'.lx-close-quote',start:'top 85%'},opacity:0,y:25,duration:.8});
    gsap.from('.lx-close-crest',{scrollTrigger:{trigger:'.lx-close-crest',start:'top 85%'},opacity:0,scale:.2,rotateY:180,duration:1.2,ease:'back.out(1.7)'});
    gsap.from('.lx-close-msg',{scrollTrigger:{trigger:'.lx-close-msg',start:'top 88%'},opacity:0,y:15,duration:.7});
    gsap.from('.lx-hashtag',{scrollTrigger:{trigger:'.lx-hashtag',start:'top 88%'},opacity:0,y:10,scale:.8,duration:.7,ease:'back.out(1.5)'});
    gsap.from('.lx-stamp',{scrollTrigger:{trigger:'.lx-stamp',start:'top 90%'},opacity:0,scale:0,rotation:-180,duration:1,ease:'back.out(2)'});
  }

  /* ==========================================================
     3D TILT ON HOVER (Desktop)
     ========================================================== */
  function init3DTilt(){
    document.querySelectorAll('.lx-event,.lx-fam-card,.lx-gal-item,.lx-photo-rect').forEach(function(el){
      el.addEventListener('mousemove',function(e){
        var r=el.getBoundingClientRect();
        var x=e.clientX-r.left,y=e.clientY-r.top;
        var cx=r.width/2,cy=r.height/2;
        var ry=((x-cx)/cx)*12;
        var rx=((cy-y)/cy)*10;
        el.style.transform='perspective(800px) rotateY('+ry+'deg) rotateX('+rx+'deg) translateZ(15px) translateY(-8px) scale(1.03)';
        el.style.transition='transform .1s ease';
      });
      el.addEventListener('mouseleave',function(){
        el.style.transition='transform .5s cubic-bezier(.25,.46,.45,.94)';
        el.style.transform='';
      });
    });
  }

  /* Click sparkles everywhere */
  function initClickSparkle(){
    document.querySelectorAll('.lx-photo,.lx-photo-rect,.lx-gal-item,.lx-event,.lx-fam-card').forEach(function(el){
      el.addEventListener('click',function(e){
        sparkBurst(e.clientX,e.clientY,25);
        playSparkle();
      });
    });
  }

  /* ==========================================================
     MUSIC TOGGLE
     ========================================================== */
  function initMusic(){
    var btn=document.getElementById('lx-music');if(!btn)return;
    btn.addEventListener('click',function(){
      if(ambPlaying){
        stopAmbient();btn.classList.remove('playing');
        btn.innerHTML='<i class="fa-solid fa-volume-xmark"></i>';
      } else {
        startAmbient();btn.classList.add('playing');
        btn.innerHTML='<i class="fa-solid fa-music"></i>';
      }
    });
  }

  /* ==========================================================
     CONTINUOUS RANDOM SPARKLES (background magic)
     ========================================================== */
  function continuousSparkles(){
    setInterval(function(){
      if(document.getElementById('lx-main')&&!document.getElementById('lx-main').classList.contains('lx-hide')){
        var x=Math.random()*window.innerWidth;
        var y=Math.random()*window.innerHeight;
        sparkBurst(x,y,3);
      }
    },4000);
  }

  /* ==========================================================
     INIT
     ========================================================== */
  function init(){
    loadFonts();
    injectCSS();
    buildPage();
    spawnParticles(65);
    spawnPetals(35);
    spawnHearts(18);
    spawnStars(25);
    animateSplash();
    init3DTilt();
    initClickSparkle();
    initMusic();
    continuousSparkles();

    var btn=document.getElementById('lxOpen');
    if(btn){
      btn.addEventListener('click',function handler(){
        btn.removeEventListener('click',handler);
        openInvitation();
      });
    }
  }

  if(document.readyState==='loading'){document.addEventListener('DOMContentLoaded',init)} else {init()}
})();
