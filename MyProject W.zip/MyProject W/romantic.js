/* ═══════════════════════════════════════════
   ROMANTIC THEME — JavaScript
   Piano melody, petals, hearts, sparkle effects
   ═══════════════════════════════════════════ */
(function(){
  'use strict';

  // ── FLOATING PETALS ──
  var petalsEl = document.getElementById('petals');
  var petalEmojis = ['🌸','🌺','🌷','💮','🏵️'];
  for(var i=0;i<15;i++){
    var p = document.createElement('div');
    p.className='petal';
    p.textContent = petalEmojis[Math.floor(Math.random()*petalEmojis.length)];
    p.style.left = Math.random()*100+'%';
    p.style.top = '-15px';
    p.style.fontSize = (12+Math.random()*14)+'px';
    p.style.animationDuration = (10+Math.random()*15)+'s';
    p.style.animationDelay = (Math.random()*12)+'s';
    petalsEl.appendChild(p);
  }

  // ── FLOATING HEARTS ──
  var heartsEl = document.getElementById('hearts');
  var heartChars = ['♥','❤','💕','💖','💗'];
  for(var i=0;i<10;i++){
    var h = document.createElement('div');
    h.className='heart-float';
    h.textContent = heartChars[Math.floor(Math.random()*heartChars.length)];
    h.style.left = Math.random()*100+'%';
    h.style.bottom = '-15px';
    h.style.fontSize = (14+Math.random()*16)+'px';
    h.style.animationDuration = (12+Math.random()*16)+'s';
    h.style.animationDelay = (Math.random()*18)+'s';
    heartsEl.appendChild(h);
  }

  // ── SPARKLE BURST ──
  function sparkBurst(cx, cy, n){
    var cols = ['#e91e63','#f8bbd0','#d4a574','#fff','#ff69b4','#ffb6c1'];
    for(var i=0;i<(n||25);i++){
      var s = document.createElement('div');
      s.className='spark';
      s.style.left = cx+'px';
      s.style.top = cy+'px';
      var sz = 2+Math.random()*5;
      s.style.width = sz+'px'; s.style.height = sz+'px';
      var c = cols[Math.floor(Math.random()*cols.length)];
      s.style.background = c;
      s.style.boxShadow = '0 0 8px '+c;
      document.body.appendChild(s);
      var a = Math.random()*Math.PI*2, d = 40+Math.random()*160;
      gsap.to(s,{x:Math.cos(a)*d, y:Math.sin(a)*d, opacity:0, duration:.7+Math.random(), ease:'power2.out', onComplete:function(){if(s.parentNode)s.remove()}});
    }
  }

  // ── SPLASH ANIMATION ──
  gsap.from('.sp-rose',{opacity:0,scale:0,rotation:-20,duration:1,delay:.3,ease:'back.out(1.5)'});
  gsap.from('.sp-for',{opacity:0,y:12,duration:.5,delay:.8});
  gsap.from('.sp-name',{opacity:0,y:18,duration:.7,delay:1.1});
  gsap.from('.sp-sub',{opacity:0,y:8,duration:.4,delay:1.4});
  gsap.from('.sp-btn',{opacity:0,scale:.7,duration:.5,delay:1.7,ease:'back.out(1.5)'});

  // ── OPEN BUTTON ──
  document.getElementById('openBtn').addEventListener('click',function(){
    var splash = document.getElementById('splash');
    var main = document.getElementById('main');
    var cx = window.innerWidth/2, cy = window.innerHeight/2;
    var tl = gsap.timeline({onComplete:function(){
      splash.style.display='none';
      document.body.style.overflow='';
      initScrollAnimations();
    }});
    tl.to('.sp-rose',{scale:3,opacity:0,rotation:180,duration:.5});
    tl.add(function(){sparkBurst(cx,cy,60)},'-=.3');
    tl.to('.sp-for,.sp-name,.sp-sub,.sp-btn',{opacity:0,y:-12,duration:.3,stagger:.04},'-=.3');
    tl.to(splash,{opacity:0,duration:.4});
    tl.add(function(){main.classList.remove('hide')});
    tl.from(main,{opacity:0,y:25,duration:.6,ease:'power2.out'});
    tl.from('.hero-photo',{opacity:0,scale:0,duration:.6,ease:'back.out(2)'},'-=.2');
    tl.from('.hero-wish',{opacity:0,y:15,duration:.5},'-=.2');
    tl.from('.hero-name',{opacity:0,y:10,duration:.4},'-=.2');
    tl.from('.hero-msg',{opacity:0,y:10,duration:.4},'-=.2');
  });

  // ── SCROLL ANIMATIONS ──
  function initScrollAnimations(){
    gsap.registerPlugin(ScrollTrigger);
    document.querySelectorAll('.sec-title').forEach(function(t){
      gsap.from(t,{scrollTrigger:{trigger:t,start:'top 85%'},opacity:0,y:25,duration:.7,ease:'power3.out'});
    });
    gsap.from('.letter-card',{scrollTrigger:{trigger:'.letter-card',start:'top 80%'},opacity:0,y:35,duration:.8,ease:'power3.out'});
    document.querySelectorAll('.pg-item').forEach(function(p,i){
      gsap.from(p,{scrollTrigger:{trigger:p,start:'top 85%'},opacity:0,scale:.6,duration:.5,delay:i*.07,ease:'back.out(1.3)'});
    });
    document.querySelectorAll('.qual-card').forEach(function(q,i){
      gsap.from(q,{scrollTrigger:{trigger:q,start:'top 85%'},opacity:0,y:30,scale:.85,duration:.5,delay:i*.07,ease:'back.out(1.3)'});
    });
    document.querySelectorAll('.tl-item').forEach(function(t,i){
      gsap.from(t,{scrollTrigger:{trigger:t,start:'top 87%'},opacity:0,x:-25,duration:.5,delay:i*.1,ease:'power3.out'});
    });
    gsap.from('.close-rose',{scrollTrigger:{trigger:'.close-rose',start:'top 85%'},opacity:0,scale:0,duration:.8,ease:'back.out(1.7)'});
    gsap.from('.close-msg',{scrollTrigger:{trigger:'.close-msg',start:'top 85%'},opacity:0,y:18,duration:.6});
  }

  // ── 3D TILT ──
  document.querySelectorAll('.pg-item,.qual-card,.letter-card,.hero-photo').forEach(function(el){
    el.addEventListener('mousemove',function(e){
      var r=el.getBoundingClientRect();
      var ry=((e.clientX-r.left-r.width/2)/(r.width/2))*8;
      var rx=((r.height/2-(e.clientY-r.top))/(r.height/2))*6;
      el.style.transform='perspective(800px) rotateY('+ry+'deg) rotateX('+rx+'deg) translateZ(10px) scale(1.04)';
      el.style.transition='transform .1s ease';
    });
    el.addEventListener('mouseleave',function(){
      el.style.transition='transform .5s ease';
      el.style.transform='';
    });
  });

  // ── CLICK SPARKLES ──
  document.addEventListener('click',function(e){
    if(e.target.closest('.pg-item,.qual-card,.hero-photo'))sparkBurst(e.clientX,e.clientY,15);
  });

  // ── PIANO MUSIC (Web Audio API) ──
  var audioCtx = null, musicPlaying = false, musicInterval = null;

  function createPianoNote(freq, time, dur, vol){
    var osc = audioCtx.createOscillator();
    var gain = audioCtx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(freq, time);
    // Add slight vibrato
    var vibrato = audioCtx.createOscillator();
    var vibratoGain = audioCtx.createGain();
    vibrato.frequency.setValueAtTime(5, time);
    vibratoGain.gain.setValueAtTime(2, time);
    vibrato.connect(vibratoGain);
    vibratoGain.connect(osc.frequency);
    vibrato.start(time);
    vibrato.stop(time+dur+.5);

    gain.gain.setValueAtTime(0, time);
    gain.gain.linearRampToValueAtTime(vol||.08, time+.05);
    gain.gain.exponentialRampToValueAtTime(.001, time+dur);
    osc.connect(gain);
    gain.connect(audioCtx.destination);
    osc.start(time);
    osc.stop(time+dur);
  }

  function playPianoMelody(){
    if(!audioCtx) audioCtx = new (window.AudioContext||window.webkitAudioContext)();
    // Romantic piano melody in C major / A minor
    var notes = [
      {f:523.25,d:1},{f:659.25,d:.8},{f:783.99,d:1.2},{f:659.25,d:.6},
      {f:523.25,d:1},{f:440,d:.8},{f:523.25,d:1.5},{f:0,d:.5},
      {f:587.33,d:.8},{f:698.46,d:1},{f:880,d:1.2},{f:783.99,d:.6},
      {f:659.25,d:1},{f:523.25,d:.8},{f:440,d:1.5},{f:0,d:.5},
      {f:392,d:1},{f:523.25,d:.8},{f:659.25,d:1.2},{f:587.33,d:.6},
      {f:523.25,d:1},{f:440,d:.8},{f:392,d:1.5},{f:0,d:.5}
    ];
    var t = audioCtx.currentTime + .1;
    notes.forEach(function(n){
      if(n.f>0) createPianoNote(n.f, t, n.d, .06);
      t += n.d * .7;
    });
    return t - audioCtx.currentTime;
  }

  function toggleMusic(){
    if(musicPlaying){
      musicPlaying = false;
      if(musicInterval) clearInterval(musicInterval);
      document.getElementById('musicBtn').innerHTML = '<i class="fa-solid fa-volume-xmark"></i>';
    } else {
      musicPlaying = true;
      var dur = playPianoMelody();
      musicInterval = setInterval(function(){if(musicPlaying)playPianoMelody()}, dur*1000);
      document.getElementById('musicBtn').innerHTML = '<i class="fa-solid fa-music"></i>';
    }
  }

  document.getElementById('musicBtn').addEventListener('click', toggleMusic);

  // Lock scroll on splash
  document.body.style.overflow = 'hidden';
})();
