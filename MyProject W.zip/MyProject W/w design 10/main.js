/* ============================================
   LUXURY INDIAN WEDDING INVITATION - JAVASCRIPT
   Animations, Particles, Interactions
   ============================================ */

// ===== PRELOADER =====
window.addEventListener('load', () => {
    const preloader = document.getElementById('preloader');
    setTimeout(() => {
        preloader.classList.add('fade-out');
        setTimeout(() => {
            preloader.style.display = 'none';
        }, 800);
    }, 2500);
});

// ===== PARTICLES CANVAS =====
(function initParticles() {
    const canvas = document.getElementById('particles-canvas');
    const ctx = canvas.getContext('2d');
    let particles = [];
    const particleCount = 60;

    function resize() {
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
    }
    resize();
    window.addEventListener('resize', resize);

    class Particle {
        constructor() {
            this.reset();
        }
        reset() {
            this.x = Math.random() * canvas.width;
            this.y = Math.random() * canvas.height;
            this.size = Math.random() * 3 + 0.5;
            this.speedX = (Math.random() - 0.5) * 0.5;
            this.speedY = (Math.random() - 0.5) * 0.5;
            this.opacity = Math.random() * 0.5 + 0.1;
            this.flickerSpeed = Math.random() * 0.02 + 0.005;
            this.angle = Math.random() * Math.PI * 2;
            // Bright festive Indian wedding colors
            const colors = [
                'rgba(255, 215, 0,',    // Gold
                'rgba(255, 229, 102,',  // Bright gold
                'rgba(255, 107, 0,',    // Orange
                'rgba(220, 20, 60,',    // Crimson
                'rgba(255, 64, 129,',   // Pink
                'rgba(255, 153, 51,',   // Saffron
                'rgba(255, 20, 147,',   // Hot pink
                'rgba(173, 255, 47,',   // Lime green
            ];
            this.color = colors[Math.floor(Math.random() * colors.length)];
        }
        update() {
            this.x += this.speedX + Math.sin(this.angle) * 0.2;
            this.y += this.speedY + Math.cos(this.angle) * 0.2;
            this.angle += this.flickerSpeed;
            this.opacity += Math.sin(this.angle) * 0.01;
            this.opacity = Math.max(0.05, Math.min(0.6, this.opacity));

            if (this.x < -10 || this.x > canvas.width + 10 ||
                this.y < -10 || this.y > canvas.height + 10) {
                this.reset();
            }
        }
        draw() {
            ctx.beginPath();
            ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
            ctx.fillStyle = this.color + this.opacity + ')';
            ctx.fill();
            // Glow
            ctx.beginPath();
            ctx.arc(this.x, this.y, this.size * 3, 0, Math.PI * 2);
            ctx.fillStyle = this.color + (this.opacity * 0.2) + ')';
            ctx.fill();
        }
    }

    for (let i = 0; i < particleCount; i++) {
        particles.push(new Particle());
    }

    function animateParticles() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        particles.forEach(p => {
            p.update();
            p.draw();
        });
        requestAnimationFrame(animateParticles);
    }
    animateParticles();
})();

// ===== MUSIC TOGGLE =====
const musicBtn = document.getElementById('music-toggle');
const bgMusic = document.getElementById('bg-music');
let musicPlaying = false;

musicBtn.addEventListener('click', () => {
    if (musicPlaying) {
        bgMusic.pause();
        musicBtn.classList.remove('playing');
        musicPlaying = false;
    } else {
        bgMusic.volume = 0.3;
        bgMusic.play().catch(() => {});
        musicBtn.classList.add('playing');
        musicPlaying = true;
    }
});

// ===== ENVELOPE OPENING =====
const envelope = document.getElementById('envelope');
const envelopeSection = document.getElementById('envelope-section');
const invitationContent = document.getElementById('invitation-content');
let envelopeOpened = false;

envelope.addEventListener('click', () => {
    if (envelopeOpened) return;
    envelopeOpened = true;

    // Open envelope animation
    envelope.classList.add('opened');

    // Start music softly
    if (!musicPlaying) {
        bgMusic.volume = 0;
        bgMusic.play().then(() => {
            musicBtn.classList.add('playing');
            musicPlaying = true;
            // Fade in music
            let vol = 0;
            const fadeIn = setInterval(() => {
                vol += 0.02;
                if (vol >= 0.3) {
                    vol = 0.3;
                    clearInterval(fadeIn);
                }
                bgMusic.volume = vol;
            }, 100);
        }).catch(() => {});
    }

    // After envelope opens, transition to invitation
    setTimeout(() => {
        envelopeSection.classList.add('opened');

        setTimeout(() => {
            envelopeSection.style.display = 'none';
            invitationContent.classList.remove('hidden');

            // Start petal rain
            createPetalRain();

            // Start floating hearts
            startFloatingHearts();

            // Initialize AOS
            AOS.init({
                duration: 800,
                easing: 'ease-out-cubic',
                once: true,
                offset: 80
            });

            // Initialize GSAP ScrollTrigger animations
            initGSAPAnimations();

            // Refresh AOS & ScrollTrigger after content is visible
            setTimeout(() => {
                AOS.refresh();
                if (typeof ScrollTrigger !== 'undefined') {
                    ScrollTrigger.refresh();
                }
            }, 300);

            // Smooth scroll to top
            window.scrollTo({ top: 0, behavior: 'instant' });

        }, 800);
    }, 1800);
});

// ===== PETAL RAIN =====
function createPetalRain() {
    const petalRain = document.getElementById('petal-rain');
    const petalCount = 25;
    const petalColors = [
        'radial-gradient(ellipse at center, #ff6b6b, #c0392b)',
        'radial-gradient(ellipse at center, #ff9ff3, #f368e0)',
        'radial-gradient(ellipse at center, #ffa502, #e17055)',
        'radial-gradient(ellipse at center, #ff6348, #ee5a24)',
        'radial-gradient(ellipse at center, #FFD700, #FFA500)'
    ];

    for (let i = 0; i < petalCount; i++) {
        const petal = document.createElement('div');
        petal.classList.add('petal');
        petal.style.left = Math.random() * 100 + '%';
        petal.style.width = (Math.random() * 10 + 8) + 'px';
        petal.style.height = (Math.random() * 10 + 8) + 'px';
        petal.style.background = petalColors[Math.floor(Math.random() * petalColors.length)];
        petal.style.animationDuration = (Math.random() * 6 + 6) + 's';
        petal.style.animationDelay = (Math.random() * 8) + 's';
        petal.style.opacity = Math.random() * 0.5 + 0.3;
        petalRain.appendChild(petal);
    }

    // Fade out petals after 20 seconds
    setTimeout(() => {
        petalRain.style.transition = 'opacity 3s ease';
        petalRain.style.opacity = '0';
        setTimeout(() => {
            petalRain.innerHTML = '';
            petalRain.style.opacity = '1';
        }, 3000);
    }, 20000);
}

// ===== FLOATING HEARTS =====
function startFloatingHearts() {
    const heartsContainer = document.getElementById('floating-hearts');
    const heartSymbols = ['❤', '♥', '💕', '✿', '❀'];

    function createHeart() {
        const heart = document.createElement('div');
        heart.classList.add('floating-heart');
        heart.textContent = heartSymbols[Math.floor(Math.random() * heartSymbols.length)];
        heart.style.left = Math.random() * 100 + '%';
        heart.style.fontSize = (Math.random() * 12 + 8) + 'px';
        heart.style.animationDuration = (Math.random() * 8 + 8) + 's';
        heart.style.color = `rgba(${Math.floor(Math.random() * 100 + 150)}, ${Math.floor(Math.random() * 50 + 20)}, ${Math.floor(Math.random() * 80 + 40)}, 0.3)`;
        heartsContainer.appendChild(heart);

        // Remove after animation
        setTimeout(() => {
            heart.remove();
        }, 16000);
    }

    // Create hearts periodically
    setInterval(createHeart, 2000);
    // Initial burst
    for (let i = 0; i < 5; i++) {
        setTimeout(createHeart, i * 400);
    }
}

// ===== COUNTDOWN TIMER =====
function updateCountdown() {
    const weddingDate = new Date('February 15, 2027 11:30:00').getTime();
    const now = new Date().getTime();
    const diff = weddingDate - now;

    if (diff <= 0) {
        document.getElementById('days').textContent = '00';
        document.getElementById('hours').textContent = '00';
        document.getElementById('minutes').textContent = '00';
        document.getElementById('seconds').textContent = '00';
        return;
    }

    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
    const seconds = Math.floor((diff % (1000 * 60)) / 1000);

    document.getElementById('days').textContent = String(days).padStart(2, '0');
    document.getElementById('hours').textContent = String(hours).padStart(2, '0');
    document.getElementById('minutes').textContent = String(minutes).padStart(2, '0');
    document.getElementById('seconds').textContent = String(seconds).padStart(2, '0');
}

// Start countdown
updateCountdown();
setInterval(updateCountdown, 1000);

// ===== GSAP SCROLL ANIMATIONS =====
function initGSAPAnimations() {
    // Register ScrollTrigger
    gsap.registerPlugin(ScrollTrigger);

    // Intro couple names entrance
    gsap.from('.groom-name', {
        duration: 1.5,
        x: -100,
        opacity: 0,
        ease: 'power3.out',
        scrollTrigger: {
            trigger: '.couple-names',
            start: 'top 80%'
        }
    });

    gsap.from('.bride-name', {
        duration: 1.5,
        x: 100,
        opacity: 0,
        ease: 'power3.out',
        scrollTrigger: {
            trigger: '.couple-names',
            start: 'top 80%'
        }
    });

    gsap.from('.ampersand', {
        duration: 1,
        scale: 0,
        opacity: 0,
        ease: 'back.out(1.7)',
        delay: 0.5,
        scrollTrigger: {
            trigger: '.couple-names',
            start: 'top 80%'
        }
    });

    // Event cards - slide up with glow
    document.querySelectorAll('.event-card').forEach((card) => {
        // Ensure cards are visible by default
        card.style.opacity = '1';
        card.style.transform = 'translateY(0)';

        gsap.fromTo(card,
            { y: 60, opacity: 0.2 },
            {
                duration: 1,
                y: 0,
                opacity: 1,
                ease: 'power2.out',
                scrollTrigger: {
                    trigger: card,
                    start: 'top 90%',
                    toggleActions: 'play none none none'
                }
            }
        );
    });

    // Countdown items stagger
    gsap.from('.countdown-item', {
        duration: 0.8,
        y: 40,
        opacity: 0,
        stagger: 0.15,
        ease: 'power2.out',
        scrollTrigger: {
            trigger: '.countdown-container',
            start: 'top 85%'
        }
    });

    // Gallery items
    gsap.from('.gallery-item', {
        duration: 0.6,
        scale: 0.8,
        opacity: 0,
        stagger: 0.1,
        ease: 'power2.out',
        scrollTrigger: {
            trigger: '.gallery-grid',
            start: 'top 85%'
        }
    });

    // Timeline cards
    document.querySelectorAll('.timeline-card').forEach((card, i) => {
        gsap.from(card, {
            duration: 0.8,
            x: i % 2 === 0 ? -50 : 50,
            opacity: 0,
            ease: 'power2.out',
            scrollTrigger: {
                trigger: card,
                start: 'top 85%'
            }
        });
    });

    // RSVP card
    gsap.from('.rsvp-card', {
        duration: 1,
        y: 60,
        opacity: 0,
        ease: 'power2.out',
        scrollTrigger: {
            trigger: '.rsvp-card',
            start: 'top 85%'
        }
    });
}

// ===== SMOOTH SCROLL NAVIGATION =====
document.querySelectorAll('.nav-link').forEach(link => {
    link.addEventListener('click', (e) => {
        e.preventDefault();
        const targetId = link.getAttribute('href');
        const target = document.querySelector(targetId);

        if (target) {
            const navHeight = document.getElementById('main-nav').offsetHeight;
            const targetPos = target.offsetTop - navHeight;
            window.scrollTo({
                top: targetPos,
                behavior: 'smooth'
            });
        }

        // Update active state
        document.querySelectorAll('.nav-link').forEach(l => l.classList.remove('active'));
        link.classList.add('active');
    });
});

// Update active nav on scroll
window.addEventListener('scroll', () => {
    const sections = document.querySelectorAll('.section');
    const navLinks = document.querySelectorAll('.nav-link');
    const navHeight = document.getElementById('main-nav')?.offsetHeight || 0;

    let current = '';
    sections.forEach(section => {
        const sectionTop = section.offsetTop - navHeight - 100;
        if (window.scrollY >= sectionTop) {
            current = section.getAttribute('id');
        }
    });

    navLinks.forEach(link => {
        link.classList.remove('active');
        if (link.getAttribute('href') === '#' + current) {
            link.classList.add('active');
        }
    });
});

// ===== RSVP FORM =====
const rsvpForm = document.getElementById('rsvp-form');
const rsvpPopup = document.getElementById('rsvp-popup');
const popupClose = document.getElementById('popup-close');

if (rsvpForm) {
    rsvpForm.addEventListener('submit', (e) => {
        e.preventDefault();

        // Show popup
        rsvpPopup.classList.remove('hidden');

        // Reset form
        rsvpForm.reset();

        // Create celebration burst
        celebrationBurst();
    });
}

if (popupClose) {
    popupClose.addEventListener('click', () => {
        rsvpPopup.classList.add('hidden');
    });
}

// Close popup on background click
if (rsvpPopup) {
    rsvpPopup.addEventListener('click', (e) => {
        if (e.target === rsvpPopup) {
            rsvpPopup.classList.add('hidden');
        }
    });
}

// ===== CELEBRATION BURST EFFECT =====
function celebrationBurst() {
    const symbols = ['✨', '💖', '🌸', '⭐', '🎉', '❤', '✿'];
    const container = document.createElement('div');
    container.style.cssText = 'position:fixed;top:0;left:0;width:100%;height:100%;pointer-events:none;z-index:100000;overflow:hidden;';
    document.body.appendChild(container);

    for (let i = 0; i < 30; i++) {
        const particle = document.createElement('div');
        particle.textContent = symbols[Math.floor(Math.random() * symbols.length)];
        particle.style.cssText = `
            position: absolute;
            top: 50%;
            left: 50%;
            font-size: ${Math.random() * 20 + 12}px;
            pointer-events: none;
            animation: none;
        `;
        container.appendChild(particle);

        // Animate with GSAP
        if (typeof gsap !== 'undefined') {
            gsap.to(particle, {
                duration: 1.5 + Math.random(),
                x: (Math.random() - 0.5) * window.innerWidth * 0.8,
                y: (Math.random() - 0.5) * window.innerHeight * 0.8,
                opacity: 0,
                scale: 0.5 + Math.random(),
                rotation: Math.random() * 360,
                ease: 'power2.out',
                onComplete: () => particle.remove()
            });
        }
    }

    setTimeout(() => container.remove(), 3000);
}

// ===== NAV HIDE/SHOW ON SCROLL =====
let lastScrollY = 0;
const mainNav = document.getElementById('main-nav');

window.addEventListener('scroll', () => {
    if (!mainNav) return;
    const currentScrollY = window.scrollY;

    if (currentScrollY > lastScrollY && currentScrollY > 100) {
        mainNav.style.transform = 'translateY(-100%)';
    } else {
        mainNav.style.transform = 'translateY(0)';
    }
    lastScrollY = currentScrollY;
});

// ===== SPARKLE CURSOR TRAIL (subtle) =====
let cursorTrailEnabled = true;
document.addEventListener('mousemove', (e) => {
    if (!cursorTrailEnabled) return;
    if (Math.random() > 0.85) { // Only sometimes
        const sparkle = document.createElement('div');
        sparkle.textContent = '✦';
        sparkle.style.cssText = `
            position: fixed;
            left: ${e.clientX}px;
            top: ${e.clientY}px;
            font-size: ${Math.random() * 8 + 6}px;
            color: rgba(201, 146, 15, ${Math.random() * 0.5 + 0.2});
            pointer-events: none;
            z-index: 99999;
            transition: all 1s ease;
        `;
        document.body.appendChild(sparkle);

        requestAnimationFrame(() => {
            sparkle.style.transform = `translateY(-${Math.random() * 30 + 20}px) translateX(${(Math.random() - 0.5) * 30}px) scale(0)`;
            sparkle.style.opacity = '0';
        });

        setTimeout(() => sparkle.remove(), 1000);
    }
});

// ===== PARALLAX EFFECT ON INTRO =====
window.addEventListener('scroll', () => {
    const intro = document.querySelector('.intro-content');
    if (intro) {
        const scrolled = window.scrollY;
        intro.style.transform = `translateY(${scrolled * 0.1}px)`;
    }
});

// ===== TILT EFFECT ON EVENT CARDS (desktop) =====
if (window.innerWidth > 768) {
    document.querySelectorAll('.event-card').forEach(card => {
        card.addEventListener('mousemove', (e) => {
            const rect = card.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const y = e.clientY - rect.top;
            const centerX = rect.width / 2;
            const centerY = rect.height / 2;

            const rotateX = (y - centerY) / centerY * -3;
            const rotateY = (x - centerX) / centerX * 3;

            card.style.transform = `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) translateY(-5px)`;
        });

        card.addEventListener('mouseleave', () => {
            card.style.transform = 'perspective(1000px) rotateX(0) rotateY(0) translateY(0)';
        });
    });
}

// ===== CONSOLE GREETING =====
console.log(
    '%c 💒 Arjun & Priya Wedding Invitation 💒 ',
    'background: linear-gradient(135deg, #c9920f, #f5d78e); color: #1a0a05; padding: 12px 20px; font-size: 16px; font-family: serif; border-radius: 8px;'
);