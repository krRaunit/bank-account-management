/* ═══════════════════════════════════════════
   CLASSIC VINTAGE THEME — JavaScript
   Harp arpeggios, gentle leaves, elegant reveals
   ═══════════════════════════════════════════ */
(function(){
  'use strict';

  // ── FALLING LEAVES ──
  var leavesEl=document.getElementById('leaves');
  var leafEmojis=['🍂','🍁','🌿','🍃','✦'];
  for(var i=0;i<12;i++){
    var l=document.createElement('div');l.className='leaf';
    l.textContent=leafEmojis[Math.floor(Math.random()*leafEmojis.length)];
    l.style.left=Math.random()*100+'%';l.style.top='-12px';
    l.style.fontSize=(10+Math.random()*12)+'px';
    l.style.animationDuration=(12+Math.random()*16)+'s';
    l.style.animationDelay=(Math.random()*15)+'s';
    leavesEl.appendChild(l);
  }

  // ── SPARK BURST ──
  function sparkBurst(cx,cy,n){
    var cols=['#800020','#c9975c','#f5f0e8','#2d5a27','#d4a574'];
    for(var i=0;i<(n||20);i++){
      var s=document.createElement('div');s.className='spark';
      s.style.left=cx+'px';s.style.top=cy+'px';
      var sz=2+Math.random()*4;s.style.width=sz+'px';s.style.height=sz+'px';
      var c=cols[Math.floor(Math.random()*cols.length)];
      s.style.background=c;s.style.boxShadow='0 0 6px '+c;
      document.body.appendChild(s);
      var a=Math.random()*Math.PI*2,d=30+Math.random()*120;
      gsap.to(s,{x:Math.cos(a)*d,y:Math.sin(a)*d,opacity:0,duration:.8+Math.random(),ease:'power2.out',onComplete:function(){if(s.parentNode)s.remove()}});
    }
  }

  // ── SPLASH ANIM ──
  gsap.from('.sp-crest',{opacity:0,y:-20,duration:.8,delay:.3,ease:'power3.out'});
  gsap.from('.sp-line',{scaleX:0,duration:.5,delay:.6});
  gsap.from('.sp-for',{opacity:0,y:8,duration:.5,delay:.8});
  gsap.from('.sp-name',{opacity:0,y:15,duration:.7,delay:1.1});
  gsap.from('.sp-sub',{opacity:0,y:6,duration:.4,delay:1.4});
  gsap.from('.sp-btn',{opacity:0,y:10,duration:.5,delay:1.7});

  // ── OPEN ──
  document.getElementById('openBtn').addEventListener('click',function(){
    var splash=document.getElementById('splash'),main=document.getElementById('main');
    var cx=window.innerWidth/2,cy=window.innerHeight/2;
    var tl=gsap.timeline({onComplete:function(){splash.style.display='none';document.body.style.overflow='';initSR()}});
    tl.to('.sp-crest',{y:-40,opacity:0,duration:.4});
    tl.add(function(){sparkBurst(cx,cy,50)},'-=.2');
    tl.to('#splash > *:not(.sp-crest)',{opacity:0,y:-10,duration:.25,stagger:.03},'-=.3');
    tl.to(splash,{opacity:0,duration:.35});
    tl.add(function(){main.classList.remove('hide')});
    tl.from(main,{opacity:0,duration:.5});
    tl.from('.hero-polaroid',{opacity:0,y:30,rotation:-10,duration:.7,ease:'power3.out'},'-=.2');
    tl.from('.hero-wish',{opacity:0,y:12,duration:.5},'-=.2');
    tl.from('.hero-name',{opacity:0,y:8,duration:.4},'-=.15');
    tl.from('.hero-msg',{opacity:0,y:8,duration:.4},'-=.15');
  });

  // ── SCROLL REVEALS ──
  function initSR(){
    gsap.registerPlugin(ScrollTrigger);
    document.querySelectorAll('.sec-title').forEach(function(t){
      gsap.from(t,{scrollTrigger:{trigger:t,start:'top 85%'},opacity:0,y:20,duration:.7});
    });
    gsap.from('.vintage-letter',{scrollTrigger:{trigger:'.vintage-letter',start:'top 80%'},opacity:0,y:30,duration:.8});
    document.querySelectorAll('.pol-item').forEach(function(p,i){
      gsap.from(p,{scrollTrigger:{trigger:p,start:'top 85%'},opacity:0,y:25,rotation:i%2?-8:8,duration:.5,delay:i*.08,ease:'power3.out'});
    });
    document.querySelectorAll('.vint-card').forEach(function(v,i){
      gsap.from(v,{scrollTrigger:{trigger:v,start:'top 85%'},opacity:0,y:25,duration:.5,delay:i*.07});
    });
    gsap.from('.classic-poem',{scrollTrigger:{trigger:'.classic-poem',start:'top 82%'},opacity:0,y:20,duration:.7});
    gsap.from('.close-crest',{scrollTrigger:{trigger:'.close-crest',start:'top 85%'},opacity:0,y:-15,duration:.6});
  }

  // ── 3D HOVER ──
  document.querySelectorAll('.pol-item,.vint-card,.vintage-letter,.hero-polaroid').forEach(function(el){
    el.addEventListener('mousemove',function(e){
      var r=el.getBoundingClientRect();
      var ry=((e.clientX-r.left-r.width/2)/(r.width/2))*8;
      var rx=((r.height/2-(e.clientY-r.top))/(r.height/2))*6;
      el.style.transform='perspective(800px) rotateY('+ry+'deg) rotateX('+rx+'deg) translateZ(8px)';
      el.style.transition='transform .1s ease';
    });
    el.addEventListener('mouseleave',function(){el.style.transition='transform .5s ease';el.style.transform=''});
  });

  document.addEventListener('click',function(e){
    if(e.target.closest('.pol-item,.vint-card,.hero-polaroid'))sparkBurst(e.clientX,e.clientY,12);
  });

  // ── HARP ARPEGGIOS MUSIC (Web Audio) ──
  var audioCtx=null,musicPlaying=false,musicInterval=null;

  function playHarp(){
    if(!audioCtx)audioCtx=new(window.AudioContext||window.webkitAudioContext)();
    // C major harp arpeggio pattern ascending/descending
    var notes=[
      261.63,329.63,392,523.25,659.25,783.99,1046.50,
      783.99,659.25,523.25,392,329.63,261.63,
      220,329.63,440,523.25,659.25,880,
      659.25,523.25,440,329.63,261.63
    ];
    var t=audioCtx.currentTime+.1;
    notes.forEach(function(f){
      var osc=audioCtx.createOscillator(),gain=audioCtx.createGain();
      // Harp sound: combination of triangle+sine
      osc.type='triangle';
      osc.frequency.setValueAtTime(f,t);
      gain.gain.setValueAtTime(0,t);
      gain.gain.linearRampToValueAtTime(.05,t+.01);
      gain.gain.exponentialRampToValueAtTime(.001,t+1.2);
      osc.connect(gain);gain.connect(audioCtx.destination);
      osc.start(t);osc.stop(t+1.3);
      t+=.25;
    });
    return t-audioCtx.currentTime;
  }

  function toggleMusic(){
    if(musicPlaying){
      musicPlaying=false;if(musicInterval)clearInterval(musicInterval);
      document.getElementById('musicBtn').innerHTML='<i class="fa-solid fa-volume-xmark"></i>';
    }else{
      musicPlaying=true;
      var dur=playHarp();
      musicInterval=setInterval(function(){if(musicPlaying)playHarp()},dur*1000+300);
      document.getElementById('musicBtn').innerHTML='<i class="fa-solid fa-music"></i>';
    }
  }
  document.getElementById('musicBtn').addEventListener('click',toggleMusic);

  document.body.style.overflow='hidden';
})();
