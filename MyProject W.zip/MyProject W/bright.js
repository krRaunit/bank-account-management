/* ═══════════════════════════════════════════
   BRIGHT NEON THEME — JavaScript
   Chiptune music, confetti, balloons, neon bursts
   ═══════════════════════════════════════════ */
(function(){
  'use strict';

  // ── CONFETTI ──
  var confEl=document.getElementById('confetti');
  var confColors=['#00d4ff','#ff0080','#39ff14','#ffe600','#ff6600','#b84dff'];
  for(var i=0;i<35;i++){
    var c=document.createElement('div');c.className='confetti-piece';
    c.style.left=Math.random()*100+'%';c.style.top='-10px';
    c.style.background=confColors[Math.floor(Math.random()*confColors.length)];
    c.style.borderRadius=Math.random()>.5?'50%':'2px';
    c.style.width=(5+Math.random()*8)+'px';c.style.height=(5+Math.random()*10)+'px';
    c.style.animationDuration=(6+Math.random()*10)+'s';
    c.style.animationDelay=(Math.random()*12)+'s';
    confEl.appendChild(c);
  }

  // ── BALLOONS ──
  var ballEl=document.getElementById('balloons');
  var ballEmojis=['🎈','🎈','🎊','🎉','🎈'];
  for(var i=0;i<8;i++){
    var b=document.createElement('div');b.className='balloon';
    b.textContent=ballEmojis[Math.floor(Math.random()*ballEmojis.length)];
    b.style.left=Math.random()*100+'%';b.style.bottom='-30px';
    b.style.fontSize=(24+Math.random()*16)+'px';
    b.style.animationDuration=(14+Math.random()*18)+'s';
    b.style.animationDelay=(Math.random()*20)+'s';
    ballEl.appendChild(b);
  }

  // ── SPARKLE BURST ──
  function sparkBurst(cx,cy,n){
    var cols=['#00d4ff','#ff0080','#39ff14','#ffe600','#ff6600','#b84dff','#fff'];
    for(var i=0;i<(n||30);i++){
      var s=document.createElement('div');s.className='spark';
      s.style.left=cx+'px';s.style.top=cy+'px';
      var sz=3+Math.random()*6;s.style.width=sz+'px';s.style.height=sz+'px';
      var c=cols[Math.floor(Math.random()*cols.length)];
      s.style.background=c;s.style.boxShadow='0 0 10px '+c;
      document.body.appendChild(s);
      var a=Math.random()*Math.PI*2,d=50+Math.random()*200;
      gsap.to(s,{x:Math.cos(a)*d,y:Math.sin(a)*d,opacity:0,duration:.6+Math.random()*.5,ease:'power2.out',onComplete:function(){if(s.parentNode)s.remove()}});
    }
  }

  // ── SPLASH INTRO ──
  gsap.from('.sp-emoji',{opacity:0,scale:0,rotation:-30,duration:.8,delay:.2,ease:'elastic.out(1,.5)'});
  gsap.from('.sp-for',{opacity:0,y:10,duration:.4,delay:.7});
  gsap.from('.sp-name',{opacity:0,scale:.5,duration:.6,delay:1,ease:'back.out(2)'});
  gsap.from('.sp-sub',{opacity:0,y:8,duration:.4,delay:1.3});
  gsap.from('.sp-btn',{opacity:0,scale:.6,duration:.5,delay:1.5,ease:'elastic.out(1,.6)'});

  // ── OPEN ──
  document.getElementById('openBtn').addEventListener('click',function(){
    var splash=document.getElementById('splash'),main=document.getElementById('main');
    var cx=window.innerWidth/2,cy=window.innerHeight/2;
    var tl=gsap.timeline({onComplete:function(){splash.style.display='none';document.body.style.overflow='';initSR()}});
    tl.to('.sp-emoji',{scale:5,opacity:0,rotation:180,duration:.4,ease:'power2.in'});
    tl.add(function(){sparkBurst(cx,cy,100)},'-=.2');
    // Burst at multiple points
    tl.add(function(){sparkBurst(cx*.5,cy*.7,30);sparkBurst(cx*1.5,cy*.5,30)},'-=.1');
    tl.to('#splash > *:not(.sp-emoji)',{opacity:0,y:-15,duration:.25,stagger:.03},'-=.3');
    tl.to(splash,{opacity:0,duration:.3});
    tl.add(function(){main.classList.remove('hide')});
    tl.from(main,{opacity:0,y:20,duration:.5});
    tl.from('.hero-photo-circle',{opacity:0,scale:0,rotation:-15,duration:.6,ease:'elastic.out(1,.6)'},'-=.2');
    tl.from('.hero-wish',{opacity:0,y:20,duration:.4},'-=.1');
    tl.from('.hero-name',{opacity:0,y:10,duration:.3},'-=.1');
    tl.from('.hero-msg',{opacity:0,y:10,duration:.3},'-=.1');
  });

  // ── SCROLL ANIMATIONS ──
  function initSR(){
    gsap.registerPlugin(ScrollTrigger);
    document.querySelectorAll('.sec-title').forEach(function(t){
      gsap.from(t,{scrollTrigger:{trigger:t,start:'top 85%'},opacity:0,scale:.7,duration:.6,ease:'back.out(1.5)'});
    });
    gsap.from('.fun-card',{scrollTrigger:{trigger:'.fun-card',start:'top 80%'},opacity:0,y:35,rotation:-3,duration:.7,ease:'back.out(1.3)'});
    document.querySelectorAll('.col-item').forEach(function(c,i){
      gsap.from(c,{scrollTrigger:{trigger:c,start:'top 85%'},opacity:0,scale:.5,rotation:10*(i%2?1:-1),duration:.5,delay:i*.06,ease:'back.out(1.5)'});
    });
    document.querySelectorAll('.reason-card').forEach(function(r,i){
      gsap.from(r,{scrollTrigger:{trigger:r,start:'top 85%'},opacity:0,y:40,rotation:-5,duration:.5,delay:i*.07,ease:'back.out(1.3)'});
    });
    document.querySelectorAll('.mem-card').forEach(function(m,i){
      gsap.from(m,{scrollTrigger:{trigger:m,start:'top 85%'},opacity:0,x:40,scale:.8,duration:.5,delay:i*.06});
    });
    gsap.from('.close-emoji',{scrollTrigger:{trigger:'.close-emoji',start:'top 85%'},opacity:0,scale:0,rotation:30,duration:.7,ease:'elastic.out(1,.5)'});
  }

  // ── HOVER EFFECTS ──
  document.querySelectorAll('.col-item,.reason-card,.fun-card,.mem-card,.hero-photo-circle').forEach(function(el){
    el.addEventListener('mousemove',function(e){
      var r=el.getBoundingClientRect();
      var ry=((e.clientX-r.left-r.width/2)/(r.width/2))*12;
      var rx=((r.height/2-(e.clientY-r.top))/(r.height/2))*8;
      el.style.transform='perspective(600px) rotateY('+ry+'deg) rotateX('+rx+'deg) translateZ(12px)';
      el.style.transition='transform .08s ease';
    });
    el.addEventListener('mouseleave',function(){el.style.transition='transform .4s ease';el.style.transform=''});
  });

  document.addEventListener('click',function(e){
    if(e.target.closest('.col-item,.reason-card,.mem-card,.hero-photo-circle'))sparkBurst(e.clientX,e.clientY,20);
  });

  // ── CHIPTUNE MUSIC (Web Audio) ──
  var audioCtx=null, musicPlaying=false, musicInterval=null;

  function playChiptune(){
    if(!audioCtx)audioCtx=new(window.AudioContext||window.webkitAudioContext)();
    var notes=[
      {f:523,d:.15},{f:659,d:.15},{f:784,d:.15},{f:1047,d:.3},{f:0,d:.15},
      {f:784,d:.15},{f:659,d:.15},{f:523,d:.3},{f:0,d:.15},
      {f:440,d:.15},{f:523,d:.15},{f:659,d:.15},{f:784,d:.3},{f:0,d:.15},
      {f:659,d:.15},{f:523,d:.15},{f:440,d:.15},{f:523,d:.4},{f:0,d:.3},
      {f:698,d:.15},{f:880,d:.15},{f:1047,d:.15},{f:880,d:.15},{f:698,d:.3},{f:0,d:.15},
      {f:523,d:.15},{f:659,d:.15},{f:784,d:.15},{f:1047,d:.6}
    ];
    var t=audioCtx.currentTime+.1;
    notes.forEach(function(n){
      if(n.f>0){
        var osc=audioCtx.createOscillator(),gain=audioCtx.createGain();
        osc.type='square';
        osc.frequency.setValueAtTime(n.f,t);
        gain.gain.setValueAtTime(0,t);
        gain.gain.linearRampToValueAtTime(.04,t+.02);
        gain.gain.exponentialRampToValueAtTime(.001,t+n.d);
        osc.connect(gain);gain.connect(audioCtx.destination);
        osc.start(t);osc.stop(t+n.d+.05);
      }
      t+=n.d;
    });
    return t-audioCtx.currentTime;
  }

  function toggleMusic(){
    if(musicPlaying){
      musicPlaying=false;if(musicInterval)clearInterval(musicInterval);
      document.getElementById('musicBtn').innerHTML='<i class="fa-solid fa-volume-xmark"></i>';
    }else{
      musicPlaying=true;
      var dur=playChiptune();
      musicInterval=setInterval(function(){if(musicPlaying)playChiptune()},dur*1000+500);
      document.getElementById('musicBtn').innerHTML='<i class="fa-solid fa-music"></i>';
    }
  }
  document.getElementById('musicBtn').addEventListener('click',toggleMusic);

  document.body.style.overflow='hidden';
})();
