/* ============================================================
   "ETERNAL BLOOM" — Ultra-Premium Wedding Invitation Engine
   Lotus Opening · Floating Rose Petals · Gold Particles ·
   Photo Galleries · Sitar Ambiance · 3D Cards · Mandala Art ·
   Scroll Reveals · Animated Countdown · Ornate Frames
   ============================================================ */
(function () {
  'use strict';

  /* ==========================================================
     CONFIGURATION — Easy to customize
     ========================================================== */
  var C = {
    bride: 'Ishita',
    groom: 'Kabir',
    brideFull: 'Maharani Ishita',
    groomFull: 'Maharaj Kabir',
    brideFamily: 'House Sharma',
    groomFamily: 'House Kapoor',
    brideFather: 'Shri Rajendra Sharma',
    brideMother: 'Smt. Kavita Sharma',
    groomFather: 'Shri Vikram Kapoor',
    groomMother: 'Smt. Meera Kapoor',
    weddingDate: 'December 20, 2026',
    weddingDay: 'Saturday',
    weddingTime: '11:00 AM',
    venue: 'The Royal Palace, Jaipur',
    hashtag: '#IshitaWedsKabir',
    events: [
      { name: 'Haldi', emoji: '🌼', date: 'Dec 18, 2026', time: '10:00 AM', place: 'Sharma Haveli, Jaipur', desc: 'Sacred turmeric blessings for radiance and prosperity.', color: '#f59e0b' },
      { name: 'Mehendi', emoji: '✋', date: 'Dec 18, 2026', time: '5:00 PM', place: "The Queen's Garden", desc: 'An evening of intricate henna artistry under the stars.', color: '#10b981' },
      { name: 'Sangeet', emoji: '🎶', date: 'Dec 19, 2026', time: '7:00 PM', place: 'Grand Durbar Hall', desc: 'A magical night of dance, music and celebration.', color: '#8b5cf6' },
      { name: 'Wedding', emoji: '💍', date: 'Dec 20, 2026', time: '9:00 AM Baraat · 11 AM Pheras', place: 'Royal Lakshmi Temple', desc: 'The sacred union — two souls become one forever.', color: '#ef4444' },
      { name: 'Reception', emoji: '🥂', date: 'Dec 20, 2026', time: '7:00 PM', place: 'The Palace Ballroom', desc: 'A grand evening banquet to honor the newlyweds.', color: '#3b82f6' }
    ]
  };

  /* ==========================================================
     INJECT ADDITIONAL GOOGLE FONTS
     ========================================================== */
  function injectFonts() {
    var fonts = [
      'https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,700;0,900;1,400&family=Dancing+Script:wght@400;700&family=Cormorant+Garamond:ital,wght@0,300;0,400;0,600;1,300;1,400&family=Abril+Fatface&family=Cinzel+Decorative:wght@400;700;900&family=Great+Vibes&family=EB+Garamond:ital,wght@0,400;0,600;1,400&family=Noto+Sans+Devanagari:wght@400;600&display=swap',
      'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css'
    ];
    fonts.forEach(function (url) {
      var l = document.createElement('link');
      l.rel = 'stylesheet';
      l.href = url;
      document.head.appendChild(l);
    });
  }

  /* ==========================================================
     INJECT ALL CSS STYLES
     ========================================================== */
  function injectStyles() {
    var css = `
/* ---- RESET & BASE ---- */
*,*::before,*::after{margin:0;padding:0;box-sizing:border-box}
html{scroll-behavior:smooth}
body{
  font-family:'EB Garamond','Cormorant Garamond',serif;
  background:#080810;color:#f5efe0;
  overflow-x:hidden;min-height:100vh;
}
.eb-hidden{display:none!important}

/* ---- CSS VARIABLES ---- */
:root{
  --bg:#080810;--bg2:#0e0e1c;--bg3:#14142a;
  --gold:#d4a54a;--gold-lt:#f0d48a;--gold-br:#ffd700;--gold-dk:#a07830;
  --rose:#e84393;--rose-lt:#fd79a8;
  --cream:#f5efe0;--muted:#a09882;
  --emerald:#2dd4a8;--saffron:#ff9f43;--purple:#9b59b6;
  --font-display:'Playfair Display',serif;
  --font-script:'Great Vibes',cursive;
  --font-royal:'Cinzel Decorative',serif;
  --font-heading:'Cinzel',serif;
  --font-body:'EB Garamond',serif;
  --font-dancing:'Dancing Script',cursive;
}

/* ---- FLOATING GOLD PARTICLES ---- */
#eb-particles{position:fixed;inset:0;pointer-events:none;z-index:1;overflow:hidden}
.eb-ptcl{
  position:absolute;border-radius:50%;
  background:var(--gold-lt);
  box-shadow:0 0 8px var(--gold),0 0 20px rgba(212,165,74,.3);
  pointer-events:none;opacity:0;
  animation:ebFloat linear infinite;
}
@keyframes ebFloat{
  0%{transform:translateY(0) translateX(0) scale(1) rotate(0);opacity:0}
  6%{opacity:.7}
  50%{transform:translateY(-55vh) translateX(35px) scale(.6) rotate(180deg);opacity:.35}
  100%{transform:translateY(-110vh) translateX(-25px) scale(.15) rotate(360deg);opacity:0}
}

/* ---- FLOATING PETALS ---- */
#eb-petals{position:fixed;inset:0;pointer-events:none;z-index:2;overflow:hidden}
.eb-petal{
  position:absolute;width:18px;height:18px;
  pointer-events:none;opacity:0;
  animation:ebPetalFall linear infinite;
}
.eb-petal::before{
  content:'';display:block;width:100%;height:100%;
  border-radius:60% 0 60% 0;
  transform:rotate(45deg);
}
.eb-petal.p-rose::before{background:linear-gradient(135deg,#e84393,#fd79a8)}
.eb-petal.p-gold::before{background:linear-gradient(135deg,#d4a54a,#f0d48a)}
.eb-petal.p-pink::before{background:linear-gradient(135deg,#ff6b9d,#ffb8d0)}
.eb-petal.p-peach::before{background:linear-gradient(135deg,#ff9f43,#feca57)}
.eb-petal.p-lav::before{background:linear-gradient(135deg,#a855f7,#c084fc)}
@keyframes ebPetalFall{
  0%{transform:translateY(-20px) translateX(0) rotate(0) scale(1);opacity:0}
  5%{opacity:.8}
  25%{transform:translateY(25vh) translateX(60px) rotate(90deg) scale(.9)}
  50%{transform:translateY(50vh) translateX(-40px) rotate(200deg) scale(.75);opacity:.6}
  75%{transform:translateY(75vh) translateX(50px) rotate(310deg) scale(.6)}
  100%{transform:translateY(105vh) translateX(-30px) rotate(400deg) scale(.4);opacity:0}
}

/* ---- SPLASH / OPENING SCREEN ---- */
#eb-splash{
  position:fixed;inset:0;z-index:1000;
  display:flex;align-items:center;justify-content:center;flex-direction:column;
  background:
    radial-gradient(ellipse at 50% 40%,rgba(212,165,74,.06) 0%,transparent 60%),
    radial-gradient(ellipse at 30% 70%,rgba(232,67,147,.04) 0%,transparent 50%),
    linear-gradient(180deg,#080810 0%,#0e0e1c 50%,#080810 100%);
  overflow:hidden;
}
#eb-splash::before{
  content:'';position:absolute;inset:0;
  background:repeating-linear-gradient(45deg,transparent 0px,transparent 80px,rgba(212,165,74,.012) 80px,rgba(212,165,74,.012) 82px);
  pointer-events:none;
}

/* Mandala */
.eb-mandala{
  width:280px;height:280px;position:relative;margin-bottom:30px;
  animation:ebMandalaSpin 30s linear infinite;
}
@keyframes ebMandalaSpin{to{transform:rotate(360deg)}}
.eb-mandala svg{width:100%;height:100%}
.eb-mandala-ring{
  fill:none;stroke:var(--gold);stroke-width:.7;opacity:.4;
  transform-origin:center;
}
.eb-mandala-ring:nth-child(2){stroke:var(--rose);opacity:.3;animation:ebMandalaSpin 25s linear infinite reverse}
.eb-mandala-ring:nth-child(3){stroke:var(--gold-lt);opacity:.25;animation:ebMandalaSpin 35s linear infinite}

/* Lotus */
.eb-lotus{
  position:absolute;top:50%;left:50%;
  transform:translate(-50%,-50%);
  width:140px;height:140px;
}
.lotus-petal{
  position:absolute;width:36px;height:60px;
  left:50%;top:50%;
  transform-origin:center bottom;
  border-radius:50% 50% 0 0;
  opacity:0;
  transition:all 1.2s cubic-bezier(.34,1.56,.64,1);
}
.lotus-petal.bloom{opacity:1;transform:translateX(-50%) translateY(-100%) rotate(var(--r)) scale(1)!important}

.eb-splash-hindi{
  font-family:'Noto Sans Devanagari',sans-serif;
  font-size:clamp(14px,3.5vw,20px);
  color:var(--gold);letter-spacing:3px;
  margin-bottom:12px;text-shadow:0 0 20px rgba(212,165,74,.4);
  opacity:0;animation:ebFadeUp 1s .5s forwards;
}
.eb-splash-names{
  font-family:var(--font-script);
  font-size:clamp(42px,11vw,72px);
  background:linear-gradient(135deg,var(--gold),var(--gold-lt),var(--rose-lt),var(--gold));
  background-size:300% 300%;
  -webkit-background-clip:text;-webkit-text-fill-color:transparent;
  background-clip:text;
  animation:ebGoldShimmer 4s ease infinite,ebFadeUp 1s .8s forwards;
  opacity:0;
}
@keyframes ebGoldShimmer{0%{background-position:0% 50%}50%{background-position:100% 50%}100%{background-position:0% 50%}}
@keyframes ebFadeUp{to{opacity:1;transform:translateY(0)}}

.eb-splash-subtitle{
  font-family:var(--font-heading);
  font-size:clamp(10px,2.5vw,14px);
  color:var(--muted);letter-spacing:5px;text-transform:uppercase;
  margin-top:8px;opacity:0;animation:ebFadeUp 1s 1.1s forwards;
}

.eb-open-btn{
  margin-top:35px;padding:16px 50px;
  border:2px solid var(--gold);border-radius:50px;
  background:linear-gradient(135deg,rgba(212,165,74,.1),rgba(232,67,147,.05));
  color:var(--gold-lt);cursor:pointer;
  font-family:var(--font-royal);font-size:clamp(11px,2.5vw,14px);
  letter-spacing:4px;text-transform:uppercase;
  position:relative;overflow:hidden;
  transition:all .4s ease;
  opacity:0;animation:ebFadeUp 1s 1.4s forwards,ebBtnPulse 2s 2.5s infinite;
  box-shadow:0 0 30px rgba(212,165,74,.15),inset 0 0 30px rgba(212,165,74,.05);
}
.eb-open-btn:hover{
  background:linear-gradient(135deg,rgba(212,165,74,.25),rgba(232,67,147,.1));
  box-shadow:0 0 50px rgba(212,165,74,.3),inset 0 0 50px rgba(212,165,74,.1);
  transform:scale(1.05);
}
@keyframes ebBtnPulse{
  0%,100%{box-shadow:0 0 30px rgba(212,165,74,.15),inset 0 0 30px rgba(212,165,74,.05)}
  50%{box-shadow:0 0 50px rgba(212,165,74,.35),inset 0 0 50px rgba(212,165,74,.1)}
}

/* ---- SPARK BURST ---- */
.eb-spark{
  position:fixed;border-radius:50%;pointer-events:none;z-index:1001;
  background:var(--gold-lt);
  box-shadow:0 0 6px var(--gold);
}

/* ---- MAIN INVITATION ---- */
#eb-main{position:relative;z-index:5}

/* Ornate section frame */
.eb-section{
  position:relative;padding:80px 20px;
  overflow:hidden;
}
.eb-section::before{
  content:'';position:absolute;inset:20px;
  border:1px solid rgba(212,165,74,.12);
  border-radius:8px;pointer-events:none;
}

/* Section backgrounds */
.eb-sec-dark{background:var(--bg)}
.eb-sec-deep{background:var(--bg2)}
.eb-sec-rich{background:linear-gradient(180deg,var(--bg) 0%,var(--bg3) 50%,var(--bg) 100%)}

/* Ornate corners for sections */
.eb-corner{
  position:absolute;width:40px;height:40px;z-index:3;
  pointer-events:none;
}
.eb-corner::before,.eb-corner::after{
  content:'';position:absolute;background:var(--gold);
}
.eb-corner::before{width:100%;height:1px}
.eb-corner::after{width:1px;height:100%}
.eb-c-tl{top:12px;left:12px}.eb-c-tl::before{top:0;left:0}.eb-c-tl::after{top:0;left:0}
.eb-c-tr{top:12px;right:12px}.eb-c-tr::before{top:0;right:0}.eb-c-tr::after{top:0;right:0}
.eb-c-bl{bottom:12px;left:12px}.eb-c-bl::before{bottom:0;left:0}.eb-c-bl::after{bottom:0;left:0}
.eb-c-br{bottom:12px;right:12px}.eb-c-br::before{bottom:0;right:0}.eb-c-br::after{bottom:0;right:0}

/* Section titles */
.eb-title{
  font-family:var(--font-royal);
  font-size:clamp(22px,5vw,38px);
  text-align:center;
  background:linear-gradient(135deg,var(--gold),var(--gold-lt),var(--gold));
  -webkit-background-clip:text;-webkit-text-fill-color:transparent;
  background-clip:text;
  letter-spacing:3px;margin-bottom:10px;
}
.eb-subtitle{
  font-family:var(--font-body);font-style:italic;
  font-size:clamp(14px,3vw,18px);
  color:var(--muted);text-align:center;
  margin-bottom:50px;
}

/* Ornate divider */
.eb-divider{
  display:flex;align-items:center;justify-content:center;
  gap:15px;margin:20px auto 30px;width:fit-content;
}
.eb-div-line{width:80px;height:1px;background:linear-gradient(90deg,transparent,var(--gold),transparent)}
.eb-div-gem{color:var(--gold);font-size:18px}

/* ---- HERO SECTION ---- */
#eb-hero{
  min-height:100vh;display:flex;align-items:center;justify-content:center;
  flex-direction:column;text-align:center;padding:60px 20px;
  background:
    radial-gradient(ellipse at 50% 30%,rgba(212,165,74,.05) 0%,transparent 60%),
    radial-gradient(ellipse at 70% 80%,rgba(232,67,147,.03) 0%,transparent 50%),
    var(--bg);
}
.eb-hero-badge{
  font-family:'Noto Sans Devanagari',sans-serif;
  font-size:clamp(14px,3vw,20px);
  color:var(--gold);letter-spacing:3px;
  text-shadow:0 0 20px rgba(212,165,74,.3);
  margin-bottom:30px;
}
.eb-hero-photos{
  display:flex;align-items:center;justify-content:center;
  gap:clamp(20px,5vw,60px);
  margin-bottom:30px;flex-wrap:wrap;
}

/* Photo placeholder styling */
.eb-photo{
  position:relative;border-radius:50%;overflow:hidden;
  display:flex;align-items:center;justify-content:center;flex-direction:column;
  cursor:pointer;transition:transform .4s ease,box-shadow .4s ease;
}
.eb-photo:hover{transform:scale(1.05);box-shadow:0 0 50px rgba(212,165,74,.4)}
.eb-photo-lg{
  width:clamp(150px,30vw,210px);height:clamp(150px,30vw,210px);
  border:3px solid var(--gold);
  box-shadow:0 0 30px rgba(212,165,74,.2),inset 0 0 40px rgba(0,0,0,.5);
  background:linear-gradient(135deg,#1a1028,#12101e,#1a0e20);
}
.eb-photo-icon{font-size:32px;color:var(--gold);opacity:.5;margin-bottom:6px}
.eb-photo-label{
  font-family:var(--font-heading);font-size:10px;
  color:var(--gold);opacity:.5;letter-spacing:2px;text-transform:uppercase;
}
.eb-photo img{width:100%;height:100%;object-fit:cover;position:absolute;inset:0;border-radius:inherit}

/* Glow ring around photos */
.eb-photo::after{
  content:'';position:absolute;inset:-6px;
  border-radius:50%;border:1px solid rgba(212,165,74,.2);
  animation:ebRingPulse 3s ease-in-out infinite;
}
@keyframes ebRingPulse{
  0%,100%{opacity:.3;transform:scale(1)}
  50%{opacity:.6;transform:scale(1.03)}
}

.eb-hero-ampersand{
  font-family:var(--font-script);
  font-size:clamp(48px,10vw,80px);
  background:linear-gradient(180deg,var(--rose),var(--gold-lt));
  -webkit-background-clip:text;-webkit-text-fill-color:transparent;
  background-clip:text;
  margin:0 10px;
  animation:ebPulseGentle 3s ease-in-out infinite;
}
@keyframes ebPulseGentle{0%,100%{transform:scale(1)}50%{transform:scale(1.08)}}

.eb-hero-names{
  font-family:var(--font-script);
  font-size:clamp(48px,12vw,82px);
  background:linear-gradient(135deg,var(--gold),var(--gold-lt),#fff,var(--gold-lt),var(--gold));
  background-size:400% 400%;
  -webkit-background-clip:text;-webkit-text-fill-color:transparent;
  background-clip:text;
  animation:ebGoldShimmer 5s ease infinite;
  margin-bottom:15px;line-height:1.2;
}
.eb-hero-tagline{
  font-family:var(--font-body);font-style:italic;
  font-size:clamp(16px,3.5vw,22px);
  color:var(--muted);margin-bottom:20px;
}
.eb-hero-date{
  font-family:var(--font-heading);
  font-size:clamp(13px,2.8vw,18px);
  letter-spacing:4px;text-transform:uppercase;
  color:var(--gold);
}
.eb-hero-venue{
  font-family:var(--font-body);font-style:italic;
  font-size:clamp(14px,3vw,18px);color:var(--muted);margin-top:6px;
}

/* ---- FAMILIES SECTION ---- */
.eb-families{
  display:flex;align-items:stretch;justify-content:center;
  gap:clamp(20px,4vw,50px);flex-wrap:wrap;
  max-width:900px;margin:0 auto;
}
.eb-family-card{
  flex:1;min-width:260px;max-width:380px;
  background:linear-gradient(145deg,rgba(20,20,42,.9),rgba(14,14,28,.95));
  border:1px solid rgba(212,165,74,.15);
  border-radius:16px;padding:35px 25px;text-align:center;
  position:relative;overflow:hidden;
  transition:transform .4s ease,box-shadow .4s ease;
}
.eb-family-card:hover{
  transform:translateY(-5px);
  box-shadow:0 20px 50px rgba(0,0,0,.4),0 0 30px rgba(212,165,74,.1);
}
.eb-family-card::before{
  content:'';position:absolute;top:0;left:50%;transform:translateX(-50%);
  width:60%;height:2px;
  background:linear-gradient(90deg,transparent,var(--gold),transparent);
}
.eb-family-emoji{font-size:42px;margin-bottom:12px;display:block}
.eb-family-name{
  font-family:var(--font-royal);font-size:clamp(14px,2.8vw,18px);
  color:var(--gold);letter-spacing:2px;margin-bottom:8px;
}
.eb-family-parents{
  font-family:var(--font-body);font-size:15px;
  color:var(--cream);line-height:1.8;margin-bottom:12px;
}
.eb-family-present{
  font-family:var(--font-body);font-style:italic;
  font-size:14px;color:var(--muted);margin-bottom:8px;
}
.eb-family-person{
  font-family:var(--font-script);
  font-size:clamp(28px,6vw,40px);
}
.eb-bride-color{color:var(--rose-lt)}
.eb-groom-color{color:var(--emerald)}

/* ---- COUPLE / STORY SECTION ---- */
.eb-story-grid{
  display:grid;
  grid-template-columns:repeat(auto-fit,minmax(280px,1fr));
  gap:40px;max-width:1000px;margin:0 auto;
  align-items:center;
}
.eb-photo-rect{
  width:100%;aspect-ratio:4/5;border-radius:16px;overflow:hidden;
  border:2px solid rgba(212,165,74,.2);
  background:linear-gradient(145deg,#1a1028,#12101e);
  display:flex;align-items:center;justify-content:center;flex-direction:column;
  position:relative;cursor:pointer;
  box-shadow:0 10px 40px rgba(0,0,0,.4);
  transition:transform .4s ease,box-shadow .4s ease;
}
.eb-photo-rect:hover{
  transform:scale(1.03);
  box-shadow:0 15px 50px rgba(0,0,0,.5),0 0 30px rgba(212,165,74,.15);
}
.eb-photo-rect img{width:100%;height:100%;object-fit:cover;position:absolute;inset:0}
.eb-story-text{
  text-align:center;
}
.eb-story-text h3{
  font-family:var(--font-script);
  font-size:clamp(32px,7vw,48px);
  color:var(--gold-lt);margin-bottom:16px;
}
.eb-story-text p{
  font-family:var(--font-body);
  font-size:clamp(15px,3vw,18px);
  color:var(--cream);line-height:1.8;
  opacity:.85;
}
.eb-story-text .eb-quote{
  font-style:italic;color:var(--rose-lt);margin-top:20px;
  font-size:clamp(16px,3.2vw,20px);
}

/* ---- EVENTS SECTION ---- */
.eb-events-grid{
  display:grid;
  grid-template-columns:repeat(auto-fit,minmax(280px,1fr));
  gap:30px;max-width:1200px;margin:0 auto;
}
.eb-event-card{
  position:relative;border-radius:20px;overflow:hidden;
  background:linear-gradient(180deg,rgba(20,20,42,.95),rgba(8,8,16,.98));
  border:1px solid rgba(212,165,74,.1);
  transition:transform .5s ease,box-shadow .5s ease;
  cursor:pointer;
  perspective:800px;
}
.eb-event-card:hover{
  transform:translateY(-8px) scale(1.02);
  box-shadow:0 25px 60px rgba(0,0,0,.5),0 0 40px rgba(212,165,74,.12);
}
.eb-event-img{
  width:100%;aspect-ratio:16/10;overflow:hidden;
  background:linear-gradient(145deg,#1a1028,#0e0e1c);
  display:flex;align-items:center;justify-content:center;flex-direction:column;
  position:relative;
}
.eb-event-img img{width:100%;height:100%;object-fit:cover;position:absolute;inset:0}
.eb-event-color-bar{
  position:absolute;bottom:0;left:0;right:0;height:4px;
}
.eb-event-content{padding:24px 20px}
.eb-event-emoji{font-size:28px;margin-bottom:8px;display:block}
.eb-event-name{
  font-family:var(--font-royal);
  font-size:clamp(16px,3.5vw,22px);
  color:var(--gold-lt);letter-spacing:2px;margin-bottom:10px;
}
.eb-event-detail{
  font-family:var(--font-body);
  font-size:14px;color:var(--muted);
  display:flex;align-items:center;gap:8px;
  margin-bottom:6px;
}
.eb-event-detail i{color:var(--gold);width:16px;text-align:center;font-size:12px}
.eb-event-desc{
  font-family:var(--font-body);font-style:italic;
  font-size:15px;color:var(--cream);opacity:.75;
  margin-top:12px;line-height:1.6;
}

/* ---- GALLERY SECTION ---- */
.eb-gallery-grid{
  display:grid;
  grid-template-columns:repeat(auto-fit,minmax(200px,1fr));
  gap:20px;max-width:1000px;margin:0 auto;
}
.eb-gallery-item{
  aspect-ratio:1;border-radius:16px;overflow:hidden;
  border:1px solid rgba(212,165,74,.12);
  background:linear-gradient(145deg,#1a1028,#0e0e1c);
  display:flex;align-items:center;justify-content:center;flex-direction:column;
  position:relative;cursor:pointer;
  transition:transform .4s ease,box-shadow .4s ease;
}
.eb-gallery-item:hover{
  transform:scale(1.05);
  box-shadow:0 10px 40px rgba(0,0,0,.5),0 0 25px rgba(212,165,74,.15);
}
.eb-gallery-item img{width:100%;height:100%;object-fit:cover;position:absolute;inset:0}

/* ---- COUNTDOWN ---- */
.eb-countdown{
  display:flex;align-items:center;justify-content:center;
  gap:clamp(12px,3vw,30px);flex-wrap:wrap;
  margin:40px auto 0;
}
.eb-cd-block{text-align:center}
.eb-cd-num{
  display:block;font-family:var(--font-display);
  font-size:clamp(36px,8vw,60px);font-weight:700;
  background:linear-gradient(180deg,var(--gold-lt),var(--gold));
  -webkit-background-clip:text;-webkit-text-fill-color:transparent;
  background-clip:text;
  line-height:1;
}
.eb-cd-label{
  font-family:var(--font-heading);
  font-size:clamp(10px,2vw,13px);
  color:var(--muted);letter-spacing:3px;text-transform:uppercase;
  margin-top:4px;
}
.eb-cd-sep{
  font-size:clamp(28px,6vw,48px);
  color:rgba(212,165,74,.3);font-weight:300;
  align-self:flex-start;margin-top:5px;
}

/* ---- CLOSING SECTION ---- */
.eb-closing-quote{
  font-family:var(--font-body);font-style:italic;
  font-size:clamp(18px,4vw,26px);
  color:var(--cream);text-align:center;
  max-width:600px;margin:0 auto 40px;line-height:1.6;
  opacity:.85;
}
.eb-closing-crest{
  text-align:center;font-size:clamp(24px,5vw,36px);
  margin-bottom:30px;
}
.eb-crest-letter{
  font-family:var(--font-script);
  font-size:clamp(40px,8vw,60px);
  color:var(--gold-lt);
}
.eb-crest-crown{
  font-size:clamp(28px,5vw,40px);margin:0 12px;
  display:inline-block;
  animation:ebPulseGentle 3s ease-in-out infinite;
}
.eb-closing-msg{
  font-family:var(--font-body);
  font-size:clamp(15px,3vw,19px);
  color:var(--cream);text-align:center;
  max-width:500px;margin:0 auto 25px;line-height:1.7;
  opacity:.8;
}
.eb-hashtag{
  font-family:var(--font-dancing);
  font-size:clamp(26px,6vw,42px);
  text-align:center;
  background:linear-gradient(135deg,var(--rose),var(--gold-lt),var(--emerald));
  -webkit-background-clip:text;-webkit-text-fill-color:transparent;
  background-clip:text;
  margin-bottom:30px;
}
.eb-ornament{
  text-align:center;color:var(--gold);
  font-size:18px;letter-spacing:12px;margin-bottom:25px;
}
.eb-signed{
  font-family:var(--font-body);font-style:italic;
  font-size:15px;color:var(--muted);text-align:center;
  line-height:1.8;
}
.eb-stamp{
  width:90px;height:90px;margin:35px auto 0;
  border:2px solid var(--gold);border-radius:50%;
  display:flex;align-items:center;justify-content:center;
  font-family:var(--font-heading);
  font-size:10px;color:var(--gold);text-align:center;
  letter-spacing:1px;line-height:1.4;
  position:relative;
  box-shadow:0 0 20px rgba(212,165,74,.15);
}
.eb-stamp::before{
  content:'';position:absolute;inset:4px;
  border:1px dashed rgba(212,165,74,.3);border-radius:50%;
}

/* ---- MUSIC TOGGLE ---- */
#eb-music{
  position:fixed;bottom:20px;right:20px;z-index:100;
  width:50px;height:50px;border-radius:50%;border:1px solid var(--gold);
  background:rgba(8,8,16,.85);backdrop-filter:blur(10px);
  color:var(--gold);font-size:20px;cursor:pointer;
  transition:all .3s ease;
  display:flex;align-items:center;justify-content:center;
  box-shadow:0 4px 20px rgba(0,0,0,.4);
}
#eb-music:hover{background:rgba(212,165,74,.15);transform:scale(1.1)}
#eb-music.playing{animation:ebMusicPulse 1.5s ease-in-out infinite}
@keyframes ebMusicPulse{
  0%,100%{box-shadow:0 4px 20px rgba(0,0,0,.4)}
  50%{box-shadow:0 4px 20px rgba(212,165,74,.4),0 0 30px rgba(212,165,74,.2)}
}

/* ---- SCROLL INDICATOR ---- */
.eb-scroll-hint{
  position:absolute;bottom:30px;left:50%;transform:translateX(-50%);
  text-align:center;
  animation:ebBounce 2s ease-in-out infinite;
}
.eb-scroll-hint i{color:var(--gold);font-size:20px;opacity:.5}
@keyframes ebBounce{0%,100%{transform:translateX(-50%) translateY(0)}50%{transform:translateX(-50%) translateY(8px)}}

/* ---- RESPONSIVE ---- */
@media(max-width:768px){
  .eb-hero-photos{gap:15px}
  .eb-photo-lg{width:clamp(120px,35vw,160px);height:clamp(120px,35vw,160px)}
  .eb-families{flex-direction:column;align-items:center}
  .eb-family-card{min-width:auto;width:100%;max-width:340px}
  .eb-story-grid{grid-template-columns:1fr}
  .eb-events-grid{grid-template-columns:1fr}
  .eb-gallery-grid{grid-template-columns:repeat(2,1fr)}
  .eb-section{padding:60px 16px}
}
@media(max-width:480px){
  .eb-photo-lg{width:120px;height:120px}
  .eb-gallery-grid{grid-template-columns:repeat(2,1fr);gap:12px}
}
`;
    var style = document.createElement('style');
    style.textContent = css;
    document.head.appendChild(style);
  }

  /* ==========================================================
     AUDIO ENGINE (Web Audio API)
     ========================================================== */
  var audioCtx = null;
  function ac() {
    if (!audioCtx) audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    return audioCtx;
  }

  function tone(freq, dur, type, vol) {
    try {
      var c = ac(), o = c.createOscillator(), g = c.createGain();
      o.connect(g); g.connect(c.destination);
      o.type = type || 'sine';
      o.frequency.value = freq;
      g.gain.setValueAtTime(vol || 0.06, c.currentTime);
      g.gain.exponentialRampToValueAtTime(0.001, c.currentTime + dur);
      o.start(); o.stop(c.currentTime + dur);
    } catch (_) {}
  }

  /* Shehnai-like melody (Indian wedding instrument) */
  function playShehnai() {
    var melody = [
      { f: 523.25, d: 0.6, delay: 0 },     // C5
      { f: 587.33, d: 0.4, delay: 400 },    // D5
      { f: 659.25, d: 0.5, delay: 700 },    // E5
      { f: 698.46, d: 0.8, delay: 1000 },   // F5
      { f: 659.25, d: 0.3, delay: 1500 },   // E5
      { f: 587.33, d: 0.4, delay: 1700 },   // D5
      { f: 523.25, d: 1.2, delay: 2000 },   // C5 (hold)
      { f: 783.99, d: 0.6, delay: 2800 },   // G5
      { f: 698.46, d: 0.4, delay: 3200 },   // F5
      { f: 659.25, d: 0.8, delay: 3500 },   // E5
      { f: 523.25, d: 1.5, delay: 4000 },   // C5 (final)
    ];
    melody.forEach(function (n) {
      setTimeout(function () {
        tone(n.f, n.d + 0.5, 'sawtooth', 0.025);
        tone(n.f * 1.005, n.d + 0.5, 'sawtooth', 0.015); // slight detune for richness
        tone(n.f * 2, n.d + 0.3, 'sine', 0.012); // overtone
      }, n.delay);
    });
  }

  /* Temple bells */
  function playBells() {
    var freqs = [1174.66, 1396.91, 1567.98];
    freqs.forEach(function (f, i) {
      setTimeout(function () { tone(f, 1.5, 'sine', 0.05); }, i * 200);
    });
  }

  /* Gentle chime */
  function playChime() {
    tone(1318.51, 0.8, 'sine', 0.04);
    setTimeout(function () { tone(1567.98, 0.6, 'sine', 0.03); }, 100);
    setTimeout(function () { tone(2093.00, 0.5, 'sine', 0.025); }, 200);
  }

  /* Sparkle sound */
  function playSparkle() {
    [1318.51, 1567.98, 2093.00, 2637.02, 3135.96].forEach(function (f, i) {
      setTimeout(function () { tone(f, 0.4, 'sine', 0.03); }, i * 60);
    });
  }

  /* Soft tinkle */
  function playTinkle() {
    tone(1800 + Math.random() * 1200, 0.15, 'sine', 0.02);
  }

  /* Ambient sitar + tanpura drone */
  var ambientNodes = [], ambientPlaying = false;
  function startAmbient() {
    if (ambientPlaying) return;
    try {
      var c = ac();
      // Tanpura drone (Sa + Pa)
      [130.81, 196.00, 261.63].forEach(function (f) {
        var o = c.createOscillator(), g = c.createGain();
        o.type = 'sine'; o.frequency.value = f;
        o.connect(g); g.connect(c.destination);
        g.gain.value = 0.012;
        o.start();
        ambientNodes.push({ o: o, g: g });
      });
      // Shimmery sitar harmonics
      [523.25, 659.25, 783.99, 1046.50].forEach(function (f, i) {
        var o = c.createOscillator(), g = c.createGain();
        var lfo = c.createOscillator(), lg = c.createGain();
        o.type = 'triangle'; o.frequency.value = f;
        lfo.type = 'sine'; lfo.frequency.value = 0.08 + i * 0.02;
        lg.gain.value = 0.006;
        lfo.connect(lg); lg.connect(g.gain);
        o.connect(g); g.connect(c.destination);
        g.gain.value = 0.008;
        o.start(); lfo.start();
        ambientNodes.push({ o: o, g: g, l: lfo });
      });
      // Warm pad
      [261.63, 329.63].forEach(function (f) {
        var o = c.createOscillator(), g = c.createGain();
        o.type = 'sine'; o.frequency.value = f;
        o.connect(g); g.connect(c.destination);
        g.gain.value = 0.01;
        o.start();
        ambientNodes.push({ o: o, g: g });
      });
      ambientPlaying = true;
    } catch (_) {}
  }

  function stopAmbient() {
    ambientNodes.forEach(function (n) {
      try { n.o.stop(); if (n.l) n.l.stop(); } catch (_) {}
    });
    ambientNodes = [];
    ambientPlaying = false;
  }

  /* ==========================================================
     BUILD HTML — Generate the entire page
     ========================================================== */
  function buildPage() {
    document.body.innerHTML = '';
    document.body.style.overflow = 'hidden';

    var html = '';

    /* -- Particles container -- */
    html += '<div id="eb-particles"></div>';
    html += '<div id="eb-petals"></div>';

    /* -- SPLASH / OPENING -- */
    html += '<section id="eb-splash">';
    html += '  <div class="eb-mandala">';
    html += '    <svg viewBox="0 0 280 280">';
    // Mandala rings
    for (var r = 0; r < 5; r++) {
      var radius = 50 + r * 25;
      var dashLen = 3 + r * 2;
      html += '<circle class="eb-mandala-ring" cx="140" cy="140" r="' + radius + '" stroke-dasharray="' + dashLen + ' ' + (dashLen + 2) + '"/>';
    }
    html += '    </svg>';
    // Lotus
    html += '    <div class="eb-lotus" id="ebLotus">';
    var petalColors = ['#e84393', '#fd79a8', '#f0d48a', '#d4a54a', '#ff6b9d', '#e84393', '#c084fc', '#f0d48a', '#fd79a8', '#d4a54a', '#ff6b9d', '#e84393'];
    for (var p = 0; p < 12; p++) {
      var rot = (p * 30);
      html += '<div class="lotus-petal" style="--r:' + rot + 'deg;transform:translateX(-50%) translateY(-50%) rotate(' + rot + 'deg) scale(0.3);background:linear-gradient(to top,' + petalColors[p] + ',' + petalColors[p] + '88)"></div>';
    }
    html += '    </div>';
    html += '  </div>';
    html += '  <p class="eb-splash-hindi">॥ श्री गणेशाय नमः ॥</p>';
    html += '  <div class="eb-splash-names">' + C.bride + ' & ' + C.groom + '</div>';
    html += '  <p class="eb-splash-subtitle">Request the Honour of Your Presence</p>';
    html += '  <button class="eb-open-btn" id="ebOpenBtn">✦ Open Invitation ✦</button>';
    html += '</section>';

    /* -- MAIN INVITATION -- */
    html += '<div id="eb-main" class="eb-hidden">';

    /* === HERO === */
    html += '<section id="eb-hero" class="eb-section eb-sec-dark">';
    html += corners();
    html += '  <p class="eb-hero-badge">॥ श्री गणेशाय नमः ॥</p>';
    html += '  <div class="eb-hero-photos">';
    html += '    <div class="eb-photo eb-photo-lg" title="Bride Photo">';
    html += '      <i class="fa-solid fa-camera eb-photo-icon"></i>';
    html += '      <span class="eb-photo-label">Bride</span>';
    html += '    </div>';
    html += '    <span class="eb-hero-ampersand">&</span>';
    html += '    <div class="eb-photo eb-photo-lg" title="Groom Photo">';
    html += '      <i class="fa-solid fa-camera eb-photo-icon"></i>';
    html += '      <span class="eb-photo-label">Groom</span>';
    html += '    </div>';
    html += '  </div>';
    html += '  <h1 class="eb-hero-names">' + C.bride + ' & ' + C.groom + '</h1>';
    html += '  <p class="eb-hero-tagline">"Two souls, one eternal journey of love"</p>';
    html += divider();
    html += '  <p class="eb-hero-date">' + C.weddingDay + ' · ' + C.weddingDate + '</p>';
    html += '  <p class="eb-hero-venue">' + C.venue + '</p>';
    html += '  <div class="eb-scroll-hint"><i class="fa-solid fa-chevron-down"></i></div>';
    html += '</section>';

    /* === FAMILIES === */
    html += '<section class="eb-section eb-sec-deep">';
    html += corners();
    html += '  <h2 class="eb-title">The Noble Families</h2>';
    html += divider();
    html += '  <p class="eb-subtitle">Together in celebration of love</p>';
    html += '  <div class="eb-families">';
    // Bride family
    html += '    <div class="eb-family-card">';
    html += '      <span class="eb-family-emoji">👸</span>';
    html += '      <h3 class="eb-family-name">' + C.brideFamily + '</h3>';
    html += '      <p class="eb-family-parents">' + C.brideFather + '<br>' + C.brideMother + '</p>';
    html += '      <p class="eb-family-present">Lovingly present their daughter</p>';
    html += '      <h2 class="eb-family-person eb-bride-color">' + C.brideFull + '</h2>';
    html += '    </div>';
    // Groom family
    html += '    <div class="eb-family-card">';
    html += '      <span class="eb-family-emoji">🤴</span>';
    html += '      <h3 class="eb-family-name">' + C.groomFamily + '</h3>';
    html += '      <p class="eb-family-parents">' + C.groomFather + '<br>' + C.groomMother + '</p>';
    html += '      <p class="eb-family-present">Proudly present their son</p>';
    html += '      <h2 class="eb-family-person eb-groom-color">' + C.groomFull + '</h2>';
    html += '    </div>';
    html += '  </div>';
    html += '</section>';

    /* === OUR STORY with Photos === */
    html += '<section class="eb-section eb-sec-rich">';
    html += corners();
    html += '  <h2 class="eb-title">Our Love Story</h2>';
    html += divider();
    html += '  <p class="eb-subtitle">Written by destiny, sealed by the stars</p>';
    html += '  <div class="eb-story-grid">';
    html += '    <div class="eb-photo-rect" title="Couple Together Photo">';
    html += '      <i class="fa-solid fa-heart eb-photo-icon" style="font-size:40px"></i>';
    html += '      <span class="eb-photo-label">Couple Photo</span>';
    html += '    </div>';
    html += '    <div class="eb-story-text">';
    html += '      <h3>A Journey of Love</h3>';
    html += '      <p>From the first glance to forever, our story is one of fate, friendship, and an unbreakable bond. Every moment together has led us to this beautiful beginning.</p>';
    html += '      <p class="eb-quote">"In all the world, there is no heart for me like yours."</p>';
    html += '    </div>';
    html += '  </div>';
    html += '  <div class="eb-story-grid" style="margin-top:50px">';
    html += '    <div class="eb-story-text">';
    html += '      <h3>Pre-Wedding Bliss</h3>';
    html += '      <p>As we prepare for our grand celebration, every moment brings us closer. From engagement parties to planning our dream wedding — this chapter has been magical.</p>';
    html += '      <p class="eb-quote">"The best thing to hold onto in life is each other."</p>';
    html += '    </div>';
    html += '    <div class="eb-photo-rect" title="Pre-Wedding / Engagement Photo">';
    html += '      <i class="fa-solid fa-ring eb-photo-icon" style="font-size:40px"></i>';
    html += '      <span class="eb-photo-label">Pre-Wedding Photo</span>';
    html += '    </div>';
    html += '  </div>';
    html += '</section>';

    /* === WEDDING EVENTS === */
    html += '<section class="eb-section eb-sec-deep">';
    html += corners();
    html += '  <h2 class="eb-title">The Grand Festivities</h2>';
    html += divider();
    html += '  <p class="eb-subtitle">Five days of grandeur, tradition, and celebration</p>';
    html += '  <div class="eb-events-grid">';
    C.events.forEach(function (evt) {
      html += '<div class="eb-event-card">';
      html += '  <div class="eb-event-img" title="' + evt.name + ' Ceremony Photo">';
      html += '    <i class="fa-solid fa-image eb-photo-icon" style="font-size:36px"></i>';
      html += '    <span class="eb-photo-label">' + evt.name + ' Photo</span>';
      html += '    <div class="eb-event-color-bar" style="background:' + evt.color + '"></div>';
      html += '  </div>';
      html += '  <div class="eb-event-content">';
      html += '    <span class="eb-event-emoji">' + evt.emoji + '</span>';
      html += '    <h3 class="eb-event-name">' + evt.name + '</h3>';
      html += '    <div class="eb-event-detail"><i class="fa-solid fa-calendar"></i><span>' + evt.date + '</span></div>';
      html += '    <div class="eb-event-detail"><i class="fa-solid fa-clock"></i><span>' + evt.time + '</span></div>';
      html += '    <div class="eb-event-detail"><i class="fa-solid fa-location-dot"></i><span>' + evt.place + '</span></div>';
      html += '    <p class="eb-event-desc">' + evt.desc + '</p>';
      html += '  </div>';
      html += '</div>';
    });
    html += '  </div>';
    html += '</section>';

    /* === COUNTDOWN === */
    html += '<section class="eb-section eb-sec-rich">';
    html += corners();
    html += '  <h2 class="eb-title">Counting Down to Forever</h2>';
    html += divider();
    html += '  <p class="eb-subtitle">The auspicious moment draws near</p>';
    html += '  <div class="eb-countdown">';
    html += '    <div class="eb-cd-block"><span class="eb-cd-num" id="ebDays">000</span><span class="eb-cd-label">Days</span></div>';
    html += '    <span class="eb-cd-sep">:</span>';
    html += '    <div class="eb-cd-block"><span class="eb-cd-num" id="ebHrs">00</span><span class="eb-cd-label">Hours</span></div>';
    html += '    <span class="eb-cd-sep">:</span>';
    html += '    <div class="eb-cd-block"><span class="eb-cd-num" id="ebMins">00</span><span class="eb-cd-label">Minutes</span></div>';
    html += '    <span class="eb-cd-sep">:</span>';
    html += '    <div class="eb-cd-block"><span class="eb-cd-num" id="ebSecs">00</span><span class="eb-cd-label">Seconds</span></div>';
    html += '  </div>';
    html += '</section>';

    /* === GALLERY === */
    html += '<section class="eb-section eb-sec-deep">';
    html += corners();
    html += '  <h2 class="eb-title">Precious Moments</h2>';
    html += divider();
    html += '  <p class="eb-subtitle">A glimpse of our beautiful journey</p>';
    html += '  <div class="eb-gallery-grid">';
    var galleryLabels = ['Bride Portrait', 'Groom Portrait', 'Together Forever', 'Ring Ceremony'];
    var galleryIcons = ['fa-user-tie', 'fa-user', 'fa-heart', 'fa-gem'];
    galleryLabels.forEach(function (label, i) {
      html += '<div class="eb-gallery-item" title="' + label + '">';
      html += '  <i class="fa-solid ' + galleryIcons[i] + ' eb-photo-icon" style="font-size:32px"></i>';
      html += '  <span class="eb-photo-label">' + label + '</span>';
      html += '</div>';
    });
    html += '  </div>';
    html += '</section>';

    /* === CLOSING === */
    html += '<section class="eb-section eb-sec-rich" style="padding-bottom:100px">';
    html += corners();
    html += '  <p class="eb-closing-quote">"A love story for the ages — written by destiny, sealed by the stars, and blessed by the heavens."</p>';
    html += '  <div class="eb-closing-crest">';
    html += '    <span class="eb-crest-letter">' + C.bride.charAt(0) + '</span>';
    html += '    <span class="eb-crest-crown">♛</span>';
    html += '    <span class="eb-crest-letter">' + C.groom.charAt(0) + '</span>';
    html += '  </div>';
    html += '  <p class="eb-closing-msg">Your gracious presence shall be the most treasured gift at this royal celebration of love.</p>';
    html += '  <div class="eb-hashtag">' + C.hashtag + '</div>';
    html += '  <div class="eb-ornament">⚜ ✦ 👑 ✦ ⚜</div>';
    html += '  <p class="eb-signed">With Eternal Love & Royal Regards,<br>The ' + C.brideFamily.replace('House ', '') + ' & ' + C.groomFamily.replace('House ', '') + ' Families</p>';
    html += '  <div class="eb-stamp">SEALED<br>&<br>BLESSED<br>2026</div>';
    html += '</section>';

    html += '</div>'; // close #eb-main

    /* -- MUSIC BUTTON -- */
    html += '<button id="eb-music" class="eb-hidden" title="Toggle Music"><i class="fa-solid fa-music"></i></button>';

    document.body.innerHTML = html;
  }

  /* Helper — ornate corners */
  function corners() {
    return '<div class="eb-corner eb-c-tl"></div><div class="eb-corner eb-c-tr"></div><div class="eb-corner eb-c-bl"></div><div class="eb-corner eb-c-br"></div>';
  }

  /* Helper — ornate divider */
  function divider() {
    return '<div class="eb-divider"><span class="eb-div-line"></span><span class="eb-div-gem">⚜</span><span class="eb-div-line"></span></div>';
  }

  /* ==========================================================
     PARTICLE EFFECTS
     ========================================================== */
  function createParticles(count) {
    var container = document.getElementById('eb-particles');
    if (!container) return;
    for (var i = 0; i < (count || 50); i++) {
      var p = document.createElement('div');
      p.className = 'eb-ptcl';
      p.style.left = Math.random() * 100 + '%';
      p.style.bottom = '-10px';
      var size = 1.5 + Math.random() * 4;
      p.style.width = size + 'px';
      p.style.height = size + 'px';
      p.style.animationDuration = (12 + Math.random() * 20) + 's';
      p.style.animationDelay = (Math.random() * 18) + 's';
      container.appendChild(p);
    }
  }

  function createPetals(count) {
    var container = document.getElementById('eb-petals');
    if (!container) return;
    var classes = ['p-rose', 'p-gold', 'p-pink', 'p-peach', 'p-lav'];
    for (var i = 0; i < (count || 25); i++) {
      var p = document.createElement('div');
      p.className = 'eb-petal ' + classes[Math.floor(Math.random() * classes.length)];
      p.style.left = Math.random() * 100 + '%';
      p.style.top = '-20px';
      var size = 12 + Math.random() * 14;
      p.style.width = size + 'px';
      p.style.height = size + 'px';
      p.style.animationDuration = (14 + Math.random() * 18) + 's';
      p.style.animationDelay = (Math.random() * 20) + 's';
      container.appendChild(p);
    }
  }

  /* Gold spark burst */
  function goldSpark(cx, cy, count) {
    for (var i = 0; i < (count || 30); i++) {
      var s = document.createElement('div');
      s.className = 'eb-spark';
      s.style.left = cx + 'px';
      s.style.top = cy + 'px';
      var size = 2 + Math.random() * 5;
      s.style.width = size + 'px';
      s.style.height = size + 'px';
      var colors = ['#d4a54a', '#f0d48a', '#ffd700', '#e84393', '#fd79a8', '#ff6b9d', '#a855f7', '#2dd4a8'];
      s.style.background = colors[Math.floor(Math.random() * colors.length)];
      s.style.boxShadow = '0 0 6px ' + s.style.background;
      document.body.appendChild(s);

      var angle = Math.random() * Math.PI * 2;
      var dist = 60 + Math.random() * 220;
      gsap.to(s, {
        x: Math.cos(angle) * dist,
        y: Math.sin(angle) * dist,
        opacity: 0,
        duration: 0.9 + Math.random() * 1.2,
        ease: 'power2.out',
        onComplete: function () { if (s.parentNode) s.remove(); }
      });
    }
  }

  /* ==========================================================
     OPENING ANIMATION — Lotus Bloom + Splash
     ========================================================== */
  function animateSplash() {
    var tl = gsap.timeline({ delay: 0.3 });

    // Mandala fades in and begins spinning (CSS handles continuous spin)
    tl.from('.eb-mandala', { opacity: 0, scale: 0.5, duration: 1.5, ease: 'power2.out' });

    // Lotus petals bloom one by one
    var petals = document.querySelectorAll('.lotus-petal');
    petals.forEach(function (petal, i) {
      tl.to(petal, {
        opacity: 1,
        duration: 0.3,
        delay: i * 0.06,
        ease: 'power2.out',
        onStart: function () { petal.classList.add('bloom'); }
      }, i === 0 ? '-=0.5' : '<+=0.06');
    });
  }

  function openInvitation() {
    var splash = document.getElementById('eb-splash');
    var main = document.getElementById('eb-main');
    var musicBtn = document.getElementById('eb-music');

    // Play shehnai melody
    playShehnai();

    var tl = gsap.timeline({
      onComplete: function () {
        splash.style.display = 'none';
        document.body.style.overflow = '';
        musicBtn.classList.remove('eb-hidden');
        musicBtn.classList.add('playing');
        startAmbient();
        initCountdown();
        initScrollReveals();
      }
    });

    // Lotus petals fly outward
    document.querySelectorAll('.lotus-petal').forEach(function (petal, i) {
      var angle = (i * 30) * (Math.PI / 180);
      tl.to(petal, {
        x: Math.cos(angle) * 200,
        y: Math.sin(angle) * 200,
        opacity: 0,
        rotation: Math.random() * 360,
        duration: 0.7,
        ease: 'power2.out'
      }, i * 0.03);
    });

    // Mandala expands and fades
    tl.to('.eb-mandala', { scale: 3, opacity: 0, duration: 0.8, ease: 'power2.in' }, '-=0.5');

    // Sparkle burst in center
    tl.add(function () {
      goldSpark(window.innerWidth / 2, window.innerHeight / 2, 80);
      playBells();
    }, '-=0.3');

    // Text fades out
    tl.to('.eb-splash-hindi, .eb-splash-names, .eb-splash-subtitle, .eb-open-btn', {
      opacity: 0, y: -20, duration: 0.4, stagger: 0.05
    }, '-=0.5');

    // Splash fades
    tl.to(splash, { opacity: 0, duration: 0.5 });

    // Main reveals
    tl.add(function () {
      main.classList.remove('eb-hidden');
      goldSpark(window.innerWidth / 2, window.innerHeight / 3, 50);
    });

    tl.from(main, { opacity: 0, y: 30, duration: 1, ease: 'power2.out' });

    // Animate hero section entrance
    tl.from('.eb-hero-badge', { opacity: 0, y: -15, duration: 0.5 }, '-=0.6');
    tl.from('.eb-photo-lg', { opacity: 0, scale: 0.5, duration: 0.8, stagger: 0.15, ease: 'back.out(1.5)' }, '-=0.4');
    tl.from('.eb-hero-ampersand', { opacity: 0, scale: 0, duration: 0.5, ease: 'back.out(2)' }, '-=0.3');
    tl.from('.eb-hero-names', { opacity: 0, y: 20, duration: 0.7 }, '-=0.2');
    tl.from('.eb-hero-tagline', { opacity: 0, y: 10, duration: 0.5 }, '-=0.2');
    tl.from('#eb-hero .eb-divider', { scaleX: 0, duration: 0.5 }, '-=0.2');
    tl.from('.eb-hero-date, .eb-hero-venue', { opacity: 0, y: 10, duration: 0.4, stagger: 0.1 }, '-=0.2');
    tl.from('.eb-scroll-hint', { opacity: 0, duration: 0.5 }, '-=0.1');

    // Corner animations
    tl.from('#eb-hero .eb-corner', { opacity: 0, scale: 0, duration: 0.3, stagger: 0.08, ease: 'back.out(2)' }, '-=0.8');
  }

  /* ==========================================================
     COUNTDOWN TIMER
     ========================================================== */
  function initCountdown() {
    var target = new Date(C.weddingDate + ' ' + C.weddingTime).getTime();

    function update() {
      var diff = Math.max(0, target - Date.now());
      var d = Math.floor(diff / 86400000);
      var h = Math.floor((diff % 86400000) / 3600000);
      var m = Math.floor((diff % 3600000) / 60000);
      var s = Math.floor((diff % 60000) / 1000);

      setVal('ebDays', String(d).padStart(3, '0'));
      setVal('ebHrs', String(h).padStart(2, '0'));
      setVal('ebMins', String(m).padStart(2, '0'));

      var sEl = document.getElementById('ebSecs');
      if (sEl) {
        var prev = sEl.textContent;
        var next = String(s).padStart(2, '0');
        if (prev !== next) {
          sEl.textContent = next;
          if (typeof gsap !== 'undefined') {
            gsap.from(sEl, { y: -5, opacity: 0.3, duration: 0.2 });
          }
        }
      }
    }

    function setVal(id, val) {
      var el = document.getElementById(id);
      if (el) el.textContent = val;
    }

    update();
    setInterval(update, 1000);
  }

  /* ==========================================================
     SCROLL REVEAL ANIMATIONS (GSAP ScrollTrigger)
     ========================================================== */
  function initScrollReveals() {
    if (typeof gsap === 'undefined' || typeof ScrollTrigger === 'undefined') return;
    gsap.registerPlugin(ScrollTrigger);

    // All sections — corners pop in
    document.querySelectorAll('.eb-section').forEach(function (sec) {
      var secCorners = sec.querySelectorAll('.eb-corner');
      if (secCorners.length) {
        secCorners.forEach(function (c, i) {
          gsap.from(c, {
            scrollTrigger: { trigger: sec, start: 'top 80%' },
            opacity: 0, scale: 0, duration: 0.4, delay: i * 0.08, ease: 'back.out(2)'
          });
        });
      }
    });

    // All titles
    document.querySelectorAll('.eb-title').forEach(function (t) {
      gsap.from(t, {
        scrollTrigger: { trigger: t, start: 'top 85%' },
        opacity: 0, y: 25, duration: 0.7, ease: 'power3.out'
      });
    });

    // All dividers
    document.querySelectorAll('.eb-divider').forEach(function (d) {
      gsap.from(d, {
        scrollTrigger: { trigger: d, start: 'top 88%' },
        scaleX: 0, duration: 0.6
      });
    });

    // All subtitles
    document.querySelectorAll('.eb-subtitle').forEach(function (s) {
      gsap.from(s, {
        scrollTrigger: { trigger: s, start: 'top 88%' },
        opacity: 0, y: 15, duration: 0.5
      });
    });

    // Family cards
    document.querySelectorAll('.eb-family-card').forEach(function (card, i) {
      gsap.from(card, {
        scrollTrigger: { trigger: card, start: 'top 85%' },
        opacity: 0, y: 40, duration: 0.7, delay: i * 0.15, ease: 'power3.out',
        onStart: function () { playTinkle(); }
      });
    });

    // Story sections
    document.querySelectorAll('.eb-story-grid').forEach(function (grid, i) {
      var children = grid.children;
      gsap.from(children[0], {
        scrollTrigger: { trigger: grid, start: 'top 80%' },
        opacity: 0, x: i % 2 === 0 ? -40 : 40, duration: 0.8, ease: 'power3.out'
      });
      gsap.from(children[1], {
        scrollTrigger: { trigger: grid, start: 'top 80%' },
        opacity: 0, x: i % 2 === 0 ? 40 : -40, duration: 0.8, delay: 0.15, ease: 'power3.out'
      });
    });

    // Event cards with stagger
    document.querySelectorAll('.eb-event-card').forEach(function (card, i) {
      gsap.from(card, {
        scrollTrigger: { trigger: card, start: 'top 85%' },
        opacity: 0, y: 50, scale: 0.95, duration: 0.7, delay: i * 0.1,
        ease: 'power3.out',
        onStart: function () {
          playChime();
          var r = card.getBoundingClientRect();
          goldSpark(r.left + r.width / 2, r.top + 10, 6);
        }
      });
    });

    // Countdown
    gsap.from('.eb-countdown', {
      scrollTrigger: { trigger: '.eb-countdown', start: 'top 85%' },
      opacity: 0, y: 30, duration: 0.8
    });

    document.querySelectorAll('.eb-cd-block').forEach(function (b, i) {
      gsap.from(b, {
        scrollTrigger: { trigger: '.eb-countdown', start: 'top 85%' },
        opacity: 0, scale: 0.5, duration: 0.5, delay: i * 0.12, ease: 'back.out(1.5)'
      });
    });

    // Gallery items
    document.querySelectorAll('.eb-gallery-item').forEach(function (item, i) {
      gsap.from(item, {
        scrollTrigger: { trigger: item, start: 'top 85%' },
        opacity: 0, scale: 0.8, rotation: (i % 2 === 0 ? -5 : 5), duration: 0.6,
        delay: i * 0.1, ease: 'power3.out',
        onStart: function () { playTinkle(); }
      });
    });

    // Closing elements
    gsap.from('.eb-closing-quote', {
      scrollTrigger: { trigger: '.eb-closing-quote', start: 'top 85%' },
      opacity: 0, y: 20, duration: 0.8
    });
    gsap.from('.eb-closing-crest', {
      scrollTrigger: { trigger: '.eb-closing-crest', start: 'top 85%' },
      opacity: 0, scale: 0.3, duration: 1, ease: 'back.out(1.7)'
    });
    gsap.from('.eb-closing-msg', {
      scrollTrigger: { trigger: '.eb-closing-msg', start: 'top 88%' },
      opacity: 0, y: 15, duration: 0.7
    });
    gsap.from('.eb-hashtag', {
      scrollTrigger: { trigger: '.eb-hashtag', start: 'top 88%' },
      opacity: 0, y: 10, duration: 0.6
    });
    gsap.from('.eb-stamp', {
      scrollTrigger: { trigger: '.eb-stamp', start: 'top 90%' },
      opacity: 0, scale: 0, rotation: -90, duration: 0.8, ease: 'back.out(2)'
    });
  }

  /* ==========================================================
     INTERACTIVE FEATURES
     ========================================================== */

  /* 3D tilt on hover for event cards (desktop) */
  function initTiltCards() {
    document.querySelectorAll('.eb-event-card, .eb-family-card, .eb-gallery-item').forEach(function (card) {
      card.addEventListener('mousemove', function (e) {
        var rect = card.getBoundingClientRect();
        var x = e.clientX - rect.left;
        var y = e.clientY - rect.top;
        var cx = rect.width / 2;
        var cy = rect.height / 2;
        var rotateY = ((x - cx) / cx) * 8;
        var rotateX = ((cy - y) / cy) * 6;
        card.style.transform = 'perspective(800px) rotateY(' + rotateY + 'deg) rotateX(' + rotateX + 'deg) translateY(-5px) scale(1.02)';
      });
      card.addEventListener('mouseleave', function () {
        if (typeof gsap !== 'undefined') {
          gsap.to(card, { rotateY: 0, rotateX: 0, y: 0, scale: 1, duration: 0.5, ease: 'power2.out', clearProps: 'transform' });
        } else {
          card.style.transform = '';
        }
      });
    });
  }

  /* Click sparkles on photos */
  function initPhotoSparkles() {
    document.querySelectorAll('.eb-photo, .eb-photo-rect, .eb-gallery-item').forEach(function (el) {
      el.addEventListener('click', function (e) {
        goldSpark(e.clientX, e.clientY, 20);
        playSparkle();
      });
    });
  }

  /* ==========================================================
     MUSIC TOGGLE
     ========================================================== */
  function initMusicToggle() {
    var btn = document.getElementById('eb-music');
    if (!btn) return;
    btn.addEventListener('click', function () {
      if (ambientPlaying) {
        stopAmbient();
        btn.classList.remove('playing');
        btn.innerHTML = '<i class="fa-solid fa-volume-xmark"></i>';
      } else {
        startAmbient();
        btn.classList.add('playing');
        btn.innerHTML = '<i class="fa-solid fa-music"></i>';
      }
    });
  }

  /* ==========================================================
     INITIALIZE EVERYTHING
     ========================================================== */
  function init() {
    injectFonts();
    injectStyles();
    buildPage();
    createParticles(55);
    createPetals(30);
    animateSplash();
    initTiltCards();
    initPhotoSparkles();
    initMusicToggle();

    // Open button handler
    var openBtn = document.getElementById('ebOpenBtn');
    if (openBtn) {
      openBtn.addEventListener('click', function handler() {
        openBtn.removeEventListener('click', handler);
        openInvitation();
      });
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
