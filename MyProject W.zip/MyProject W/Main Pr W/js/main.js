/* ============================================================
   VIVAANTRA — Premium Digital Invitation Studio
   Main JavaScript  |  ES6+
   ============================================================ */

document.addEventListener('DOMContentLoaded', () => {

  /* ==========================================================
     1. LOADING SCREEN
     ========================================================== */
  const loader = document.getElementById('loader');
  window.addEventListener('load', () => {
    setTimeout(() => {
      loader.classList.add('hidden');
      document.body.style.overflow = 'auto';
      // Trigger initial reveals after loader hides
      setTimeout(revealOnScroll, 300);
    }, 2200);
  });
  // Fallback in case load event already fired
  if (document.readyState === 'complete') {
    setTimeout(() => {
      loader.classList.add('hidden');
      document.body.style.overflow = 'auto';
      setTimeout(revealOnScroll, 300);
    }, 2200);
  }

  /* ==========================================================
     2. CURSOR GLOW EFFECT  (desktop only)
     ========================================================== */
  const cursorGlow = document.querySelector('.cursor-glow');
  if (cursorGlow && window.innerWidth > 1024) {
    let mouseX = 0, mouseY = 0, glowX = 0, glowY = 0;
    document.addEventListener('mousemove', e => {
      mouseX = e.clientX;
      mouseY = e.clientY;
    });
    (function animateCursor() {
      glowX += (mouseX - glowX) * 0.12;
      glowY += (mouseY - glowY) * 0.12;
      cursorGlow.style.left = glowX + 'px';
      cursorGlow.style.top = glowY + 'px';
      requestAnimationFrame(animateCursor);
    })();
  }

  /* ==========================================================
     3. SCROLL PROGRESS BAR
     ========================================================== */
  const scrollProgress = document.querySelector('.scroll-progress');
  function updateScrollProgress() {
    const scrollTop = window.scrollY;
    const docHeight = document.documentElement.scrollHeight - window.innerHeight;
    const pct = docHeight > 0 ? (scrollTop / docHeight) * 100 : 0;
    document.documentElement.style.setProperty('--scroll-pct', pct + '%');
  }
  window.addEventListener('scroll', updateScrollProgress, { passive: true });

  /* ==========================================================
     4. NAVBAR  — scroll class + active link
     ========================================================== */
  const navbar = document.querySelector('.navbar');
  const navLinks = document.querySelectorAll('.nav-links a');
  const sections = document.querySelectorAll('section[id]');

  function handleNavScroll() {
    const scrollY = window.scrollY;
    // Add scrolled class
    navbar.classList.toggle('scrolled', scrollY > 60);

    // Highlight active section link
    sections.forEach(sec => {
      const top = sec.offsetTop - 200;
      const bottom = top + sec.offsetHeight;
      const id = sec.getAttribute('id');
      if (scrollY >= top && scrollY < bottom) {
        navLinks.forEach(l => l.classList.remove('active'));
        const activeLink = document.querySelector(`.nav-links a[href="#${id}"]`);
        if (activeLink) activeLink.classList.add('active');
      }
    });
  }
  window.addEventListener('scroll', handleNavScroll, { passive: true });

  /* ==========================================================
     5. HAMBURGER MENU
     ========================================================== */
  const hamburger = document.querySelector('.hamburger');
  const navLinksContainer = document.querySelector('.nav-links');
  if (hamburger) {
    hamburger.addEventListener('click', () => {
      hamburger.classList.toggle('active');
      navLinksContainer.classList.toggle('open');
    });
    // Close on link click
    navLinksContainer.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        hamburger.classList.remove('active');
        navLinksContainer.classList.remove('open');
      });
    });
  }

  /* ==========================================================
     6. THEME TOGGLE  — Dark / Light
     ========================================================== */
  const themeToggle = document.querySelector('.theme-toggle');
  const themeIcon = themeToggle ? themeToggle.querySelector('i') : null;
  function setTheme(mode) {
    document.body.classList.toggle('light-mode', mode === 'light');
    if (themeIcon) {
      themeIcon.className = mode === 'light' ? 'fas fa-moon' : 'fas fa-sun';
    }
    localStorage.setItem('vivaantra-theme', mode);
  }
  // Init from storage
  const savedTheme = localStorage.getItem('vivaantra-theme') || 'dark';
  setTheme(savedTheme);
  if (themeToggle) {
    themeToggle.addEventListener('click', () => {
      const current = document.body.classList.contains('light-mode') ? 'dark' : 'light';
      setTheme(current);
    });
  }

  /* ==========================================================
     7. MUSIC TOGGLE
     ========================================================== */
  const musicFloat = document.querySelector('.music-float');
  const bgMusic = document.getElementById('bg-music');
  if (musicFloat && bgMusic) {
    musicFloat.addEventListener('click', () => {
      if (bgMusic.paused) {
        bgMusic.play().then(() => {
          musicFloat.classList.add('playing');
          musicFloat.querySelector('i').className = 'fas fa-volume-up';
        }).catch(() => {});
      } else {
        bgMusic.pause();
        musicFloat.classList.remove('playing');
        musicFloat.querySelector('i').className = 'fas fa-volume-mute';
      }
    });
  }

  /* ==========================================================
     8. PARTICLES BACKGROUND  (canvas)
     ========================================================== */
  const particleCanvas = document.getElementById('particles-canvas');
  if (particleCanvas) {
    const ctx = particleCanvas.getContext('2d');
    let particles = [];
    const PARTICLE_COUNT = window.innerWidth < 768 ? 35 : 70;

    function resizeCanvas() {
      particleCanvas.width = window.innerWidth;
      particleCanvas.height = window.innerHeight;
    }
    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);

    class Particle {
      constructor() {
        this.reset();
      }
      reset() {
        this.x = Math.random() * particleCanvas.width;
        this.y = Math.random() * particleCanvas.height;
        this.size = Math.random() * 2.5 + 0.5;
        this.speedX = (Math.random() - 0.5) * 0.4;
        this.speedY = (Math.random() - 0.5) * 0.4;
        this.opacity = Math.random() * 0.4 + 0.1;
        // Gold / pink / white color mix
        const colors = ['212,167,66', '255,111,145', '155,89,182', '255,255,255'];
        this.color = colors[Math.floor(Math.random() * colors.length)];
      }
      update() {
        this.x += this.speedX;
        this.y += this.speedY;
        if (this.x < 0 || this.x > particleCanvas.width) this.speedX *= -1;
        if (this.y < 0 || this.y > particleCanvas.height) this.speedY *= -1;
      }
      draw() {
        ctx.beginPath();
        ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(${this.color},${this.opacity})`;
        ctx.fill();
      }
    }

    // Init particles
    for (let i = 0; i < PARTICLE_COUNT; i++) particles.push(new Particle());

    function connectParticles() {
      for (let a = 0; a < particles.length; a++) {
        for (let b = a + 1; b < particles.length; b++) {
          const dx = particles[a].x - particles[b].x;
          const dy = particles[a].y - particles[b].y;
          const dist = Math.sqrt(dx * dx + dy * dy);
          if (dist < 120) {
            ctx.beginPath();
            ctx.strokeStyle = `rgba(212,167,66,${0.06 * (1 - dist / 120)})`;
            ctx.lineWidth = 0.5;
            ctx.moveTo(particles[a].x, particles[a].y);
            ctx.lineTo(particles[b].x, particles[b].y);
            ctx.stroke();
          }
        }
      }
    }

    function animateParticles() {
      ctx.clearRect(0, 0, particleCanvas.width, particleCanvas.height);
      particles.forEach(p => { p.update(); p.draw(); });
      connectParticles();
      requestAnimationFrame(animateParticles);
    }
    animateParticles();
  }

  /* ==========================================================
     9. SCROLL REVEAL ANIMATIONS
     ========================================================== */
  const revealElements = document.querySelectorAll('.reveal, .reveal-left, .reveal-right, .reveal-scale, .stagger-children');
  function revealOnScroll() {
    const windowHeight = window.innerHeight;
    revealElements.forEach(el => {
      const top = el.getBoundingClientRect().top;
      if (top < windowHeight * 0.88) {
        el.classList.add('revealed');
      }
    });
  }
  window.addEventListener('scroll', revealOnScroll, { passive: true });

  /* ==========================================================
     10. ANIMATED COUNTERS
     ========================================================== */
  const counters = document.querySelectorAll('.counter-num');
  let countersDone = false;
  function animateCounters() {
    if (countersDone) return;
    const section = document.querySelector('.counters');
    if (!section) return;
    const top = section.getBoundingClientRect().top;
    if (top < window.innerHeight * 0.85) {
      countersDone = true;
      counters.forEach(counter => {
        const target = parseInt(counter.getAttribute('data-target'), 10);
        const suffix = counter.getAttribute('data-suffix') || '';
        let current = 0;
        const step = Math.ceil(target / 60);
        const timer = setInterval(() => {
          current += step;
          if (current >= target) { current = target; clearInterval(timer); }
          counter.textContent = current.toLocaleString() + suffix;
        }, 28);
      });
    }
  }
  window.addEventListener('scroll', animateCounters, { passive: true });

  /* ==========================================================
     11. FEATURED DESIGNS CAROUSEL
     ========================================================== */
  const carouselTrack = document.querySelector('.carousel-track');
  const prevBtn = document.querySelector('.carousel-btn.prev');
  const nextBtn = document.querySelector('.carousel-btn.next');
  if (carouselTrack && prevBtn && nextBtn) {
    let carouselPos = 0;
    const cardWidth = 348; // card width + gap
    const visibleCards = () => Math.floor(carouselTrack.parentElement.offsetWidth / cardWidth) || 1;
    const totalCards = carouselTrack.children.length;
    const maxPos = () => Math.max(0, totalCards - visibleCards());

    function updateCarousel() {
      carouselTrack.style.transform = `translateX(-${carouselPos * cardWidth}px)`;
    }
    nextBtn.addEventListener('click', () => {
      carouselPos = carouselPos < maxPos() ? carouselPos + 1 : 0;
      updateCarousel();
    });
    prevBtn.addEventListener('click', () => {
      carouselPos = carouselPos > 0 ? carouselPos - 1 : maxPos();
      updateCarousel();
    });
    // Auto-play every 4s
    let autoPlay = setInterval(() => {
      carouselPos = carouselPos < maxPos() ? carouselPos + 1 : 0;
      updateCarousel();
    }, 4000);
    carouselTrack.parentElement.addEventListener('mouseenter', () => clearInterval(autoPlay));
    carouselTrack.parentElement.addEventListener('mouseleave', () => {
      autoPlay = setInterval(() => {
        carouselPos = carouselPos < maxPos() ? carouselPos + 1 : 0;
        updateCarousel();
      }, 4000);
    });
  }

  /* ==========================================================
     12. TESTIMONIALS AUTO-SCROLL
     ========================================================== */
  const testimonialsTrack = document.querySelector('.testimonials-track');
  if (testimonialsTrack) {
    let testScrollDir = 1;
    setInterval(() => {
      const maxScroll = testimonialsTrack.scrollWidth - testimonialsTrack.clientWidth;
      if (testimonialsTrack.scrollLeft >= maxScroll - 2) testScrollDir = -1;
      if (testimonialsTrack.scrollLeft <= 2) testScrollDir = 1;
      testimonialsTrack.scrollBy({ left: testScrollDir * 310, behavior: 'smooth' });
    }, 3500);
  }

  /* ==========================================================
     13. BACK TO TOP
     ========================================================== */
  const backToTop = document.querySelector('.back-to-top');
  if (backToTop) {
    window.addEventListener('scroll', () => {
      backToTop.classList.toggle('visible', window.scrollY > 500);
    }, { passive: true });
    backToTop.addEventListener('click', () => {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  }

  /* ==========================================================
     14. CONTACT FORM  — simple validation
     ========================================================== */
  const contactForm = document.getElementById('contact-form');
  if (contactForm) {
    contactForm.addEventListener('submit', e => {
      e.preventDefault();
      const fields = contactForm.querySelectorAll('[required]');
      let valid = true;
      fields.forEach(f => {
        if (!f.value.trim()) { valid = false; f.style.borderColor = '#ff5f57'; }
        else f.style.borderColor = '';
      });
      if (valid) {
        // Show success message
        const btn = contactForm.querySelector('.btn');
        const origText = btn.innerHTML;
        btn.innerHTML = '<i class="fas fa-check"></i> Message Sent!';
        btn.style.background = 'linear-gradient(135deg,#25D366,#128C7E)';
        setTimeout(() => { btn.innerHTML = origText; btn.style.background = ''; contactForm.reset(); }, 3000);
      }
    });
  }

  /* ==========================================================
     15. SMOOTH SCROLL for anchor links
     ========================================================== */
  document.querySelectorAll('a[href^="#"]').forEach(link => {
    link.addEventListener('click', e => {
      const id = link.getAttribute('href');
      if (id === '#') return;
      const target = document.querySelector(id);
      if (target) {
        e.preventDefault();
        const offset = 80;
        const top = target.getBoundingClientRect().top + window.scrollY - offset;
        window.scrollTo({ top, behavior: 'smooth' });
      }
    });
  });

  /* ==========================================================
     16. 3D TILT on hover  (category & featured cards)
     ========================================================== */
  const tiltCards = document.querySelectorAll('.category-card, .featured-card, .pricing-card');
  tiltCards.forEach(card => {
    card.addEventListener('mousemove', e => {
      const rect = card.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;
      const centerX = rect.width / 2;
      const centerY = rect.height / 2;
      const rotateX = ((y - centerY) / centerY) * -6;
      const rotateY = ((x - centerX) / centerX) * 6;
      card.style.transform = `perspective(800px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) translateY(-8px)`;
    });
    card.addEventListener('mouseleave', () => {
      card.style.transform = '';
    });
  });

  /* ==========================================================
     17. TYPING EFFECT for hero subtitle (optional flair)
     ========================================================== */
  const heroSubtitle = document.querySelector('.hero-subtitle');
  if (heroSubtitle && heroSubtitle.dataset.typed) {
    const text = heroSubtitle.dataset.typed;
    heroSubtitle.textContent = '';
    let i = 0;
    function type() {
      if (i < text.length) {
        heroSubtitle.textContent += text.charAt(i);
        i++;
        setTimeout(type, 32);
      }
    }
    // Start after loader hides
    setTimeout(type, 2600);
  }

});
