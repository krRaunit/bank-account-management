/* ============================================================
   ROYAL NIGHT WEDDING — PREMIUM MAIN.JS
   Ultra-Luxury Fantasy Night-Sky Wedding Invitation
   ============================================================ */

document.addEventListener('DOMContentLoaded', () => {

    // ======== REFERENCES ========
    const starsCanvas    = document.getElementById('starsCanvas');
    const ctx            = starsCanvas.getContext('2d');
    const prelude        = document.getElementById('prelude');
    const openingScene   = document.getElementById('openingScene');
    const envelope       = document.getElementById('envelope');
    const envSeal        = document.getElementById('envSeal');
    const orbitRing      = document.getElementById('orbitRing');
    const orbitRingInner = document.getElementById('orbitRingInner');
    const tapPrompt      = document.getElementById('tapPrompt');
    const explosionBox   = document.getElementById('explosionContainer');
    const flashOverlay   = document.getElementById('flashOverlay');
    const invitationPage = document.getElementById('invitationPage');
    const firefliesBox   = document.getElementById('fireflies');
    const musicBtn       = document.getElementById('musicBtn');

    let isOpening = false;
    let audioCtx  = null;

    // ================================================================
    //  PRELUDE (LOADING SCREEN)
    // ================================================================
    function initPrelude() {
        setTimeout(() => {
            prelude.classList.add('hidden');
        }, 2600);
    }


    // ================================================================
    //  STARRY SKY WITH NEBULA + CONSTELLATIONS
    // ================================================================
    function initStars() {
        const resize = () => {
            starsCanvas.width  = window.innerWidth;
            starsCanvas.height = window.innerHeight;
        };
        resize();
        window.addEventListener('resize', resize);

        // Generate stars
        const stars = [];
        const COUNT = Math.min(350, Math.floor(window.innerWidth * 0.18));
        for (let i = 0; i < COUNT; i++) {
            stars.push({
                x:   Math.random() * starsCanvas.width,
                y:   Math.random() * starsCanvas.height,
                r:   Math.random() * 1.8 + 0.2,
                a:   Math.random(),
                spd: Math.random() * 0.01 + 0.003,
                dir: Math.random() > 0.5 ? 1 : -1,
                // Color tint
                hue: Math.random() > 0.8 ? (Math.random() > 0.5 ? 45 : 230) : 240,
            });
        }

        // Nebula patches (drawn once)
        const nebulae = [];
        for (let i = 0; i < 4; i++) {
            nebulae.push({
                x: Math.random() * starsCanvas.width,
                y: Math.random() * starsCanvas.height * 0.6,
                w: Math.random() * 400 + 200,
                h: Math.random() * 300 + 150,
                hue: [260, 220, 280, 200][i],
                alpha: Math.random() * 0.015 + 0.008,
            });
        }

        // Shooting stars
        const shootingStars = [];
        function spawnShootingStar() {
            shootingStars.push({
                x: Math.random() * starsCanvas.width * 0.8,
                y: Math.random() * starsCanvas.height * 0.3,
                len: Math.random() * 100 + 50,
                speed: Math.random() * 7 + 5,
                angle: Math.PI / 4 + Math.random() * 0.4 - 0.2,
                life: 1,
                decay: Math.random() * 0.012 + 0.008,
            });
        }

        function animate() {
            ctx.clearRect(0, 0, starsCanvas.width, starsCanvas.height);

            // Nebula glow
            for (const n of nebulae) {
                const grad = ctx.createRadialGradient(n.x, n.y, 0, n.x, n.y, n.w / 2);
                grad.addColorStop(0, `hsla(${n.hue}, 60%, 30%, ${n.alpha})`);
                grad.addColorStop(0.5, `hsla(${n.hue}, 50%, 20%, ${n.alpha * 0.5})`);
                grad.addColorStop(1, 'transparent');
                ctx.fillStyle = grad;
                ctx.fillRect(n.x - n.w / 2, n.y - n.h / 2, n.w, n.h);
            }

            // Stars
            for (const s of stars) {
                s.a += s.spd * s.dir;
                if (s.a >= 1)    { s.a = 1;    s.dir = -1; }
                if (s.a <= 0.05) { s.a = 0.05;  s.dir = 1; }

                ctx.beginPath();
                ctx.arc(s.x, s.y, s.r, 0, Math.PI * 2);
                ctx.fillStyle = `hsla(${s.hue}, 30%, 90%, ${s.a})`;
                ctx.fill();

                // Glow for big stars
                if (s.r > 1.2) {
                    ctx.beginPath();
                    ctx.arc(s.x, s.y, s.r * 3.5, 0, Math.PI * 2);
                    ctx.fillStyle = `hsla(${s.hue}, 40%, 80%, ${s.a * 0.06})`;
                    ctx.fill();
                }

                // Cross flare for brightest
                if (s.r > 1.6 && s.a > 0.7) {
                    ctx.strokeStyle = `hsla(${s.hue}, 30%, 90%, ${s.a * 0.2})`;
                    ctx.lineWidth = 0.5;
                    ctx.beginPath();
                    ctx.moveTo(s.x - s.r * 4, s.y);
                    ctx.lineTo(s.x + s.r * 4, s.y);
                    ctx.stroke();
                    ctx.beginPath();
                    ctx.moveTo(s.x, s.y - s.r * 4);
                    ctx.lineTo(s.x, s.y + s.r * 4);
                    ctx.stroke();
                }
            }

            // Shooting stars
            for (let i = shootingStars.length - 1; i >= 0; i--) {
                const ss = shootingStars[i];
                ss.x += Math.cos(ss.angle) * ss.speed;
                ss.y += Math.sin(ss.angle) * ss.speed;
                ss.life -= ss.decay;
                if (ss.life <= 0) { shootingStars.splice(i, 1); continue; }

                const tailX = ss.x - Math.cos(ss.angle) * ss.len;
                const tailY = ss.y - Math.sin(ss.angle) * ss.len;
                const grad = ctx.createLinearGradient(tailX, tailY, ss.x, ss.y);
                grad.addColorStop(0, 'rgba(255, 215, 0, 0)');
                grad.addColorStop(0.6, `rgba(255, 230, 130, ${ss.life * 0.4})`);
                grad.addColorStop(1, `rgba(255, 245, 200, ${ss.life * 0.8})`);
                ctx.beginPath();
                ctx.moveTo(tailX, tailY);
                ctx.lineTo(ss.x, ss.y);
                ctx.strokeStyle = grad;
                ctx.lineWidth = 1.8;
                ctx.stroke();

                // Head glow
                ctx.beginPath();
                ctx.arc(ss.x, ss.y, 2.5, 0, Math.PI * 2);
                ctx.fillStyle = `rgba(255, 248, 220, ${ss.life * 0.9})`;
                ctx.fill();

                // Sparkle trail
                if (Math.random() > 0.5) {
                    ctx.beginPath();
                    ctx.arc(
                        ss.x - Math.cos(ss.angle) * (Math.random() * 40),
                        ss.y - Math.sin(ss.angle) * (Math.random() * 40),
                        0.8,
                        0, Math.PI * 2
                    );
                    ctx.fillStyle = `rgba(255, 215, 0, ${ss.life * 0.5})`;
                    ctx.fill();
                }
            }

            requestAnimationFrame(animate);
        }
        animate();

        // Shooting star spawner (more frequent)
        setInterval(() => {
            if (Math.random() > 0.3) spawnShootingStar();
        }, 2500);
    }


    // ================================================================
    //  FIREFLIES (more and varied)
    // ================================================================
    function initFireflies() {
        const count = window.innerWidth < 600 ? 20 : 40;
        for (let i = 0; i < count; i++) {
            const ff = document.createElement('div');
            ff.className = 'firefly';
            ff.style.left = Math.random() * 100 + '%';
            ff.style.top  = Math.random() * 100 + '%';
            ff.style.setProperty('--duration', (Math.random() * 6 + 4) + 's');
            ff.style.setProperty('--delay',    (Math.random() * 6) + 's');
            ff.style.setProperty('--dx', (Math.random() * 160 - 80) + 'px');
            ff.style.setProperty('--dy', (Math.random() * 160 - 80) + 'px');
            const size = (Math.random() * 4 + 2) + 'px';
            ff.style.width  = size;
            ff.style.height = size;
            firefliesBox.appendChild(ff);
        }
    }


    // ================================================================
    //  ENVELOPE OPENING — MULTI-PHASE CINEMATIC
    // ================================================================
    function openEnvelope() {
        if (isOpening) return;
        isOpening = true;

        // Try to play a subtle chime via Web Audio
        playOpenChime();

        // Phase 0 — Hide tap prompt, fade opening text
        tapPrompt.classList.add('hidden');
        const topText = document.getElementById('openingTopText');
        const nameText = document.getElementById('openingNames');
        if (topText) topText.style.opacity = '0';
        if (nameText) nameText.style.opacity = '0';

        // Phase 1 — Dual orbit rings converge (0-600ms)
        orbitRing.classList.add('converge');
        orbitRingInner.classList.add('converge');

        // Phase 2 — Seal shatters with massive particle burst (450ms)
        setTimeout(() => {
            createSealExplosion(80);
            envSeal.classList.add('shatter');
        }, 450);

        // Phase 3 — Flap opens + golden light beams cascade (900ms)
        setTimeout(() => {
            envelope.classList.add('open');
            envelope.style.animation = 'none';
        }, 900);

        // Phase 4 — Secondary sparkle burst from card edges (1800ms)
        setTimeout(() => {
            createCardSparkles();
        }, 1800);

        // Phase 5 — Golden flash transition (3000ms)
        setTimeout(() => {
            transitionToInvitation();
        }, 3000);
    }

    // Golden particle explosion from seal center
    function createSealExplosion(count) {
        const sealRect = envSeal.getBoundingClientRect();
        const cx = sealRect.left + sealRect.width  / 2;
        const cy = sealRect.top  + sealRect.height / 2;

        for (let i = 0; i < count; i++) {
            const p = document.createElement('div');
            const isSparkle = Math.random() > 0.6;
            p.className = 'explosion-particle' + (isSparkle ? ' sparkle' : '');

            const angle = (Math.PI * 2 / count) * i + (Math.random() - 0.5) * 0.5;
            const dist  = Math.random() * 250 + 80;
            const tx = Math.cos(angle) * dist;
            const ty = Math.sin(angle) * dist;
            const dur = (Math.random() * 0.7 + 0.4).toFixed(2);
            const size = isSparkle ? (Math.random() * 4 + 2) : (Math.random() * 6 + 2);
            const rot  = isSparkle ? (Math.random() * 360) : 0;

            p.style.left = cx + 'px';
            p.style.top  = cy + 'px';
            p.style.width  = size + 'px';
            p.style.height = size + 'px';
            p.style.setProperty('--tx', tx + 'px');
            p.style.setProperty('--ty', ty + 'px');
            p.style.setProperty('--duration', dur + 's');
            p.style.setProperty('--rot', rot + 'deg');

            // Color variety
            const r = Math.random();
            if (r > 0.7) {
                p.style.background = '#ffe8a0';
                p.style.boxShadow  = '0 0 8px #ffe8a0, 0 0 22px rgba(255,232,160,0.4)';
            } else if (r > 0.4) {
                p.style.background = '#ffd700';
                p.style.boxShadow  = '0 0 8px #ffd700, 0 0 22px rgba(255,215,0,0.35)';
            } else {
                p.style.background = '#c8b8ff';
                p.style.boxShadow  = '0 0 6px #c8b8ff, 0 0 16px rgba(200,184,255,0.3)';
            }

            explosionBox.appendChild(p);
            setTimeout(() => p.remove(), parseFloat(dur) * 1000 + 300);
        }
    }

    // Secondary sparkle burst when card rises
    function createCardSparkles() {
        const envRect = envelope.getBoundingClientRect();
        const cx = envRect.left + envRect.width / 2;
        const cy = envRect.top;

        for (let i = 0; i < 35; i++) {
            const p = document.createElement('div');
            p.className = 'explosion-particle sparkle';

            const angle = Math.random() * Math.PI * 2;
            const dist  = Math.random() * 200 + 60;
            const tx = Math.cos(angle) * dist;
            const ty = Math.sin(angle) * dist - 80;
            const dur = (Math.random() * 0.8 + 0.5).toFixed(2);

            p.style.left = (cx + (Math.random() - 0.5) * envRect.width * 0.8) + 'px';
            p.style.top  = cy + 'px';
            p.style.width  = (Math.random() * 4 + 1.5) + 'px';
            p.style.height = p.style.width;
            p.style.setProperty('--tx', tx + 'px');
            p.style.setProperty('--ty', ty + 'px');
            p.style.setProperty('--duration', dur + 's');
            p.style.setProperty('--rot', (Math.random() * 360) + 'deg');
            p.style.background = Math.random() > 0.5 ? '#ffd700' : '#ffe8a0';

            explosionBox.appendChild(p);
            setTimeout(() => p.remove(), parseFloat(dur) * 1000 + 300);
        }
    }

    // Transition to main invitation
    function transitionToInvitation() {
        flashOverlay.classList.add('active');

        setTimeout(() => {
            openingScene.classList.add('hidden');
            flashOverlay.classList.remove('active');
            flashOverlay.classList.add('fade');
            invitationPage.classList.add('visible');
            document.body.style.overflow = 'auto';
            initAmbientParticles();
            initCoupleFrameSparkles();
        }, 550);

        setTimeout(() => {
            openingScene.style.display = 'none';
            flashOverlay.remove();
        }, 3000);
    }


    // ================================================================
    //  WEB AUDIO CHIME (subtle magical open sound)
    // ================================================================
    function playOpenChime() {
        try {
            audioCtx = new (window.AudioContext || window.webkitAudioContext)();
            // Play a pleasant golden chime chord
            const notes = [523.25, 659.25, 783.99, 1046.5]; // C5, E5, G5, C6
            notes.forEach((freq, i) => {
                const osc = audioCtx.createOscillator();
                const gain = audioCtx.createGain();
                osc.type = 'sine';
                osc.frequency.value = freq;
                gain.gain.setValueAtTime(0, audioCtx.currentTime);
                gain.gain.linearRampToValueAtTime(0.06, audioCtx.currentTime + 0.05 + i * 0.08);
                gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 1.5 + i * 0.2);
                osc.connect(gain);
                gain.connect(audioCtx.destination);
                osc.start(audioCtx.currentTime + i * 0.08);
                osc.stop(audioCtx.currentTime + 2 + i * 0.2);
            });
        } catch (e) { /* silent fail */ }
    }


    // ================================================================
    //  MUSIC BUTTON (ambient background melody)
    // ================================================================
    let bgMusic = null;
    let isMusicPlaying = false;

    musicBtn.classList.add('paused');
    musicBtn.addEventListener('click', () => {
        if (!bgMusic) {
            bgMusic = createAmbientMusic();
        }
        if (isMusicPlaying) {
            bgMusic.suspend();
            musicBtn.classList.add('paused');
        } else {
            bgMusic.resume();
            musicBtn.classList.remove('paused');
        }
        isMusicPlaying = !isMusicPlaying;
    });

    function createAmbientMusic() {
        const ac = new (window.AudioContext || window.webkitAudioContext)();
        const masterGain = ac.createGain();
        masterGain.gain.value = 0.08;
        masterGain.connect(ac.destination);

        // Soft pad
        function playPad(freq, startTime, duration) {
            const osc = ac.createOscillator();
            const g = ac.createGain();
            osc.type = 'sine';
            osc.frequency.value = freq;
            g.gain.setValueAtTime(0, startTime);
            g.gain.linearRampToValueAtTime(0.5, startTime + 0.5);
            g.gain.setValueAtTime(0.5, startTime + duration - 0.5);
            g.gain.linearRampToValueAtTime(0, startTime + duration);
            osc.connect(g);
            g.connect(masterGain);
            osc.start(startTime);
            osc.stop(startTime + duration);
        }

        // Loop a gentle chord progression
        const chords = [
            [261.63, 329.63, 392],     // C
            [220, 293.66, 349.23],      // Dm
            [246.94, 329.63, 392],      // Em
            [261.63, 329.63, 392],      // C
        ];

        let t = ac.currentTime;
        function scheduleLoop() {
            for (const chord of chords) {
                for (const note of chord) {
                    playPad(note, t, 4);
                }
                t += 4;
            }
            setTimeout(scheduleLoop, (chords.length * 4 - 1) * 1000);
        }
        scheduleLoop();

        return ac;
    }


    // ================================================================
    //  AMBIENT PARTICLES (invitation page)
    // ================================================================
    function initAmbientParticles() {
        const container = document.getElementById('ambientParticles');
        const count = window.innerWidth < 600 ? 25 : 50;
        for (let i = 0; i < count; i++) {
            const dot = document.createElement('div');
            dot.className = 'ambient-dot';
            dot.style.left = Math.random() * 100 + '%';
            dot.style.top  = Math.random() * 100 + '%';
            dot.style.setProperty('--dur', (Math.random() * 8 + 5) + 's');
            dot.style.setProperty('--del', (Math.random() * 8) + 's');
            container.appendChild(dot);
        }
    }


    // ================================================================
    //  COUPLE FRAME SPARKLES
    // ================================================================
    function initCoupleFrameSparkles() {
        ['sparkleGroom', 'sparkleBride'].forEach(id => {
            const container = document.getElementById(id);
            if (!container) return;
            for (let i = 0; i < 8; i++) {
                const s = document.createElement('span');
                s.textContent = '✦';
                s.style.cssText = `
                    position: absolute;
                    font-size: ${Math.random() * 6 + 4}px;
                    color: #ffd700;
                    opacity: 0;
                    animation: sparkleFrameAnim ${Math.random() * 3 + 2}s ${Math.random() * 3}s infinite ease-in-out;
                    top: ${Math.random() * 100}%;
                    left: ${Math.random() * 100}%;
                    text-shadow: 0 0 6px rgba(255,215,0,0.5);
                `;
                container.appendChild(s);
            }
        });

        // Inject sparkle keyframes
        if (!document.getElementById('sparkleStyle')) {
            const style = document.createElement('style');
            style.id = 'sparkleStyle';
            style.textContent = `
                @keyframes sparkleFrameAnim {
                    0%, 100% { opacity: 0; transform: scale(0.5) rotate(0deg); }
                    50% { opacity: 0.7; transform: scale(1) rotate(180deg); }
                }
            `;
            document.head.appendChild(style);
        }
    }


    // ================================================================
    //  SCROLL REVEAL (IntersectionObserver)
    // ================================================================
    function initScrollReveal() {
        const reveals = document.querySelectorAll('.reveal-up');
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const delay = parseFloat(entry.target.dataset.delay) || 0;
                    setTimeout(() => {
                        entry.target.classList.add('revealed');
                    }, delay * 1000);
                    observer.unobserve(entry.target);
                }
            });
        }, { threshold: 0.1 });
        reveals.forEach(el => observer.observe(el));
    }


    // ================================================================
    //  COUNTDOWN TIMER
    // ================================================================
    function initCountdown() {
        const target = new Date('2027-01-15T10:00:00').getTime();
        const dEl = document.getElementById('cdDays');
        const hEl = document.getElementById('cdHours');
        const mEl = document.getElementById('cdMinutes');
        const sEl = document.getElementById('cdSeconds');

        function tick() {
            const diff = target - Date.now();
            if (diff <= 0) {
                dEl.textContent = '000'; hEl.textContent = '00';
                mEl.textContent = '00';  sEl.textContent = '00';
                return;
            }
            const d = Math.floor(diff / 86400000);
            const h = Math.floor((diff % 86400000) / 3600000);
            const m = Math.floor((diff % 3600000) / 60000);
            const s = Math.floor((diff % 60000) / 1000);

            animateNumber(dEl, String(d).padStart(3, '0'));
            animateNumber(hEl, String(h).padStart(2, '0'));
            animateNumber(mEl, String(m).padStart(2, '0'));
            animateNumber(sEl, String(s).padStart(2, '0'));
        }

        function animateNumber(el, val) {
            if (el.textContent !== val) {
                el.style.transform = 'translateY(-4px)';
                el.style.opacity = '0.5';
                setTimeout(() => {
                    el.textContent = val;
                    el.style.transform = 'translateY(0)';
                    el.style.opacity = '1';
                }, 150);
            }
        }

        tick();
        setInterval(tick, 1000);
    }


    // ================================================================
    //  PARALLAX (opening scene)
    // ================================================================
    function initParallax() {
        const area = document.getElementById('envelopeArea');
        const moonW = document.querySelector('.moon-wrapper');

        document.addEventListener('mousemove', (e) => {
            if (isOpening) return;
            const cx = window.innerWidth / 2;
            const cy = window.innerHeight / 2;
            const dx = (e.clientX - cx) / cx;
            const dy = (e.clientY - cy) / cy;

            if (area && openingScene.style.display !== 'none') {
                area.style.transform = `translate(${dx * 12}px, ${dy * 10}px)`;
            }
            if (moonW && openingScene.style.display !== 'none') {
                moonW.style.transform = `translate(${dx * -6}px, ${dy * -5}px)`;
            }
        });
    }


    // ================================================================
    //  SMOOTH SCROLL PARALLAX FOR SECTIONS
    // ================================================================
    function initSectionParallax() {
        const titles = document.querySelectorAll('.section-title');
        window.addEventListener('scroll', () => {
            const scrollY = window.scrollY;
            titles.forEach(t => {
                const rect = t.getBoundingClientRect();
                if (rect.top < window.innerHeight && rect.bottom > 0) {
                    const offset = (rect.top / window.innerHeight - 0.5) * 15;
                    t.style.transform = `translateY(${offset}px)`;
                }
            });
        }, { passive: true });
    }


    // ================================================================
    //  INITIALIZE
    // ================================================================
    document.body.style.overflow = 'hidden';

    initPrelude();
    initStars();
    initFireflies();
    initScrollReveal();
    initCountdown();
    initParallax();
    initSectionParallax();

    envelope.addEventListener('click', openEnvelope);
});
