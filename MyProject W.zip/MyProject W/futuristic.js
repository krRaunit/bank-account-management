/* ═══════════════════════════════════════════
   3D FUTURISTIC THEME — JavaScript
   Electronic synth music, particles, glitch, 3D cube, flip cards
   ═══════════════════════════════════════════ */
(function(){
  'use strict';

  // ── PARTICLES ──
  var partEl=document.getElementById('particles');
  var pCols=['#0ff','#8b00ff','#39ff14','#ff00ff'];
  for(var i=0;i<25;i++){
    var p=document.createElement('div');p.className='ftParticle';
    var sz=1+Math.random()*4;p.style.width=sz+'px';p.style.height=sz+'px';
    p.style.left=Math.random()*100+'%';p.style.bottom='-5px';
    var c=pCols[Math.floor(Math.random()*pCols.length)];
    p.style.background=c;p.style.boxShadow='0 0 '+(4+Math.random()*8)+'px '+c;
    p.style.animationDuration=(8+Math.random()*16)+'s';
    p.style.animationDelay=(Math.random()*12)+'s';
    partEl.appendChild(p);
  }

  // ── GLITCH LINES ──
  var glEl=document.getElementById('glitchLines');
  for(var i=0;i<4;i++){
    var g=document.createElement('div');g.className='glitchLine';
    g.style.animationDuration=(6+Math.random()*8)+'s';
    g.style.animationDelay=(Math.random()*10)+'s';
    glEl.appendChild(g);
  }

  // ── SPARK BURST ──
  function sparkBurst(cx,cy,n){
    var cols=['#0ff','#8b00ff','#39ff14','#ff00ff','#fff','#ffd700'];
    for(var i=0;i<(n||30);i++){
      var s=document.createElement('div');s.className='spark';
      s.style.left=cx+'px';s.style.top=cy+'px';
      var sz=2+Math.random()*5;s.style.width=sz+'px';s.style.height=sz+'px';
      var c=cols[Math.floor(Math.random()*cols.length)];
      s.style.background=c;s.style.boxShadow='0 0 10px '+c;
      document.body.appendChild(s);
      var a=Math.random()*Math.PI*2,d=50+Math.random()*200;
      gsap.to(s,{x:Math.cos(a)*d,y:Math.sin(a)*d,opacity:0,duration:.6+Math.random()*.5,ease:'power2.out',onComplete:function(){if(s.parentNode)s.remove()}});
    }
  }

  // ── SPLASH ANIM ──
  gsap.from('.sp-holo',{opacity:0,scale:0,rotationY:90,duration:.9,delay:.3,ease:'back.out(1.5)'});
  gsap.from('.sp-for',{opacity:0,y:10,duration:.4,delay:.8});
  gsap.from('.sp-name',{opacity:0,y:18,duration:.6,delay:1.1});
  gsap.from('.sp-sub',{opacity:0,y:8,duration:.4,delay:1.4});
  gsap.from('.sp-btn',{opacity:0,scale:.7,duration:.5,delay:1.6,ease:'back.out(1.5)'});

  // ── OPEN ──
  document.getElementById('openBtn').addEventListener('click',function(){
    var splash=document.getElementById('splash'),main=document.getElementById('main');
    var cx=window.innerWidth/2,cy=window.innerHeight/2;
    var tl=gsap.timeline({onComplete:function(){splash.style.display='none';document.body.style.overflow='';initSR()}});
    tl.to('.sp-holo',{scale:5,opacity:0,rotationY:180,duration:.5});
    tl.add(function(){sparkBurst(cx,cy,80)},'-=.3');
    tl.add(function(){sparkBurst(cx*.3,cy*.6,20);sparkBurst(cx*1.7,cy*.4,20)},'-=.1');
    tl.to('#splash > *:not(.sp-holo)',{opacity:0,y:-12,duration:.25,stagger:.03},'-=.3');
    tl.to(splash,{opacity:0,duration:.35});
    tl.add(function(){main.classList.remove('hide')});
    tl.from(main,{opacity:0,y:20,duration:.5});
    tl.from('.hero-cube-wrap',{opacity:0,scale:0,rotationY:180,duration:.8,ease:'back.out(1.5)'},'-=.2');
    tl.from('.hero-wish',{opacity:0,y:15,duration:.4},'-=.2');
    tl.from('.hero-name',{opacity:0,y:10,duration:.3},'-=.15');
    tl.from('.hero-msg',{opacity:0,y:8,duration:.3},'-=.15');
  });

  // ── SCROLL ANIMATIONS ──
  function initSR(){
    gsap.registerPlugin(ScrollTrigger);
    document.querySelectorAll('.sec-title').forEach(function(t){
      gsap.from(t,{scrollTrigger:{trigger:t,start:'top 85%'},opacity:0,y:25,duration:.7});
    });
    gsap.from('.holo-card',{scrollTrigger:{trigger:'.holo-card',start:'top 80%'},opacity:0,y:40,rotateX:15,duration:.8});
    document.querySelectorAll('.flip-card').forEach(function(f,i){
      gsap.from(f,{scrollTrigger:{trigger:f,start:'top 85%'},opacity:0,rotateY:90,scale:.5,duration:.6,delay:i*.08,ease:'back.out(1.3)'});
    });
    document.querySelectorAll('.dash-card').forEach(function(d,i){
      gsap.from(d,{scrollTrigger:{trigger:d,start:'top 85%'},opacity:0,y:30,scale:.8,rotateX:15,duration:.5,delay:i*.07,ease:'back.out(1.2)'});
    });

    // Animate stat numbers
    document.querySelectorAll('.dash-val').forEach(function(el){
      var v=parseInt(el.getAttribute('data-val'));
      ScrollTrigger.create({trigger:el,start:'top 85%',once:true,
        onEnter:function(){gsap.to(el,{innerHTML:v,duration:1.5,roundProps:'innerHTML',ease:'power2.out'})}
      });
    });

    // Progress bars
    document.querySelectorAll('.prog-fill').forEach(function(b){
      ScrollTrigger.create({trigger:b,start:'top 88%',once:true,
        onEnter:function(){b.style.width=b.getAttribute('data-w')}
      });
    });

    document.querySelectorAll('.prog-item').forEach(function(p,i){
      gsap.from(p,{scrollTrigger:{trigger:p,start:'top 87%'},opacity:0,x:-25,duration:.5,delay:i*.08});
    });
    gsap.from('.close-icon',{scrollTrigger:{trigger:'.close-icon',start:'top 85%'},opacity:0,scale:0,rotationY:90,duration:.8,ease:'back.out(1.7)'});
  }

  // ── 3D TILT ──
  document.querySelectorAll('.flip-card,.dash-card,.holo-card,.prog-item').forEach(function(el){
    el.addEventListener('mousemove',function(e){
      var r=el.getBoundingClientRect();
      var ry=((e.clientX-r.left-r.width/2)/(r.width/2))*12;
      var rx=((r.height/2-(e.clientY-r.top))/(r.height/2))*8;
      el.style.transform='perspective(600px) rotateY('+ry+'deg) rotateX('+rx+'deg) translateZ(12px)';
      el.style.transition='transform .08s ease';
    });
    el.addEventListener('mouseleave',function(){el.style.transition='transform .5s ease';el.style.transform=''});
  });

  document.addEventListener('click',function(e){
    if(e.target.closest('.flip-card,.dash-card,.hero-cube-wrap'))sparkBurst(e.clientX,e.clientY,18);
  });

  // ── ELECTRONIC SYNTH MUSIC (Web Audio) ──
  var audioCtx=null,musicPlaying=false,musicInterval=null;

  function playSynth(){
    if(!audioCtx)audioCtx=new(window.AudioContext||window.webkitAudioContext)();
    var t=audioCtx.currentTime+.1;

    // Bass line
    var bassNotes=[65.41,73.42,82.41,65.41,87.31,82.41,73.42,65.41];
    bassNotes.forEach(function(f){
      var osc=audioCtx.createOscillator(),gain=audioCtx.createGain();
      osc.type='sawtooth';osc.frequency.setValueAtTime(f,t);
      var filter=audioCtx.createBiquadFilter();filter.type='lowpass';filter.frequency.setValueAtTime(300,t);
      gain.gain.setValueAtTime(.035,t);gain.gain.exponentialRampToValueAtTime(.001,t+.4);
      osc.connect(filter);filter.connect(gain);gain.connect(audioCtx.destination);
      osc.start(t);osc.stop(t+.45);
      t+=.35;
    });

    // Melody over bass
    var t2=audioCtx.currentTime+.15;
    var melNotes=[523,659,784,1047,784,659,523,440,523,659,784,880,784,523];
    melNotes.forEach(function(f){
      var osc=audioCtx.createOscillator(),gain=audioCtx.createGain();
      osc.type='square';osc.frequency.setValueAtTime(f,t2);
      var filter=audioCtx.createBiquadFilter();filter.type='lowpass';filter.frequency.setValueAtTime(2000,t2);
      gain.gain.setValueAtTime(0,t2);gain.gain.linearRampToValueAtTime(.02,t2+.02);
      gain.gain.exponentialRampToValueAtTime(.001,t2+.18);
      osc.connect(filter);filter.connect(gain);gain.connect(audioCtx.destination);
      osc.start(t2);osc.stop(t2+.2);
      t2+=.2;
    });

    return Math.max(t,t2)-audioCtx.currentTime;
  }

  function toggleMusic(){
    if(musicPlaying){
      musicPlaying=false;if(musicInterval)clearInterval(musicInterval);
      document.getElementById('musicBtn').innerHTML='<i class="fa-solid fa-volume-xmark"></i>';
    }else{
      musicPlaying=true;
      var dur=playSynth();
      musicInterval=setInterval(function(){if(musicPlaying)playSynth()},dur*1000+400);
      document.getElementById('musicBtn').innerHTML='<i class="fa-solid fa-music"></i>';
    }
  }
  document.getElementById('musicBtn').addEventListener('click',toggleMusic);

  document.body.style.overflow='hidden';
})();
