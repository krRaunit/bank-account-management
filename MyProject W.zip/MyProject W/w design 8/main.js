/* =============================================
   MODERN LUXURY WEDDING INVITATION — JAVASCRIPT
   Romantic Animations & Premium Interactions
   ============================================= */

document.addEventListener('DOMContentLoaded', () => {

    // ══════════════════════════════════════
    // 1. PRELOADER
    // ══════════════════════════════════════
    const preloader = document.querySelector('.preloader');
    window.addEventListener('load', () => {
        setTimeout(() => {
            preloader.classList.add('hidden');
            initRevealAnimations();
        }, 1800);
    });

    // ══════════════════════════════════════
    // 2. CURSOR GLOW
    // ══════════════════════════════════════
    const cursorGlow = document.querySelector('.cursor-glow');
    if (cursorGlow && window.innerWidth > 768) {
        document.addEventListener('mousemove', (e) => {
            cursorGlow.style.left = e.clientX + 'px';
            cursorGlow.style.top = e.clientY + 'px';
        });
    }

    // ══════════════════════════════════════
    // 3. FLOWER & BUTTERFLY PARTICLES (Canvas)
    // ══════════════════════════════════════
    const canvas = document.getElementById('particles-canvas');
    const ctx = canvas.getContext('2d');
    let particles = [];

    function resizeCanvas() {
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
    }
    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);

    class SoftParticle {
        constructor() { this.reset(); }
        reset() {
            this.x = Math.random() * canvas.width;
            this.y = Math.random() * canvas.height;
            this.size = Math.random() * 2.5 + 0.5;
            this.speedX = (Math.random() - 0.5) * 0.3;
            this.speedY = (Math.random() - 0.5) * 0.2;
            this.opacity = Math.random() * 0.3 + 0.08;
            this.fadeSpeed = Math.random() * 0.003 + 0.001;
            this.growing = Math.random() > 0.5;
            // Soft pink / rose tones
            const colors = [
                [245, 160, 184],
                [220, 177, 167],
                [232, 223, 245],
                [252, 228, 216]
            ];
            this.color = colors[Math.floor(Math.random() * colors.length)];
        }
        update() {
            this.x += this.speedX;
            this.y += this.speedY;
            if (this.growing) {
                this.opacity += this.fadeSpeed;
                if (this.opacity >= 0.4) this.growing = false;
            } else {
                this.opacity -= this.fadeSpeed;
                if (this.opacity <= 0.05) this.growing = true;
            }
            if (this.x < 0 || this.x > canvas.width || this.y < 0 || this.y > canvas.height) {
                this.reset();
            }
        }
        draw() {
            const [r, g, b] = this.color;
            ctx.beginPath();
            ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
            ctx.fillStyle = `rgba(${r},${g},${b},${this.opacity})`;
            ctx.fill();
            // Soft glow
            ctx.beginPath();
            ctx.arc(this.x, this.y, this.size * 4, 0, Math.PI * 2);
            ctx.fillStyle = `rgba(${r},${g},${b},${this.opacity * 0.08})`;
            ctx.fill();
        }
    }

    function initParticles() {
        const count = Math.min(60, Math.floor(window.innerWidth / 20));
        for (let i = 0; i < count; i++) particles.push(new SoftParticle());
    }
    function animateParticles() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        particles.forEach(p => { p.update(); p.draw(); });
        requestAnimationFrame(animateParticles);
    }
    initParticles();
    animateParticles();

    // ══════════════════════════════════════
    // 4. FLOATING ITEMS (butterflies, flowers)
    // ══════════════════════════════════════
    function createFloatingItems() {
        const container = document.querySelector('.floating-elements');
        if (!container) return;
        const items = ['🌸', '🦋', '✿', '❀', '🌷', '💮', '🌺', '🦋', '🌼', '✾'];
        for (let i = 0; i < 14; i++) {
            const el = document.createElement('div');
            el.classList.add('float-item');
            el.textContent = items[Math.floor(Math.random() * items.length)];
            el.style.left = Math.random() * 100 + '%';
            el.style.bottom = '-30px';
            el.style.fontSize = (Math.random() * 0.8 + 0.8) + 'rem';
            el.style.animationDuration = (Math.random() * 10 + 12) + 's';
            el.style.animationDelay = (Math.random() * 12) + 's';
            container.appendChild(el);
        }
    }
    createFloatingItems();

    // ══════════════════════════════════════
    // 5. FLOATING HEARTS (couple section)
    // ══════════════════════════════════════
    function createHearts() {
        const container = document.querySelector('.floating-hearts');
        if (!container) return;
        for (let i = 0; i < 15; i++) {
            const heart = document.createElement('div');
            heart.classList.add('heart-particle');
            heart.textContent = '♥';
            heart.style.left = Math.random() * 100 + '%';
            heart.style.fontSize = (Math.random() * 0.8 + 0.6) + 'rem';
            heart.style.animationDuration = (Math.random() * 8 + 8) + 's';
            heart.style.animationDelay = (Math.random() * 10) + 's';
            container.appendChild(heart);
        }
    }
    createHearts();

    // ══════════════════════════════════════
    // 6. MUSIC TOGGLE (Web Audio API)
    // ══════════════════════════════════════
    const musicToggle = document.querySelector('.music-toggle');
    let isPlaying = false;
    let audioCtx = null;
    let musicLoop = null;

    function createPianoTone(freq, time, dur) {
        if (!audioCtx) return;
        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, time);
        gain.gain.setValueAtTime(0, time);
        gain.gain.linearRampToValueAtTime(0.025, time + 0.08);
        gain.gain.exponentialRampToValueAtTime(0.001, time + dur);
        osc.connect(gain);
        gain.connect(audioCtx.destination);
        osc.start(time);
        osc.stop(time + dur);
    }

    function playRomanticPiano() {
        audioCtx = new (window.AudioContext || window.webkitAudioContext)();
        const notes = [523.25, 587.33, 659.25, 698.46, 783.99, 880.00, 523.25, 440.00];
        function sequence() {
            const now = audioCtx.currentTime;
            for (let i = 0; i < 5; i++) {
                const note = notes[Math.floor(Math.random() * notes.length)];
                createPianoTone(note, now + i * 1.0, 2.2);
            }
        }
        sequence();
        musicLoop = setInterval(sequence, 5000);
    }

    function stopMusic() {
        if (musicLoop) { clearInterval(musicLoop); musicLoop = null; }
        if (audioCtx) { audioCtx.close(); audioCtx = null; }
    }

    musicToggle.addEventListener('click', () => {
        isPlaying = !isPlaying;
        musicToggle.classList.toggle('playing', isPlaying);
        isPlaying ? playRomanticPiano() : stopMusic();
    });

    // ══════════════════════════════════════
    // 7. BLOOMING FLOWER ANIMATION
    // ══════════════════════════════════════
    const bloomContainer = document.querySelector('.bloom-container');
    const bloomWrapper = document.querySelector('.bloom-wrapper');
    const heroContent = document.querySelector('.hero-content');
    const clickText = document.querySelector('.bloom-click-text');
    let bloomOpened = false;

    bloomContainer.addEventListener('click', () => {
        if (bloomOpened) return;
        bloomOpened = true;
        bloomWrapper.classList.add('bloomed');
        clickText.style.opacity = '0';

        // Wait for petals to bloom open, then fade away
        setTimeout(() => {
            bloomContainer.style.opacity = '0';
            bloomContainer.style.transform = 'scale(1.3)';
            bloomContainer.style.filter = 'blur(10px)';
            bloomContainer.style.transition = 'all 1.2s ease';

            setTimeout(() => {
                bloomContainer.style.display = 'none';
                heroContent.classList.add('visible');
                animateHeroContent();
            }, 1200);
        }, 2200);
    });

    function animateHeroContent() {
        const items = heroContent.querySelectorAll('.hero-animate');
        items.forEach((el, i) => {
            el.style.opacity = '0';
            el.style.transform = 'translateY(25px)';
            el.style.transition = `all 0.8s cubic-bezier(0.4,0,0.2,1) ${i * 0.15}s`;
            requestAnimationFrame(() => {
                el.style.opacity = '1';
                el.style.transform = 'translateY(0)';
            });
        });
    }

    // ══════════════════════════════════════
    // 8. COUNTDOWN TIMER
    // ══════════════════════════════════════
    function startCountdown() {
        const target = new Date('2026-12-20T00:00:00');
        const el = document.querySelector('.countdown-display');
        if (!el) return;

        function update() {
            const now = new Date();
            const diff = target - now;
            if (diff <= 0) {
                el.innerHTML = '<p style="font-family:var(--font-cursive);font-size:1.3rem;color:var(--rose-gold);">The Celebration Has Begun!</p>';
                return;
            }
            const d = Math.floor(diff / 86400000);
            const h = Math.floor((diff / 3600000) % 24);
            const m = Math.floor((diff / 60000) % 60);
            const s = Math.floor((diff / 1000) % 60);
            el.innerHTML = `
                <div class="cd-item"><strong>${d}</strong><span>Days</span></div>
                <div class="cd-sep">·</div>
                <div class="cd-item"><strong>${h}</strong><span>Hours</span></div>
                <div class="cd-sep">·</div>
                <div class="cd-item"><strong>${m}</strong><span>Min</span></div>
                <div class="cd-sep">·</div>
                <div class="cd-item"><strong>${s}</strong><span>Sec</span></div>
            `;
        }
        update();
        setInterval(update, 1000);
    }
    startCountdown();

    // ══════════════════════════════════════
    // 9. SCROLL-TRIGGERED REVEAL
    // ══════════════════════════════════════
    function initRevealAnimations() {
        const els = document.querySelectorAll('.reveal, .reveal-left, .reveal-right, .reveal-scale');
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const parent = entry.target.parentElement;
                    const siblings = parent ? parent.querySelectorAll('.reveal, .reveal-left, .reveal-right, .reveal-scale') : [];
                    const idx = Array.from(siblings).indexOf(entry.target);
                    entry.target.style.transitionDelay = `${idx * 0.08}s`;
                    entry.target.classList.add('active');
                    observer.unobserve(entry.target);
                }
            });
        }, { rootMargin: '0px 0px -60px 0px', threshold: 0.15 });
        els.forEach(el => observer.observe(el));
    }

    // ══════════════════════════════════════
    // 10. PARALLAX ON COUPLE FRAMES
    // ══════════════════════════════════════
    window.addEventListener('scroll', () => {
        document.querySelectorAll('.couple-frame').forEach(f => {
            const r = f.getBoundingClientRect();
            if (r.top < window.innerHeight && r.bottom > 0) {
                f.style.transform = `translateY(${(r.top - window.innerHeight / 2) * 0.04}px)`;
            }
        });
    });

    // ══════════════════════════════════════
    // 11. RSVP FORM HANDLER
    // ══════════════════════════════════════
    const form = document.querySelector('.rsvp-form');
    if (form) {
        form.addEventListener('submit', (e) => {
            e.preventDefault();
            const btn = form.querySelector('.submit-btn');
            const orig = btn.textContent;
            btn.textContent = '✓ RSVP RECEIVED';
            btn.style.background = 'linear-gradient(135deg, #73c8a9, #56b494)';
            setTimeout(() => {
                btn.textContent = orig;
                btn.style.background = '';
                form.reset();
            }, 3000);
        });
    }

    // ══════════════════════════════════════
    // 12. SMOOTH ANCHOR SCROLLING
    // ══════════════════════════════════════
    document.querySelectorAll('a[href^="#"]').forEach(a => {
        a.addEventListener('click', function (e) {
            e.preventDefault();
            const t = document.querySelector(this.getAttribute('href'));
            if (t) {
                window.scrollTo({ top: t.offsetTop - 30, behavior: 'smooth' });
            }
        });
    });

    // ══════════════════════════════════════
    // 13. CLICK SPARKLE
    // ══════════════════════════════════════
    document.addEventListener('click', (e) => {
        for (let i = 0; i < 6; i++) {
            const sp = document.createElement('div');
            const hue = Math.random() > 0.5 ? '340' : '20';
            sp.style.cssText = `
                position:fixed; width:5px; height:5px;
                background:hsl(${hue},70%,75%);
                border-radius:50%; pointer-events:none;
                z-index:99999;
                left:${e.clientX}px; top:${e.clientY}px;
                box-shadow:0 0 6px hsl(${hue},70%,80%);
            `;
            document.body.appendChild(sp);
            const angle = (Math.PI * 2 / 6) * i;
            const v = Math.random() * 50 + 25;
            sp.animate([
                { transform: 'translate(0,0) scale(1)', opacity: 1 },
                { transform: `translate(${Math.cos(angle)*v}px,${Math.sin(angle)*v}px) scale(0)`, opacity: 0 }
            ], { duration: 550, easing: 'ease-out' }).onfinish = () => sp.remove();
        }
    });

    // ══════════════════════════════════════
    // 14. INIT ON FIRST LOAD
    // ══════════════════════════════════════
    setTimeout(initRevealAnimations, 100);

}); // END
