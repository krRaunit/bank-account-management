/* ============================================
   ROYAL INDIAN WEDDING INVITATION - JAVASCRIPT
   Cinematic Animations & Premium Interactions
   ============================================ */

// ───── Wait for DOM ─────
document.addEventListener('DOMContentLoaded', () => {

    // ══════════════════════════════════════
    // 1. PRELOADER
    // ══════════════════════════════════════
    const preloader = document.querySelector('.preloader');
    window.addEventListener('load', () => {
        setTimeout(() => {
            preloader.classList.add('hidden');
            initAnimations();
        }, 1500);
    });

    // ══════════════════════════════════════
    // 2. CURSOR GLOW EFFECT
    // ══════════════════════════════════════
    const cursorGlow = document.querySelector('.cursor-glow');
    if (cursorGlow && window.innerWidth > 768) {
        document.addEventListener('mousemove', (e) => {
            cursorGlow.style.left = e.clientX + 'px';
            cursorGlow.style.top = e.clientY + 'px';
        });
    }

    // ══════════════════════════════════════
    // 3. GOLDEN PARTICLES CANVAS
    // ══════════════════════════════════════
    const canvas = document.getElementById('particles-canvas');
    const ctx = canvas.getContext('2d');
    let particles = [];

    function resizeCanvas() {
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
    }
    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);

    class Particle {
        constructor() {
            this.reset();
        }
        reset() {
            this.x = Math.random() * canvas.width;
            this.y = Math.random() * canvas.height;
            this.size = Math.random() * 2.5 + 0.5;
            this.speedX = (Math.random() - 0.5) * 0.5;
            this.speedY = (Math.random() - 0.5) * 0.3;
            this.opacity = Math.random() * 0.5 + 0.1;
            this.fadeSpeed = Math.random() * 0.005 + 0.002;
            this.growing = Math.random() > 0.5;
        }
        update() {
            this.x += this.speedX;
            this.y += this.speedY;

            if (this.growing) {
                this.opacity += this.fadeSpeed;
                if (this.opacity >= 0.6) this.growing = false;
            } else {
                this.opacity -= this.fadeSpeed;
                if (this.opacity <= 0.05) this.growing = true;
            }

            if (this.x < 0 || this.x > canvas.width || this.y < 0 || this.y > canvas.height) {
                this.reset();
            }
        }
        draw() {
            ctx.beginPath();
            ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
            ctx.fillStyle = `rgba(212, 175, 55, ${this.opacity})`;
            ctx.fill();
            // Glow
            ctx.beginPath();
            ctx.arc(this.x, this.y, this.size * 3, 0, Math.PI * 2);
            ctx.fillStyle = `rgba(212, 175, 55, ${this.opacity * 0.15})`;
            ctx.fill();
        }
    }

    function initParticles() {
        const count = Math.min(80, Math.floor(window.innerWidth / 15));
        for (let i = 0; i < count; i++) {
            particles.push(new Particle());
        }
    }

    function animateParticles() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        particles.forEach(p => {
            p.update();
            p.draw();
        });
        requestAnimationFrame(animateParticles);
    }

    initParticles();
    animateParticles();

    // ══════════════════════════════════════
    // 5. MUSIC TOGGLE
    // ══════════════════════════════════════
    const musicToggle = document.querySelector('.music-toggle');
    let isPlaying = false;

    // Create AudioContext for generated music
    let audioContext = null;
    let musicInterval = null;

    function createSoftTone(freq, startTime, duration) {
        if (!audioContext) return;
        const osc = audioContext.createOscillator();
        const gain = audioContext.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, startTime);
        gain.gain.setValueAtTime(0, startTime);
        gain.gain.linearRampToValueAtTime(0.03, startTime + 0.1);
        gain.gain.linearRampToValueAtTime(0, startTime + duration);
        osc.connect(gain);
        gain.connect(audioContext.destination);
        osc.start(startTime);
        osc.stop(startTime + duration);
    }

    function playAmbientMusic() {
        if (!audioContext) {
            audioContext = new (window.AudioContext || window.webkitAudioContext)();
        }
        // Indian-inspired pentatonic notes
        const notes = [261.63, 293.66, 329.63, 392.00, 440.00, 523.25, 587.33];
        let t = audioContext.currentTime;

        function playSequence() {
            const now = audioContext.currentTime;
            for (let i = 0; i < 4; i++) {
                const note = notes[Math.floor(Math.random() * notes.length)];
                createSoftTone(note, now + i * 1.2, 2.0);
            }
        }
        playSequence();
        musicInterval = setInterval(playSequence, 4800);
    }

    function stopMusic() {
        if (musicInterval) {
            clearInterval(musicInterval);
            musicInterval = null;
        }
        if (audioContext) {
            audioContext.close();
            audioContext = null;
        }
    }

    musicToggle.addEventListener('click', () => {
        isPlaying = !isPlaying;
        musicToggle.classList.toggle('playing', isPlaying);
        if (isPlaying) {
            playAmbientMusic();
        } else {
            stopMusic();
        }
    });

    // ══════════════════════════════════════
    // 6. ENVELOPE ANIMATION
    // ══════════════════════════════════════
    const envelopeContainer = document.querySelector('.envelope-container');
    const envelopeWrapper = document.querySelector('.envelope-wrapper');
    const heroContent = document.querySelector('.hero-content');
    const clickText = document.querySelector('.envelope-click-text');
    let envelopeOpened = false;

    envelopeContainer.addEventListener('click', () => {
        if (envelopeOpened) return;
        envelopeOpened = true;
        envelopeWrapper.classList.add('opened');
        clickText.style.opacity = '0';

        // After envelope animation, show hero content
        setTimeout(() => {
            envelopeContainer.style.opacity = '0';
            envelopeContainer.style.transform = 'scale(0.8)';
            envelopeContainer.style.transition = 'all 0.8s ease';

            setTimeout(() => {
                envelopeContainer.style.display = 'none';
                heroContent.classList.add('visible');
                animateHeroContent();
            }, 800);
        }, 2200);
    });

    // ══════════════════════════════════════
    // 7. HERO CONTENT ANIMATIONS (GSAP-LIKE)
    // ══════════════════════════════════════
    function animateHeroContent() {
        const elements = heroContent.querySelectorAll('.hero-animate');
        elements.forEach((el, i) => {
            el.style.opacity = '0';
            el.style.transform = 'translateY(30px)';
            el.style.transition = `all 0.8s cubic-bezier(0.4, 0, 0.2, 1) ${i * 0.2}s`;
            setTimeout(() => {
                el.style.opacity = '1';
                el.style.transform = 'translateY(0)';
            }, 50);
        });
    }

    // ══════════════════════════════════════
    // 8. FLOATING LANTERNS
    // ══════════════════════════════════════
    function createLanterns() {
        const container = document.querySelector('.floating-lanterns');
        if (!container) return;
        const count = 8;
        for (let i = 0; i < count; i++) {
            const lantern = document.createElement('div');
            lantern.classList.add('lantern');
            lantern.style.left = Math.random() * 100 + '%';
            lantern.style.animationDuration = (Math.random() * 8 + 10) + 's';
            lantern.style.animationDelay = (Math.random() * 10) + 's';
            lantern.style.opacity = Math.random() * 0.5 + 0.3;
            container.appendChild(lantern);
        }
    }
    createLanterns();

    // ══════════════════════════════════════
    // 9. ROSE PETALS ANIMATION
    // ══════════════════════════════════════
    function createPetals() {
        const container = document.querySelector('.rose-petals');
        if (!container) return;
        const count = 20;
        for (let i = 0; i < count; i++) {
            const petal = document.createElement('div');
            petal.classList.add('petal');
            petal.style.left = Math.random() * 100 + '%';
            petal.style.animationDuration = (Math.random() * 6 + 6) + 's';
            petal.style.animationDelay = (Math.random() * 8) + 's';
            petal.style.width = (Math.random() * 10 + 8) + 'px';
            petal.style.height = (Math.random() * 10 + 8) + 'px';
            container.appendChild(petal);
        }
    }
    createPetals();

    // ══════════════════════════════════════
    // 10. SCROLL-TRIGGERED REVEAL ANIMATIONS
    // ══════════════════════════════════════
    function initAnimations() {
        const revealElements = document.querySelectorAll('.reveal, .reveal-left, .reveal-right, .reveal-scale');

        const observerOptions = {
            root: null,
            rootMargin: '0px 0px -80px 0px',
            threshold: 0.15
        };

        const revealObserver = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    // Add stagger delay for items in a group
                    const parent = entry.target.parentElement;
                    const siblings = parent ? parent.querySelectorAll('.reveal, .reveal-left, .reveal-right, .reveal-scale') : [];
                    const index = Array.from(siblings).indexOf(entry.target);
                    entry.target.style.transitionDelay = `${index * 0.1}s`;
                    entry.target.classList.add('active');
                    revealObserver.unobserve(entry.target);
                }
            });
        }, observerOptions);

        revealElements.forEach(el => revealObserver.observe(el));
    }

    // ══════════════════════════════════════
    // 11. PARALLAX SCROLL EFFECT
    // ══════════════════════════════════════
    window.addEventListener('scroll', () => {
        const scrolled = window.scrollY;

        // Parallax on couple frames
        document.querySelectorAll('.couple-frame').forEach(frame => {
            const rect = frame.getBoundingClientRect();
            if (rect.top < window.innerHeight && rect.bottom > 0) {
                const offset = (rect.top - window.innerHeight / 2) * 0.05;
                frame.style.transform = `translateY(${offset}px)`;
            }
        });
    });

    // ══════════════════════════════════════
    // 12. RSVP FORM HANDLER
    // ══════════════════════════════════════
    const contactForm = document.querySelector('.contact-form');
    if (contactForm) {
        contactForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const btn = contactForm.querySelector('.submit-btn');
            const originalText = btn.textContent;
            btn.textContent = '✓ RSVP RECEIVED';
            btn.style.background = 'linear-gradient(135deg, #2ecc71, #27ae60)';
            btn.style.color = '#fff';
            setTimeout(() => {
                btn.textContent = originalText;
                btn.style.background = '';
                btn.style.color = '';
                contactForm.reset();
            }, 3000);
        });
    }

    // ══════════════════════════════════════
    // 15. SMOOTH SCROLLING FOR NAV LINKS
    // ══════════════════════════════════════
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                const offset = 80;
                const y = target.getBoundingClientRect().top + window.scrollY - offset;
                window.scrollTo({ top: y, behavior: 'smooth' });
            }
        });
    });

    // ══════════════════════════════════════
    // 16. GOLDEN DUST SPARKLE ON CLICK
    // ══════════════════════════════════════
    document.addEventListener('click', (e) => {
        for (let i = 0; i < 8; i++) {
            const sparkle = document.createElement('div');
            sparkle.style.cssText = `
                position: fixed;
                width: 4px;
                height: 4px;
                background: #d4af37;
                border-radius: 50%;
                pointer-events: none;
                z-index: 99999;
                left: ${e.clientX}px;
                top: ${e.clientY}px;
                box-shadow: 0 0 6px #d4af37;
            `;
            document.body.appendChild(sparkle);

            const angle = (Math.PI * 2 / 8) * i;
            const velocity = Math.random() * 60 + 30;
            const dx = Math.cos(angle) * velocity;
            const dy = Math.sin(angle) * velocity;

            sparkle.animate([
                { transform: 'translate(0, 0) scale(1)', opacity: 1 },
                { transform: `translate(${dx}px, ${dy}px) scale(0)`, opacity: 0 }
            ], {
                duration: 600,
                easing: 'cubic-bezier(0, 0.5, 0.5, 1)'
            }).onfinish = () => sparkle.remove();
        }
    });

    // ══════════════════════════════════════
    // 17. COUNTER ANIMATION FOR DATE
    // ══════════════════════════════════════
    function animateCountdown() {
        const weddingDate = new Date('2026-12-15T00:00:00');
        const countdownEl = document.querySelector('.countdown-display');
        if (!countdownEl) return;

        function update() {
            const now = new Date();
            const diff = weddingDate - now;
            if (diff <= 0) {
                countdownEl.textContent = 'The Celebration Has Begun!';
                return;
            }
            const days = Math.floor(diff / (1000 * 60 * 60 * 24));
            const hours = Math.floor((diff / (1000 * 60 * 60)) % 24);
            const minutes = Math.floor((diff / (1000 * 60)) % 60);
            const seconds = Math.floor((diff / 1000) % 60);

            countdownEl.innerHTML = `
                <span class="cd-item"><strong>${days}</strong> Days</span>
                <span class="cd-sep">•</span>
                <span class="cd-item"><strong>${hours}</strong> Hours</span>
                <span class="cd-sep">•</span>
                <span class="cd-item"><strong>${minutes}</strong> Min</span>
                <span class="cd-sep">•</span>
                <span class="cd-item"><strong>${seconds}</strong> Sec</span>
            `;
        }
        update();
        setInterval(update, 1000);
    }
    animateCountdown();

    // ══════════════════════════════════════
    // 18. TYPED TEXT EFFECT (for hero subtitle)
    // ══════════════════════════════════════
    function typeWriter(element, text, speed = 60) {
        if (!element) return;
        let i = 0;
        element.textContent = '';
        function type() {
            if (i < text.length) {
                element.textContent += text.charAt(i);
                i++;
                setTimeout(type, speed);
            }
        }
        type();
    }

    // ══════════════════════════════════════
    // 19. INITIALIZE ALL ON LOAD
    // ══════════════════════════════════════
    // Trigger initial reveal check
    setTimeout(() => {
        initAnimations();
    }, 100);

}); // End DOMContentLoaded
