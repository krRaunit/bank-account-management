/* ============================================================
   ROYAL INDIAN WEDDING INVITATION — Main Script
   GSAP animations · Butterfly paths · Scratch card ·
   Sound FX · Particles · Scroll reveals
   ============================================================ */

(function () {
  'use strict';

  /* ----------------------------------------------------------
     0. AUDIO CONTEXT — Sound Effects
     ---------------------------------------------------------- */
  let audioCtx = null;

  function getAudioCtx() {
    if (!audioCtx) audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    return audioCtx;
  }

  function playTone(freq, duration, type, vol) {
    try {
      const ctx  = getAudioCtx();
      const osc  = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.type = type || 'sine';
      osc.frequency.value = freq;
      gain.gain.setValueAtTime(vol || 0.18, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + duration);
      osc.start();
      osc.stop(ctx.currentTime + duration);
    } catch (_) { /* silent fail */ }
  }

  function playChime() {
    [523.25, 659.25, 783.99, 1046.5].forEach(function (f, i) {
      setTimeout(function () { playTone(f, 1.4, 'sine', 0.12); }, i * 180);
    });
  }

  function playRevealSound() {
    [783.99, 987.77, 1174.66, 1318.51].forEach(function (f, i) {
      setTimeout(function () { playTone(f, 1.0, 'triangle', 0.10); }, i * 120);
    });
  }

  function playSoftBell() {
    playTone(1174.66, 0.8, 'sine', 0.08);
  }

  /* Ambient background music using oscillators */
  let ambientNodes = [];
  let musicPlaying = false;

  function startAmbientMusic() {
    if (musicPlaying) return;
    try {
      const ctx = getAudioCtx();
      const notes = [261.63, 329.63, 392.00, 523.25];
      notes.forEach(function (freq, idx) {
        const osc  = ctx.createOscillator();
        const gain = ctx.createGain();
        const lfo  = ctx.createOscillator();
        const lfoGain = ctx.createGain();

        osc.type = 'sine';
        osc.frequency.value = freq;

        lfo.type = 'sine';
        lfo.frequency.value = 0.15 + idx * 0.05;
        lfoGain.gain.value = 0.04;

        lfo.connect(lfoGain);
        lfoGain.connect(gain.gain);
        osc.connect(gain);
        gain.connect(ctx.destination);
        gain.gain.value = 0.03;

        osc.start();
        lfo.start();
        ambientNodes.push({ osc: osc, lfo: lfo, gain: gain });
      });
      musicPlaying = true;
    } catch (_) { /* silent fail */ }
  }

  function stopAmbientMusic() {
    ambientNodes.forEach(function (n) {
      try { n.osc.stop(); n.lfo.stop(); } catch (_) {}
    });
    ambientNodes = [];
    musicPlaying = false;
  }

  /* ----------------------------------------------------------
     1. PARTICLES — floating gold dust
     ---------------------------------------------------------- */
  function createParticles(count) {
    var container = document.getElementById('particles');
    if (!container) return;
    for (var i = 0; i < (count || 45); i++) {
      var p = document.createElement('div');
      p.className = 'particle';
      p.style.left = Math.random() * 100 + '%';
      p.style.bottom = '-10px';
      var size = 2 + Math.random() * 4;
      p.style.width = size + 'px';
      p.style.height = size + 'px';
      p.style.animationDuration = (8 + Math.random() * 14) + 's';
      p.style.animationDelay = (Math.random() * 12) + 's';
      container.appendChild(p);
    }
  }

  /* ----------------------------------------------------------
     2. PETALS — rose petals falling when card opens
     ---------------------------------------------------------- */
  function spawnPetals(count) {
    for (var i = 0; i < (count || 30); i++) {
      var petal = document.createElement('div');
      petal.className = 'petal';
      petal.style.left = Math.random() * 100 + 'vw';
      petal.style.top  = '-20px';
      var hue = Math.random() > 0.5 ? 340 : (20 + Math.random() * 30);
      petal.style.background = 'hsl(' + hue + ', 70%, 55%)';
      petal.style.width  = (10 + Math.random() * 8) + 'px';
      petal.style.height = (10 + Math.random() * 8) + 'px';
      petal.style.transform = 'rotate(' + (Math.random() * 360) + 'deg)';
      document.body.appendChild(petal);

      gsap.to(petal, {
        y: window.innerHeight + 40,
        x: (Math.random() - 0.5) * 200,
        rotation: Math.random() * 720,
        opacity: 0.7,
        duration: 3 + Math.random() * 3,
        delay: Math.random() * 2,
        ease: 'power1.in',
        onComplete: function () { if (petal.parentNode) petal.parentNode.removeChild(petal); }
      });
    }
  }

  /* ----------------------------------------------------------
     3. CONFETTI burst
     ---------------------------------------------------------- */
  function burstConfetti(cx, cy, count) {
    var colors = ['#C9A84C','#FFD700','#C2185B','#E91E63','#F48FB1','#B8860B','#64B5F6'];
    for (var i = 0; i < (count || 60); i++) {
      var c = document.createElement('div');
      c.className = 'confetti';
      c.style.left = cx + 'px';
      c.style.top  = cy + 'px';
      c.style.background = colors[Math.floor(Math.random() * colors.length)];
      c.style.width  = (5 + Math.random() * 6) + 'px';
      c.style.height = (5 + Math.random() * 6) + 'px';
      c.style.borderRadius = Math.random() > 0.5 ? '50%' : '1px';
      document.body.appendChild(c);

      gsap.to(c, {
        x: (Math.random() - 0.5) * 400,
        y: (Math.random() - 0.5) * 400,
        rotation: Math.random() * 720,
        opacity: 0,
        duration: 1.2 + Math.random() * 1.4,
        ease: 'power2.out',
        onComplete: function () { if (c.parentNode) c.parentNode.removeChild(c); }
      });
    }
  }

  /* ----------------------------------------------------------
     4. CARD OPEN ANIMATION
     ---------------------------------------------------------- */
  function openCard() {
    var wrapper      = document.getElementById('cover-wrapper');
    var content      = document.getElementById('cover-content');
    var doorLeft     = wrapper.querySelector('.door-left');
    var doorRight    = wrapper.querySelector('.door-right');
    var invitation   = document.getElementById('invitation');
    var musicBtn     = document.getElementById('musicToggle');

    // Play opening sound
    playChime();

    var tl = gsap.timeline({
      onComplete: function () {
        wrapper.style.display = 'none';
        wrapper.style.pointerEvents = 'none';
        document.body.style.overflow = '';
        // Show music button
        musicBtn.classList.remove('hidden');
        // Start ambient
        startAmbientMusic();
        musicBtn.classList.add('playing');
      }
    });

    // Phase 1: fade cover text
    tl.to(content, { opacity: 0, scale: 0.92, duration: 0.5, ease: 'power2.in' });

    // Phase 2: swing doors open
    tl.to(doorLeft,  { rotateY: -110, duration: 1.2, ease: 'power3.inOut' }, '-=0.1');
    tl.to(doorRight, { rotateY:  110, duration: 1.2, ease: 'power3.inOut' }, '<');

    // Phase 3: fade out doors, reveal invitation
    tl.to([doorLeft, doorRight], { opacity: 0, duration: 0.4 }, '-=0.3');
    tl.add(function () {
      invitation.classList.remove('hidden');
      spawnPetals(35);
      burstConfetti(window.innerWidth / 2, window.innerHeight / 2, 70);
    });

    // Phase 4: invitation fades in
    tl.from(invitation, { opacity: 0, y: 30, duration: 0.8, ease: 'power2.out' });

    // Phase 5: butterflies
    tl.add(function () { animateButterflies(); }, '-=0.4');

    // Phase 6: start scroll-triggered reveals
    tl.add(function () { initScrollReveals(); }, '-=0.2');
  }

  /* ----------------------------------------------------------
     5. BUTTERFLIES — GSAP path animation
     ---------------------------------------------------------- */
  function animateButterflies() {
    var pink = document.getElementById('butterflyPink');
    var blue = document.getElementById('butterflyBlue');
    if (!pink || !blue) return;

    // Starting positions (center of screen)
    var cx = window.innerWidth  / 2;
    var cy = window.innerHeight / 2;

    [pink, blue].forEach(function (el, idx) {
      gsap.set(el, { x: cx, y: cy, opacity: 0 });
      gsap.to(el, { opacity: 1, duration: 0.6, delay: idx * 0.3 });

      // Infinite wander
      wanderButterfly(el, idx);
    });
  }

  function wanderButterfly(el, seed) {
    var vw = window.innerWidth;
    var vh = window.innerHeight;
    var dur = 4 + Math.random() * 3;

    // Pick random target within viewport
    var tx = 40 + Math.random() * (vw - 120);
    var ty = 40 + Math.random() * (vh - 120);

    gsap.to(el, {
      x: tx,
      y: ty,
      duration: dur,
      ease: 'sine.inOut',
      onComplete: function () { wanderButterfly(el, seed); }
    });
  }

  /* ----------------------------------------------------------
     6. SCRATCH CARD
     ---------------------------------------------------------- */
  function initScratchCard() {
    var canvas = document.getElementById('scratchCard');
    if (!canvas) return;
    var ctx = canvas.getContext('2d');

    // Match container size
    var wrapper = canvas.parentElement;
    canvas.width  = wrapper.offsetWidth;
    canvas.height = wrapper.offsetHeight;

    // Draw gold scratch surface
    var grad = ctx.createLinearGradient(0, 0, canvas.width, canvas.height);
    grad.addColorStop(0, '#C9A84C');
    grad.addColorStop(0.3, '#FFD700');
    grad.addColorStop(0.6, '#DAA520');
    grad.addColorStop(1, '#B8860B');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Ornate pattern on scratch surface
    ctx.strokeStyle = 'rgba(255,248,231,0.25)';
    ctx.lineWidth = 1;
    for (var i = 0; i < 20; i++) {
      ctx.beginPath();
      ctx.arc(
        canvas.width / 2 + (Math.random() - 0.5) * canvas.width * 0.6,
        canvas.height / 2 + (Math.random() - 0.5) * canvas.height * 0.6,
        20 + Math.random() * 40, 0, Math.PI * 2
      );
      ctx.stroke();
    }

    // "Scratch Here" text
    ctx.fillStyle = 'rgba(255,248,231,0.85)';
    ctx.font = 'bold 18px "Playfair Display", serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('✨ Scratch Here ✨', canvas.width / 2, canvas.height / 2);

    // Scratch logic
    var isDown = false;
    var revealed = false;

    function getPos(e) {
      var rect = canvas.getBoundingClientRect();
      var cx = e.touches ? e.touches[0].clientX : e.clientX;
      var cy = e.touches ? e.touches[0].clientY : e.clientY;
      return { x: cx - rect.left, y: cy - rect.top };
    }

    function scratch(pos) {
      ctx.globalCompositeOperation = 'destination-out';
      ctx.beginPath();
      ctx.arc(pos.x, pos.y, 22, 0, Math.PI * 2);
      ctx.fill();
      checkReveal();
    }

    function checkReveal() {
      if (revealed) return;
      var data = ctx.getImageData(0, 0, canvas.width, canvas.height).data;
      var total = data.length / 4;
      var transparent = 0;
      for (var i = 3; i < data.length; i += 4) {
        if (data[i] === 0) transparent++;
      }
      if (transparent / total > 0.45) {
        revealed = true;
        gsap.to(canvas, { opacity: 0, duration: 0.6 });
        playRevealSound();
        var sr = document.getElementById('scratchReveal');
        if (sr) {
          burstConfetti(
            sr.getBoundingClientRect().left + sr.offsetWidth / 2,
            sr.getBoundingClientRect().top + sr.offsetHeight / 2,
            50
          );
        }
      }
    }

    // Mouse events
    canvas.addEventListener('mousedown', function (e) { isDown = true; scratch(getPos(e)); });
    canvas.addEventListener('mousemove', function (e) { if (isDown) scratch(getPos(e)); });
    canvas.addEventListener('mouseup', function ()    { isDown = false; });
    canvas.addEventListener('mouseleave', function () { isDown = false; });

    // Touch events
    canvas.addEventListener('touchstart', function (e) { e.preventDefault(); isDown = true; scratch(getPos(e)); }, { passive: false });
    canvas.addEventListener('touchmove',  function (e) { e.preventDefault(); if (isDown) scratch(getPos(e)); }, { passive: false });
    canvas.addEventListener('touchend',   function ()  { isDown = false; });
  }

  /* ----------------------------------------------------------
     7. SCROLL REVEALS — event cards + sections
     ---------------------------------------------------------- */
  function initScrollReveals() {
    gsap.registerPlugin(ScrollTrigger);

    // Welcome section
    gsap.utils.toArray('.family-card').forEach(function (card, i) {
      gsap.from(card, {
        scrollTrigger: { trigger: card, start: 'top 85%', toggleActions: 'play none none none' },
        opacity: 0, y: 50, duration: 0.7, delay: i * 0.2, ease: 'power2.out'
      });
    });

    // Event cards
    gsap.utils.toArray('.event-card').forEach(function (card, i) {
      gsap.to(card, {
        scrollTrigger: { trigger: card, start: 'top 85%', toggleActions: 'play none none none' },
        opacity: 1, y: 0, duration: 0.7, delay: i * 0.1, ease: 'power2.out',
        onStart: function () { playSoftBell(); }
      });
    });

    // Section headings
    gsap.utils.toArray('.section-heading').forEach(function (h) {
      gsap.from(h, {
        scrollTrigger: { trigger: h, start: 'top 88%', toggleActions: 'play none none none' },
        opacity: 0, y: 20, duration: 0.6, ease: 'power2.out'
      });
    });

    // Footer
    gsap.from('.footer-quote', {
      scrollTrigger: { trigger: '.footer-quote', start: 'top 88%' },
      opacity: 0, y: 20, duration: 0.7
    });
    gsap.from('.couple-mono', {
      scrollTrigger: { trigger: '.couple-mono', start: 'top 88%' },
      opacity: 0, scale: 0.5, duration: 0.8, ease: 'back.out(1.7)'
    });

    // Init scratch card once section is visible
    ScrollTrigger.create({
      trigger: '.scratch-section',
      start: 'top 80%',
      once: true,
      onEnter: function () { initScratchCard(); }
    });
  }

  /* ----------------------------------------------------------
     8. MUSIC TOGGLE
     ---------------------------------------------------------- */
  function initMusicToggle() {
    var btn = document.getElementById('musicToggle');
    if (!btn) return;
    btn.addEventListener('click', function () {
      if (musicPlaying) {
        stopAmbientMusic();
        btn.classList.remove('playing');
        btn.textContent = '🔇';
      } else {
        startAmbientMusic();
        btn.classList.add('playing');
        btn.textContent = '🎵';
      }
    });
  }

  /* ----------------------------------------------------------
     9. INIT
     ---------------------------------------------------------- */
  function init() {
    // Prevent scroll while cover is showing
    document.body.style.overflow = 'hidden';

    // Particles in background
    createParticles(50);

    // Cover tap handler
    var tap = document.getElementById('tapToOpen');
    if (tap) {
      tap.addEventListener('click', function handler() {
        tap.removeEventListener('click', handler);
        openCard();
      });
    }

    // Music toggle
    initMusicToggle();

    // Animate cover content entrance
    gsap.from('.ganesh-text',  { opacity: 0, y: -20, duration: 0.8, delay: 0.2 });
    gsap.from('.cover-mandala',{ opacity: 0, scale: 0.4, duration: 1, delay: 0.4, ease: 'back.out(1.7)' });
    gsap.from('.cover-names',  { opacity: 0, y: 20, duration: 0.8, delay: 0.7 });
    gsap.from('.cover-tagline',{ opacity: 0, duration: 0.6, delay: 1.0 });
    gsap.from('.tap-to-open',  { opacity: 0, scale: 0.6, duration: 0.8, delay: 1.3, ease: 'back.out(1.7)' });

    // Corner ornaments shimmer
    gsap.utils.toArray('.corner-ornament').forEach(function (el, i) {
      gsap.from(el, { opacity: 0, scale: 0, duration: 0.5, delay: 0.3 + i * 0.15, ease: 'back.out(2)' });
    });
  }

  // Start when DOM ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
