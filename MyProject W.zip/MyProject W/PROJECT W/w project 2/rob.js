/* ============================================================
   ROYAL WEDDING INVITATION — Enhanced Script
   Colorful particles · Sparkles · Butterflies · Scratch card ·
   Trail effects · GSAP scroll reveals · Sound FX
   ============================================================ */

(function () {
  'use strict';

  /* ----------------------------------------------------------
     0. AUDIO — Sound Effects via Web Audio API
     ---------------------------------------------------------- */
  let audioCtx = null;

  function getAudioCtx() {
    if (!audioCtx) audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    return audioCtx;
  }

  function playTone(freq, dur, type, vol) {
    try {
      const ctx = getAudioCtx();
      const osc = ctx.createOscillator();
      const g   = ctx.createGain();
      osc.connect(g); g.connect(ctx.destination);
      osc.type = type || 'sine';
      osc.frequency.value = freq;
      g.gain.setValueAtTime(vol || 0.15, ctx.currentTime);
      g.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + dur);
      osc.start(); osc.stop(ctx.currentTime + dur);
    } catch (_) {}
  }

  function playOpenChime() {
    [523.25, 659.25, 783.99, 1046.5, 1318.51].forEach(function (f, i) {
      setTimeout(function () { playTone(f, 1.6, 'sine', 0.10); }, i * 160);
    });
  }

  function playRevealSound() {
    [783.99, 987.77, 1174.66, 1318.51, 1567.98].forEach(function (f, i) {
      setTimeout(function () { playTone(f, 0.9, 'triangle', 0.08); }, i * 110);
    });
  }

  function playSoftBell()   { playTone(1174.66, 0.7, 'sine', 0.06); }
  function playTinkle()     { playTone(2093.00, 0.3, 'sine', 0.05); }

  /* Ambient music */
  let ambientNodes = [];
  let musicPlaying = false;

  function startAmbientMusic() {
    if (musicPlaying) return;
    try {
      const ctx = getAudioCtx();
      const chords = [
        { f: 261.63, t: 'sine' },
        { f: 329.63, t: 'sine' },
        { f: 392.00, t: 'triangle' },
        { f: 523.25, t: 'sine' },
        { f: 196.00, t: 'sine' }
      ];
      chords.forEach(function (note, idx) {
        const osc = ctx.createOscillator();
        const g   = ctx.createGain();
        const lfo = ctx.createOscillator();
        const lg  = ctx.createGain();
        osc.type = note.t;
        osc.frequency.value = note.f;
        lfo.type = 'sine';
        lfo.frequency.value = 0.12 + idx * 0.04;
        lg.gain.value = 0.03;
        lfo.connect(lg); lg.connect(g.gain);
        osc.connect(g); g.connect(ctx.destination);
        g.gain.value = 0.022;
        osc.start(); lfo.start();
        ambientNodes.push({ osc: osc, lfo: lfo, gain: g });
      });
      musicPlaying = true;
    } catch (_) {}
  }

  function stopAmbientMusic() {
    ambientNodes.forEach(function (n) {
      try { n.osc.stop(); n.lfo.stop(); } catch (_) {}
    });
    ambientNodes = [];
    musicPlaying = false;
  }

  /* ----------------------------------------------------------
     1. MULTI-COLOR PARTICLES
     ---------------------------------------------------------- */
  function createParticles(count) {
    var container = document.getElementById('particles');
    if (!container) return;
    var types = ['gold', 'pink', 'blue'];
    for (var i = 0; i < (count || 65); i++) {
      var p = document.createElement('div');
      p.className = 'particle ' + types[i % 3];
      p.style.left = Math.random() * 100 + '%';
      p.style.bottom = '-10px';
      var size = 2 + Math.random() * 5;
      p.style.width = size + 'px';
      p.style.height = size + 'px';
      p.style.animationDuration = (7 + Math.random() * 15) + 's';
      p.style.animationDelay = (Math.random() * 14) + 's';
      container.appendChild(p);
    }
  }

  /* ----------------------------------------------------------
     2. SPARKLES — twinkling stars
     ---------------------------------------------------------- */
  function createSparkles(count) {
    var container = document.getElementById('sparkles');
    if (!container) return;
    for (var i = 0; i < (count || 40); i++) {
      var s = document.createElement('div');
      s.className = 'sparkle';
      s.style.left = Math.random() * 100 + '%';
      s.style.top  = Math.random() * 100 + '%';
      var size = 2 + Math.random() * 3;
      s.style.width = size + 'px';
      s.style.height = size + 'px';
      s.style.animationDuration = (1.5 + Math.random() * 3) + 's';
      s.style.animationDelay = (Math.random() * 4) + 's';
      // Random sparkle color
      var colors = ['#FFD700', '#FF4081', '#448AFF', '#FFFFFF', '#FF80AB', '#82B1FF'];
      s.style.background = colors[Math.floor(Math.random() * colors.length)];
      s.style.boxShadow = '0 0 6px ' + s.style.background;
      container.appendChild(s);
    }
  }

  /* ----------------------------------------------------------
     3. PETALS — multi-color falling petals on card open
     ---------------------------------------------------------- */
  function spawnPetals(count) {
    var petalColors = ['#D81B60', '#F06292', '#1565C0', '#42A5F5', '#FFD700', '#FF4081', '#82B1FF'];
    for (var i = 0; i < (count || 45); i++) {
      var petal = document.createElement('div');
      petal.className = 'petal';
      petal.style.left = Math.random() * 100 + 'vw';
      petal.style.top  = '-20px';
      petal.style.background = petalColors[Math.floor(Math.random() * petalColors.length)];
      var size = 10 + Math.random() * 10;
      petal.style.width  = size + 'px';
      petal.style.height = size + 'px';
      petal.style.transform = 'rotate(' + (Math.random() * 360) + 'deg)';
      petal.style.boxShadow = '0 0 6px ' + petal.style.background;
      document.body.appendChild(petal);

      gsap.to(petal, {
        y: window.innerHeight + 60,
        x: (Math.random() - 0.5) * 260,
        rotation: Math.random() * 900,
        opacity: 0.8,
        duration: 3 + Math.random() * 4,
        delay: Math.random() * 2.5,
        ease: 'power1.in',
        onComplete: function () { if (petal.parentNode) petal.parentNode.removeChild(petal); }
      });
    }
  }

  /* ----------------------------------------------------------
     4. CONFETTI — colorful burst
     ---------------------------------------------------------- */
  function burstConfetti(cx, cy, count) {
    var colors = ['#FFD700','#D81B60','#1565C0','#FF4081','#42A5F5','#FF80AB','#82B1FF','#FFE082','#F06292','#448AFF'];
    for (var i = 0; i < (count || 80); i++) {
      var c = document.createElement('div');
      c.className = 'confetti';
      c.style.left = cx + 'px';
      c.style.top  = cy + 'px';
      c.style.background = colors[Math.floor(Math.random() * colors.length)];
      var s = 4 + Math.random() * 8;
      c.style.width  = s + 'px';
      c.style.height = s + 'px';
      c.style.borderRadius = Math.random() > 0.4 ? '50%' : '2px';
      c.style.boxShadow = '0 0 4px ' + c.style.background;
      document.body.appendChild(c);

      gsap.to(c, {
        x: (Math.random() - 0.5) * 500,
        y: (Math.random() - 0.5) * 500,
        rotation: Math.random() * 900,
        opacity: 0,
        duration: 1.4 + Math.random() * 1.6,
        ease: 'power2.out',
        onComplete: function () { if (c.parentNode) c.parentNode.removeChild(c); }
      });
    }
  }

  /* Firework-style starburst */
  function starburst(cx, cy) {
    var n = 12;
    for (var i = 0; i < n; i++) {
      var angle = (i / n) * Math.PI * 2;
      var dot = document.createElement('div');
      dot.className = 'confetti';
      dot.style.left = cx + 'px';
      dot.style.top  = cy + 'px';
      dot.style.width = '5px';
      dot.style.height = '5px';
      dot.style.borderRadius = '50%';
      dot.style.background = i % 2 === 0 ? '#FFD700' : (i % 3 === 0 ? '#FF4081' : '#42A5F5');
      dot.style.boxShadow = '0 0 8px ' + dot.style.background;
      document.body.appendChild(dot);

      gsap.to(dot, {
        x: Math.cos(angle) * 180,
        y: Math.sin(angle) * 180,
        opacity: 0,
        duration: 1,
        ease: 'power2.out',
        onComplete: function () { if (dot.parentNode) dot.parentNode.removeChild(dot); }
      });
    }
  }

  /* ----------------------------------------------------------
     5. CARD OPEN ANIMATION
     ---------------------------------------------------------- */
  function openCard() {
    var wrapper    = document.getElementById('cover-wrapper');
    var content    = document.getElementById('cover-content');
    var doorLeft   = wrapper.querySelector('.door-left');
    var doorRight  = wrapper.querySelector('.door-right');
    var invitation = document.getElementById('invitation');
    var musicBtn   = document.getElementById('musicToggle');

    playOpenChime();

    var tl = gsap.timeline({
      onComplete: function () {
        wrapper.style.display = 'none';
        document.body.style.overflow = '';
        musicBtn.classList.remove('hidden');
        startAmbientMusic();
        musicBtn.classList.add('playing');
      }
    });

    // Fade cover text with scale + blur feel
    tl.to(content, { opacity: 0, scale: 0.88, duration: 0.6, ease: 'power3.in' });

    // Swing doors with 3D rotate — pink left, blue right
    tl.to(doorLeft,  { rotateY: -120, duration: 1.4, ease: 'power3.inOut' }, '-=0.15');
    tl.to(doorRight, { rotateY:  120, duration: 1.4, ease: 'power3.inOut' }, '<');

    // White flash overlay
    tl.add(function () {
      var flash = document.createElement('div');
      flash.style.cssText = 'position:fixed;inset:0;z-index:1005;background:#fff;opacity:0;pointer-events:none;';
      document.body.appendChild(flash);
      gsap.to(flash, { opacity: 0.6, duration: 0.15, yoyo: true, repeat: 1, onComplete: function () { flash.remove(); } });
    }, '-=0.5');

    // Fade doors away
    tl.to([doorLeft, doorRight], { opacity: 0, duration: 0.4 }, '-=0.3');

    // Reveal invitation
    tl.add(function () {
      invitation.classList.remove('hidden');
      spawnPetals(50);
      burstConfetti(window.innerWidth / 2, window.innerHeight / 2, 90);
      setTimeout(function () { starburst(window.innerWidth / 2, window.innerHeight / 2); }, 300);
      setTimeout(function () { starburst(window.innerWidth * 0.3, window.innerHeight * 0.4); }, 600);
      setTimeout(function () { starburst(window.innerWidth * 0.7, window.innerHeight * 0.4); }, 900);
    });

    // Invitation fade up
    tl.from(invitation, { opacity: 0, y: 40, duration: 1, ease: 'power2.out' });

    // Butterflies
    tl.add(function () { animateButterflies(); }, '-=0.5');

    // Scroll reveals
    tl.add(function () { initScrollReveals(); }, '-=0.3');
  }

  /* ----------------------------------------------------------
     6. BUTTERFLIES — flying + glowing trail
     ---------------------------------------------------------- */
  function animateButterflies() {
    var pink = document.getElementById('butterflyPink');
    var blue = document.getElementById('butterflyBlue');
    if (!pink || !blue) return;

    var cx = window.innerWidth  / 2;
    var cy = window.innerHeight / 2;

    [pink, blue].forEach(function (el, idx) {
      gsap.set(el, { x: cx - 30 + idx * 60, y: cy, opacity: 0, scale: 0.3 });

      // Pop in with bounce
      gsap.to(el, {
        opacity: 1, scale: 1,
        duration: 0.8, delay: idx * 0.35,
        ease: 'back.out(1.7)',
        onComplete: function () { wanderButterfly(el, idx); }
      });
    });
  }

  function wanderButterfly(el, seed) {
    var vw = window.innerWidth;
    var vh = window.innerHeight;
    var dur = 3.5 + Math.random() * 3.5;
    var tx = 50 + Math.random() * (vw - 140);
    var ty = 50 + Math.random() * (vh - 140);

    // Butterfly trail: spawn tiny glow dot
    spawnTrailDot(el, seed);

    gsap.to(el, {
      x: tx, y: ty,
      rotation: (Math.random() - 0.5) * 20,
      duration: dur,
      ease: 'sine.inOut',
      onComplete: function () { wanderButterfly(el, seed); }
    });
  }

  function spawnTrailDot(el, seed) {
    var rect = el.getBoundingClientRect();
    if (rect.width === 0) return;
    var dot = document.createElement('div');
    dot.style.cssText =
      'position:fixed;width:6px;height:6px;border-radius:50%;pointer-events:none;z-index:997;' +
      'left:' + (rect.left + rect.width / 2) + 'px;' +
      'top:' + (rect.top + rect.height / 2) + 'px;' +
      'background:' + (seed === 0 ? '#FF4081' : '#448AFF') + ';' +
      'box-shadow:0 0 8px ' + (seed === 0 ? '#FF4081' : '#448AFF') + ';';
    document.body.appendChild(dot);
    gsap.to(dot, {
      opacity: 0, scale: 0.2,
      duration: 1.2,
      ease: 'power2.out',
      onComplete: function () { if (dot.parentNode) dot.parentNode.removeChild(dot); }
    });

    // Schedule next trail dot
    setTimeout(function () { spawnTrailDot(el, seed); }, 250);
  }

  /* ----------------------------------------------------------
     7. SCRATCH CARD
     ---------------------------------------------------------- */
  function initScratchCard() {
    var canvas = document.getElementById('scratchCard');
    if (!canvas) return;
    var ctx = canvas.getContext('2d');
    var wrapper = canvas.parentElement;
    canvas.width  = wrapper.offsetWidth;
    canvas.height = wrapper.offsetHeight;

    // Vibrant gradient cover
    var grad = ctx.createLinearGradient(0, 0, canvas.width, canvas.height);
    grad.addColorStop(0, '#880E4F');
    grad.addColorStop(0.25, '#D81B60');
    grad.addColorStop(0.5, '#FFD700');
    grad.addColorStop(0.75, '#1565C0');
    grad.addColorStop(1, '#0D47A1');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Decorative circles
    ctx.strokeStyle = 'rgba(255,255,255,0.12)';
    ctx.lineWidth = 1;
    for (var i = 0; i < 25; i++) {
      ctx.beginPath();
      ctx.arc(
        Math.random() * canvas.width,
        Math.random() * canvas.height,
        15 + Math.random() * 45, 0, Math.PI * 2
      );
      ctx.stroke();
    }

    // Stars
    ctx.fillStyle = 'rgba(255,215,0,0.3)';
    for (var s = 0; s < 15; s++) {
      var sx = Math.random() * canvas.width;
      var sy = Math.random() * canvas.height;
      ctx.beginPath();
      for (var j = 0; j < 5; j++) {
        var a = (j * 4 * Math.PI / 5) - Math.PI / 2;
        var r = j % 2 === 0 ? 8 : 3;
        ctx.lineTo(sx + r * Math.cos(a), sy + r * Math.sin(a));
      }
      ctx.closePath();
      ctx.fill();
    }

    // Main text
    ctx.fillStyle = 'rgba(255,255,255,0.9)';
    ctx.font = 'bold 20px "Playfair Display", serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('✨ Scratch Here ✨', canvas.width / 2, canvas.height / 2);

    // Sub text
    ctx.fillStyle = 'rgba(255,255,255,0.5)';
    ctx.font = '13px "Cormorant Garamond", serif';
    ctx.fillText('Reveal the Auspicious Date', canvas.width / 2, canvas.height / 2 + 26);

    // Scratch
    var isDown = false;
    var revealed = false;

    function getPos(e) {
      var rect = canvas.getBoundingClientRect();
      var cx = e.touches ? e.touches[0].clientX : e.clientX;
      var cy = e.touches ? e.touches[0].clientY : e.clientY;
      return { x: cx - rect.left, y: cy - rect.top };
    }

    function scratch(pos) {
      ctx.globalCompositeOperation = 'destination-out';
      ctx.beginPath();
      ctx.arc(pos.x, pos.y, 24, 0, Math.PI * 2);
      ctx.fill();
      playTinkle();
      checkReveal();
    }

    function checkReveal() {
      if (revealed) return;
      var data = ctx.getImageData(0, 0, canvas.width, canvas.height).data;
      var total = data.length / 4;
      var clear = 0;
      for (var i = 3; i < data.length; i += 4) { if (data[i] === 0) clear++; }
      if (clear / total > 0.42) {
        revealed = true;
        gsap.to(canvas, { opacity: 0, duration: 0.5 });
        playRevealSound();
        var sr = document.getElementById('scratchReveal');
        if (sr) {
          var r = sr.getBoundingClientRect();
          burstConfetti(r.left + r.width / 2, r.top + r.height / 2, 60);
          starburst(r.left + r.width / 2, r.top + r.height / 2);
        }
      }
    }

    canvas.addEventListener('mousedown',  function (e) { isDown = true; scratch(getPos(e)); });
    canvas.addEventListener('mousemove',  function (e) { if (isDown) scratch(getPos(e)); });
    canvas.addEventListener('mouseup',    function ()  { isDown = false; });
    canvas.addEventListener('mouseleave', function ()  { isDown = false; });
    canvas.addEventListener('touchstart', function (e) { e.preventDefault(); isDown = true; scratch(getPos(e)); }, { passive: false });
    canvas.addEventListener('touchmove',  function (e) { e.preventDefault(); if (isDown) scratch(getPos(e)); }, { passive: false });
    canvas.addEventListener('touchend',   function ()  { isDown = false; });
  }

  /* ----------------------------------------------------------
     8. SCROLL REVEALS
     ---------------------------------------------------------- */
  function initScrollReveals() {
    gsap.registerPlugin(ScrollTrigger);

    // Family cards — alternating slide
    gsap.utils.toArray('.family-card').forEach(function (card, i) {
      var fromX = i === 0 ? -60 : 60;
      gsap.from(card, {
        scrollTrigger: { trigger: card, start: 'top 85%', toggleActions: 'play none none none' },
        opacity: 0, x: fromX, y: 30, duration: 0.8, delay: i * 0.25, ease: 'power3.out'
      });
    });

    // Heart pop
    gsap.from('.heart-circle', {
      scrollTrigger: { trigger: '.heart-circle', start: 'top 85%' },
      opacity: 0, scale: 0, duration: 0.6, delay: 0.5, ease: 'back.out(2)'
    });

    // Event cards — stagger with colored flash
    gsap.utils.toArray('.event-card').forEach(function (card, i) {
      gsap.to(card, {
        scrollTrigger: { trigger: card, start: 'top 85%', toggleActions: 'play none none none' },
        opacity: 1, y: 0, duration: 0.8, delay: i * 0.12, ease: 'power3.out',
        onStart: function () {
          playSoftBell();
          // Mini confetti on first appearance
          var r = card.getBoundingClientRect();
          burstConfetti(r.left + r.width / 2, r.top + 30, 12);
        }
      });
    });

    // Section headings — scale up
    gsap.utils.toArray('.section-heading').forEach(function (h) {
      gsap.from(h, {
        scrollTrigger: { trigger: h, start: 'top 88%' },
        opacity: 0, scale: 0.8, y: 20, duration: 0.7, ease: 'back.out(1.4)'
      });
    });

    // Footer
    gsap.from('.footer-quote', {
      scrollTrigger: { trigger: '.footer-quote', start: 'top 88%' },
      opacity: 0, y: 25, duration: 0.8
    });
    gsap.from('.couple-mono', {
      scrollTrigger: { trigger: '.couple-mono', start: 'top 88%' },
      opacity: 0, scale: 0.3, duration: 1, ease: 'back.out(1.7)'
    });
    gsap.from('.rangoli-decoration', {
      scrollTrigger: { trigger: '.rangoli-decoration', start: 'top 90%' },
      opacity: 0, y: 15, duration: 0.6
    });

    // Scratch card init when visible
    ScrollTrigger.create({
      trigger: '.scratch-section',
      start: 'top 80%',
      once: true,
      onEnter: function () { initScratchCard(); }
    });
  }

  /* ----------------------------------------------------------
     9. MUSIC TOGGLE
     ---------------------------------------------------------- */
  function initMusicToggle() {
    var btn = document.getElementById('musicToggle');
    if (!btn) return;
    btn.addEventListener('click', function () {
      if (musicPlaying) {
        stopAmbientMusic();
        btn.classList.remove('playing');
        btn.textContent = '🔇';
      } else {
        startAmbientMusic();
        btn.classList.add('playing');
        btn.textContent = '🎵';
      }
    });
  }

  /* ----------------------------------------------------------
     10. INIT
     ---------------------------------------------------------- */
  function init() {
    document.body.style.overflow = 'hidden';

    // Background effects
    createParticles(70);
    createSparkles(45);

    // Tap to open
    var tap = document.getElementById('tapToOpen');
    if (tap) {
      tap.addEventListener('click', function handler() {
        tap.removeEventListener('click', handler);
        openCard();
      });
    }

    initMusicToggle();

    // Cover entrance animations
    gsap.from('.ganesh-text',    { opacity: 0, y: -25, duration: 0.9, delay: 0.2 });
    gsap.from('.cover-mandala',  { opacity: 0, scale: 0.3, rotation: -90, duration: 1.2, delay: 0.4, ease: 'back.out(1.7)' });
    gsap.from('.name-bride',     { opacity: 0, x: -40, duration: 0.8, delay: 0.8, ease: 'power3.out' });
    gsap.from('.name-groom',     { opacity: 0, x:  40, duration: 0.8, delay: 0.8, ease: 'power3.out' });
    gsap.from('.amp',            { opacity: 0, scale: 0, duration: 0.5, delay: 1.1, ease: 'back.out(2)' });
    gsap.from('.cover-tagline',  { opacity: 0, y: 15, duration: 0.6, delay: 1.3 });
    gsap.from('.tap-to-open',    { opacity: 0, scale: 0.4, duration: 0.9, delay: 1.6, ease: 'elastic.out(1, 0.4)' });

    // Diyas entrance
    gsap.from('.diya1', { opacity: 0, y: -30, duration: 0.7, delay: 0.5 });
    gsap.from('.diya2', { opacity: 0, y: -30, duration: 0.7, delay: 0.7 });

    // Corner ornaments — stagger pop
    gsap.utils.toArray('.corner-ornament').forEach(function (el, i) {
      gsap.from(el, { opacity: 0, scale: 0, rotation: 180, duration: 0.6, delay: 0.3 + i * 0.15, ease: 'back.out(2.5)' });
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
