/* ============================================================
   "CELESTIAL LOVE" — Animation Engine
   Starfield · Typewriter · Cinematic Open · Countdown ·
   Scratch Card · Timeline · Shooting Stars · Sound Design
   ============================================================ */

(function () {
  'use strict';

  /* ========================================================
     0. AUDIO ENGINE
     ======================================================== */
  let audioCtx = null;
  function ac() {
    if (!audioCtx) audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    return audioCtx;
  }

  function tone(freq, dur, type, vol) {
    try {
      var c = ac(), o = c.createOscillator(), g = c.createGain();
      o.connect(g); g.connect(c.destination);
      o.type = type || 'sine'; o.frequency.value = freq;
      g.gain.setValueAtTime(vol || 0.1, c.currentTime);
      g.gain.exponentialRampToValueAtTime(0.001, c.currentTime + dur);
      o.start(); o.stop(c.currentTime + dur);
    } catch (_) {}
  }

  // Ethereal open chord
  function playOpenSound() {
    var notes = [261.63, 329.63, 392.00, 523.25, 659.25, 783.99];
    notes.forEach(function (f, i) {
      setTimeout(function () { tone(f, 2.5, 'sine', 0.06); }, i * 130);
    });
  }

  // Gentle key tap
  function playKeyTap() { tone(1400 + Math.random() * 600, 0.12, 'sine', 0.03); }

  // Soft bell
  function playSoftBell() { tone(1174.66, 0.6, 'sine', 0.04); }

  // Reveal sparkle
  function playSparkle() {
    [1318.51, 1567.98, 2093.00].forEach(function (f, i) {
      setTimeout(function () { tone(f, 0.6, 'triangle', 0.05); }, i * 90);
    });
  }

  // Scratch tinkle
  function playTinkle() { tone(2200 + Math.random() * 800, 0.15, 'sine', 0.02); }

  // Ambient pad
  var ambientNodes = [], musicPlaying = false;
  function startMusic() {
    if (musicPlaying) return;
    try {
      var c = ac();
      var chords = [130.81, 196.00, 261.63, 329.63, 392.00];
      chords.forEach(function (f, i) {
        var o = c.createOscillator(), g = c.createGain();
        var lfo = c.createOscillator(), lg = c.createGain();
        o.type = i < 2 ? 'sine' : 'triangle';
        o.frequency.value = f;
        lfo.type = 'sine'; lfo.frequency.value = 0.08 + i * 0.03;
        lg.gain.value = 0.02;
        lfo.connect(lg); lg.connect(g.gain);
        o.connect(g); g.connect(c.destination);
        g.gain.value = 0.018;
        o.start(); lfo.start();
        ambientNodes.push({ o: o, l: lfo, g: g });
      });
      musicPlaying = true;
    } catch (_) {}
  }
  function stopMusic() {
    ambientNodes.forEach(function (n) { try { n.o.stop(); n.l.stop(); } catch (_) {} });
    ambientNodes = []; musicPlaying = false;
  }

  /* ========================================================
     1. STARFIELD — Canvas Rendering
     ======================================================== */
  var stars = [];
  var starCanvas, starCtx;

  function initStarfield() {
    starCanvas = document.getElementById('starfield');
    if (!starCanvas) return;
    starCtx = starCanvas.getContext('2d');
    resizeStarfield();
    window.addEventListener('resize', resizeStarfield);

    // Create stars
    for (var i = 0; i < 220; i++) {
      stars.push({
        x: Math.random() * starCanvas.width,
        y: Math.random() * starCanvas.height,
        r: 0.3 + Math.random() * 1.5,
        a: Math.random(),           // current alpha
        speed: 0.002 + Math.random() * 0.008,
        phase: Math.random() * Math.PI * 2,
        color: i % 5 === 0 ? '#F5E6A3' : (i % 7 === 0 ? '#E8D5B7' : '#ffffff')
      });
    }

    animateStars();
  }

  function resizeStarfield() {
    if (!starCanvas) return;
    starCanvas.width  = window.innerWidth;
    starCanvas.height = window.innerHeight;
  }

  function animateStars() {
    if (!starCtx) return;
    starCtx.clearRect(0, 0, starCanvas.width, starCanvas.height);

    var t = Date.now() * 0.001;
    for (var i = 0; i < stars.length; i++) {
      var s = stars[i];
      s.a = 0.3 + 0.7 * ((Math.sin(t * s.speed * 100 + s.phase) + 1) / 2);

      starCtx.beginPath();
      starCtx.arc(s.x, s.y, s.r, 0, Math.PI * 2);
      starCtx.fillStyle = s.color;
      starCtx.globalAlpha = s.a;
      starCtx.fill();

      // Glow for larger stars
      if (s.r > 1) {
        starCtx.beginPath();
        starCtx.arc(s.x, s.y, s.r * 3, 0, Math.PI * 2);
        starCtx.fillStyle = s.color;
        starCtx.globalAlpha = s.a * 0.08;
        starCtx.fill();
      }
    }
    starCtx.globalAlpha = 1;
    requestAnimationFrame(animateStars);
  }

  /* ========================================================
     2. SHOOTING STARS
     ======================================================== */
  function spawnShootingStar() {
    var container = document.getElementById('shooting-stars');
    if (!container) return;

    var el = document.createElement('div');
    el.className = 'shooting-star';
    el.style.top  = (Math.random() * 50) + '%';
    el.style.left = (Math.random() * 80) + '%';
    el.style.width = (60 + Math.random() * 60) + 'px';
    container.appendChild(el);

    gsap.to(el, {
      x: -300, y: 200, opacity: 1, duration: 0.6,
      ease: 'power2.in',
      onComplete: function () {
        gsap.to(el, { opacity: 0, duration: 0.3, onComplete: function () { el.remove(); } });
      }
    });

    // Next one
    setTimeout(spawnShootingStar, 3000 + Math.random() * 6000);
  }

  /* ========================================================
     3. TYPEWRITER — Letter by letter name reveal
     ======================================================== */
  function typewriterName(containerId, text, delay, onDone) {
    var el = document.getElementById(containerId);
    if (!el) return;
    el.innerHTML = '';
    var letters = text.split('');
    letters.forEach(function (ch, i) {
      var span = document.createElement('span');
      span.className = 'letter';
      span.textContent = ch === ' ' ? '\u00A0' : ch;
      el.appendChild(span);
    });

    // Animate each letter
    var spans = el.querySelectorAll('.letter');
    spans.forEach(function (s, i) {
      gsap.to(s, {
        opacity: 1, y: 0,
        duration: 0.4,
        delay: delay + i * 0.08,
        ease: 'back.out(1.5)',
        onStart: function () { playKeyTap(); }
      });
    });

    // Callback after all letters
    if (onDone) {
      setTimeout(onDone, (delay + letters.length * 0.08 + 0.4) * 1000);
    }
  }

  /* ========================================================
     4. GOLD BURST & CONFETTI
     ======================================================== */
  function goldBurst(cx, cy, count) {
    for (var i = 0; i < (count || 30); i++) {
      var d = document.createElement('div');
      d.className = 'gold-burst';
      d.style.left = cx + 'px';
      d.style.top  = cy + 'px';
      var size = 2 + Math.random() * 4;
      d.style.width = size + 'px';
      d.style.height = size + 'px';
      document.body.appendChild(d);

      var angle = Math.random() * Math.PI * 2;
      var dist  = 80 + Math.random() * 160;
      gsap.to(d, {
        x: Math.cos(angle) * dist,
        y: Math.sin(angle) * dist,
        opacity: 0,
        duration: 1 + Math.random() * 0.8,
        ease: 'power2.out',
        onComplete: function () { d.remove(); }
      });
    }
  }

  function confetti(cx, cy, count) {
    var colors = ['#D4AF37', '#F5E6A3', '#FFFFFF', '#E8D5B7', '#FFFACD'];
    for (var i = 0; i < (count || 50); i++) {
      var c = document.createElement('div');
      c.className = 'confetti-particle';
      c.style.left = cx + 'px';
      c.style.top  = cy + 'px';
      var s = 3 + Math.random() * 5;
      c.style.width  = s + 'px';
      c.style.height = s + 'px';
      c.style.background = colors[Math.floor(Math.random() * colors.length)];
      c.style.borderRadius = Math.random() > 0.5 ? '50%' : '1px';
      document.body.appendChild(c);

      gsap.to(c, {
        x: (Math.random() - 0.5) * 400,
        y: (Math.random() - 0.5) * 400,
        rotation: Math.random() * 720,
        opacity: 0,
        duration: 1.2 + Math.random() * 1.2,
        ease: 'power2.out',
        onComplete: function () { c.remove(); }
      });
    }
  }

  /* ========================================================
     5. INTRO ANIMATIONS
     ======================================================== */
  function animateIntro() {
    var tl = gsap.timeline();

    // SVG frame draw
    tl.to('.geo-frame', { opacity: 1, duration: 0 });
    tl.to('.frame-outer', { strokeDashoffset: 0, duration: 2.5, ease: 'power1.inOut' }, 0);
    tl.to('.frame-inner', { strokeDashoffset: 0, duration: 2.8, ease: 'power1.inOut' }, 0.3);

    // Subtitle
    tl.to('#introSub', { opacity: 1, duration: 0.8 }, 0.8);

    // Typewriter names
    tl.add(function () {
      typewriterName('name1', 'Ananya', 0);
    }, 1.4);

    tl.to('#nameAmp', { opacity: 1, scale: 1, duration: 0.6, ease: 'back.out(1.7)' }, 2.6);
    tl.set('#nameAmp', { scale: 0 }, 0); // start hidden

    tl.add(function () {
      typewriterName('name2', 'Vivaan', 0);
    }, 2.9);

    // Date preview
    tl.to('#introDate', { opacity: 1, y: 0, duration: 0.6 }, 4.0);
    tl.set('#introDate', { y: 15 }, 0);

    // Enter button circle draw + reveal
    tl.add(function () {
      document.getElementById('enterBtn').classList.add('loaded');
    }, 4.5);

    // Corner lines
    tl.from('.frame-corner-tl, .frame-corner-tr, .frame-corner-bl, .frame-corner-br', {
      opacity: 0, duration: 0.4, stagger: 0.1
    }, 1.5);
  }

  /* ========================================================
     6. CARD OPEN — Transition to Main Content
     ======================================================== */
  function openCard() {
    var intro     = document.getElementById('intro');
    var hero      = document.getElementById('hero');
    var cdSection = document.getElementById('countdown-section');
    var evSection = document.getElementById('events-section');
    var closing   = document.getElementById('closing');
    var musicBtn  = document.getElementById('musicBtn');
    var navDots   = document.getElementById('navDots');

    playOpenSound();

    var cx = window.innerWidth / 2;
    var cy = window.innerHeight / 2;

    var tl = gsap.timeline({
      onComplete: function () {
        intro.style.display = 'none';
        document.body.style.overflow = '';
        // Show all pages
        [hero, cdSection, evSection, closing, musicBtn, navDots].forEach(function (el) {
          el.classList.remove('hidden-page');
        });
        startMusic();
        musicBtn.classList.add('playing');
        animateHero();
        initCountdown();
        initScrollReveals();
        spawnShootingStar();
      }
    });

    // Flash & zoom
    tl.to('.intro-content', { opacity: 0, scale: 1.1, duration: 0.6, ease: 'power3.in' });
    tl.to('.geo-frame',     { opacity: 0, scale: 1.2, duration: 0.6, ease: 'power3.in' }, '<');

    // White gold flash
    tl.add(function () { goldBurst(cx, cy, 50); });

    // Fade intro away
    tl.to(intro, { opacity: 0, duration: 0.4 });

    // Confetti
    tl.add(function () { confetti(cx, cy, 60); }, '-=0.2');
  }

  /* ========================================================
     7. HERO SECTION ANIMATIONS
     ======================================================== */
  function animateHero() {
    var tl = gsap.timeline({ delay: 0.3 });

    tl.to('.hero-monogram', { opacity: 1, scale: 1, rotation: 0, duration: 1, ease: 'back.out(1.4)' });
    tl.set('.hero-monogram', { scale: 0.5, rotation: -30 }, 0);

    tl.to('.hero-label', { opacity: 1, y: 0, duration: 0.6 }, 0.5);
    tl.set('.hero-label', { y: 15 }, 0);

    tl.to('.hero-bride', { opacity: 1, x: 0, duration: 0.7, ease: 'power3.out' }, 0.8);
    tl.set('.hero-bride', { x: -40 }, 0);

    tl.to('.hero-divider', { opacity: 1, duration: 0.5 }, 1.1);

    tl.to('.hero-groom', { opacity: 1, x: 0, duration: 0.7, ease: 'power3.out' }, 1.2);
    tl.set('.hero-groom', { x: 40 }, 0);

    tl.to('.hero-invite', { opacity: 1, y: 0, duration: 0.6 }, 1.6);
    tl.set('.hero-invite', { y: 15 }, 0);

    tl.to('.hero-date-strip', { opacity: 1, y: 0, duration: 0.7 }, 1.9);
    tl.set('.hero-date-strip', { y: 20 }, 0);

    tl.to('.scroll-indicator', { opacity: 1, duration: 0.5 }, 2.5);
  }

  /* ========================================================
     8. COUNTDOWN TIMER
     ======================================================== */
  function initCountdown() {
    var target = new Date('December 20, 2026 09:00:00').getTime();

    function update() {
      var now  = Date.now();
      var diff = Math.max(0, target - now);
      var d = Math.floor(diff / 86400000);
      var h = Math.floor((diff % 86400000) / 3600000);
      var m = Math.floor((diff % 3600000) / 60000);
      var s = Math.floor((diff % 60000) / 1000);

      var dEl = document.getElementById('cdDays');
      var hEl = document.getElementById('cdHours');
      var mEl = document.getElementById('cdMins');
      var sEl = document.getElementById('cdSecs');
      if (dEl) dEl.textContent = String(d).padStart(3, '0');
      if (hEl) hEl.textContent = String(h).padStart(2, '0');
      if (mEl) mEl.textContent = String(m).padStart(2, '0');
      if (sEl) {
        var prev = sEl.textContent;
        var next = String(s).padStart(2, '0');
        if (prev !== next) {
          sEl.textContent = next;
          gsap.from(sEl, { y: -8, opacity: 0.4, duration: 0.3, ease: 'power2.out' });
        }
      }
    }

    update();
    setInterval(update, 1000);
  }

  /* ========================================================
     9. SCRATCH CARD — Holographic Effect
     ======================================================== */
  function initScratchCard() {
    var canvas = document.getElementById('scratchCard');
    if (!canvas || canvas._inited) return;
    canvas._inited = true;
    var ctx = canvas.getContext('2d');
    var wrapper = canvas.parentElement;
    canvas.width  = wrapper.offsetWidth;
    canvas.height = wrapper.offsetHeight;

    // Holographic gradient
    var grad = ctx.createLinearGradient(0, 0, canvas.width, canvas.height);
    grad.addColorStop(0,   '#1a1a2e');
    grad.addColorStop(0.2, '#2d2d44');
    grad.addColorStop(0.4, '#D4AF37');
    grad.addColorStop(0.5, '#F5E6A3');
    grad.addColorStop(0.6, '#D4AF37');
    grad.addColorStop(0.8, '#2d2d44');
    grad.addColorStop(1,   '#1a1a2e');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Subtle pattern
    ctx.strokeStyle = 'rgba(255,255,255,0.06)';
    ctx.lineWidth = 0.5;
    for (var i = 0; i < 30; i++) {
      ctx.beginPath();
      ctx.arc(Math.random() * canvas.width, Math.random() * canvas.height, 10 + Math.random() * 30, 0, Math.PI * 2);
      ctx.stroke();
    }

    // Text
    ctx.fillStyle = 'rgba(255,250,205,0.7)';
    ctx.font = '500 14px Montserrat, sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('✦  Scratch to Reveal  ✦', canvas.width / 2, canvas.height / 2);

    var isDown = false, revealed = false;

    function pos(e) {
      var r = canvas.getBoundingClientRect();
      var cx = e.touches ? e.touches[0].clientX : e.clientX;
      var cy = e.touches ? e.touches[0].clientY : e.clientY;
      return { x: cx - r.left, y: cy - r.top };
    }

    function scratch(p) {
      ctx.globalCompositeOperation = 'destination-out';
      ctx.beginPath();
      ctx.arc(p.x, p.y, 20, 0, Math.PI * 2);
      ctx.fill();
      playTinkle();
      check();
    }

    function check() {
      if (revealed) return;
      var d = ctx.getImageData(0, 0, canvas.width, canvas.height).data;
      var total = d.length / 4, clear = 0;
      for (var i = 3; i < d.length; i += 4) { if (d[i] === 0) clear++; }
      if (clear / total > 0.40) {
        revealed = true;
        gsap.to(canvas, { opacity: 0, duration: 0.5 });
        playSparkle();
        var sr = document.getElementById('scratchReveal');
        if (sr) {
          var r = sr.getBoundingClientRect();
          goldBurst(r.left + r.width / 2, r.top + r.height / 2, 40);
        }
      }
    }

    canvas.addEventListener('mousedown',  function (e) { isDown = true; scratch(pos(e)); });
    canvas.addEventListener('mousemove',  function (e) { if (isDown) scratch(pos(e)); });
    canvas.addEventListener('mouseup',    function ()  { isDown = false; });
    canvas.addEventListener('mouseleave', function ()  { isDown = false; });
    canvas.addEventListener('touchstart', function (e) { e.preventDefault(); isDown = true; scratch(pos(e)); }, { passive: false });
    canvas.addEventListener('touchmove',  function (e) { e.preventDefault(); if (isDown) scratch(pos(e)); }, { passive: false });
    canvas.addEventListener('touchend',   function ()  { isDown = false; });
  }

  /* ========================================================
     10. SCROLL REVEALS
     ======================================================== */
  function initScrollReveals() {
    gsap.registerPlugin(ScrollTrigger);

    // Countdown section entrance
    gsap.from('#countdown-section .section-label', {
      scrollTrigger: { trigger: '#countdown-section', start: 'top 80%' },
      opacity: 0, y: 15, duration: 0.6
    });
    gsap.from('#countdown-section .section-title', {
      scrollTrigger: { trigger: '#countdown-section', start: 'top 80%' },
      opacity: 0, y: 20, duration: 0.7, delay: 0.15
    });
    gsap.from('.countdown-row', {
      scrollTrigger: { trigger: '.countdown-row', start: 'top 85%' },
      opacity: 0, y: 30, duration: 0.8, delay: 0.3
    });

    // Scratch card
    ScrollTrigger.create({
      trigger: '.scratch-container',
      start: 'top 80%',
      once: true,
      onEnter: function () {
        gsap.from('.scratch-container', { opacity: 0, y: 20, duration: 0.6 });
        initScratchCard();
      }
    });

    // Events section
    gsap.from('#events-section .section-label', {
      scrollTrigger: { trigger: '#events-section', start: 'top 80%' },
      opacity: 0, y: 15, duration: 0.6
    });
    gsap.from('#events-section .section-title', {
      scrollTrigger: { trigger: '#events-section', start: 'top 80%' },
      opacity: 0, y: 20, duration: 0.7, delay: 0.15
    });

    // Timeline cards
    gsap.utils.toArray('.tl-item').forEach(function (item, i) {
      var isLeft = item.classList.contains('tl-left');
      gsap.to(item, {
        scrollTrigger: { trigger: item, start: 'top 85%', toggleActions: 'play none none none' },
        opacity: 1, y: 0, x: 0, duration: 0.8, delay: i * 0.08, ease: 'power3.out',
        onStart: function () { playSoftBell(); }
      });
      gsap.set(item, { x: isLeft ? -30 : 30 });

      // Dot pop
      var dot = item.querySelector('.tl-dot');
      gsap.from(dot, {
        scrollTrigger: { trigger: item, start: 'top 85%' },
        scale: 0, duration: 0.5, delay: i * 0.08 + 0.2, ease: 'back.out(2)'
      });
    });

    // Closing
    gsap.from('.closing-quote', {
      scrollTrigger: { trigger: '.closing-quote', start: 'top 85%' },
      opacity: 0, y: 20, duration: 0.8
    });
    gsap.from('.closing-monogram', {
      scrollTrigger: { trigger: '.closing-monogram', start: 'top 85%' },
      opacity: 0, scale: 0.5, duration: 1, ease: 'back.out(1.7)'
    });
    gsap.from('.closing-message', {
      scrollTrigger: { trigger: '.closing-message', start: 'top 88%' },
      opacity: 0, y: 15, duration: 0.7
    });
    gsap.from('.closing-hashtag', {
      scrollTrigger: { trigger: '.closing-hashtag', start: 'top 88%' },
      opacity: 0, y: 10, duration: 0.6
    });

    // Nav dots — active state on scroll
    var sections = ['hero', 'countdown-section', 'events-section', 'closing'];
    sections.forEach(function (id, i) {
      ScrollTrigger.create({
        trigger: '#' + id,
        start: 'top center',
        end: 'bottom center',
        onEnter: function () { setActiveDot(i); },
        onEnterBack: function () { setActiveDot(i); }
      });
    });

    // Hide scroll hint on scroll
    ScrollTrigger.create({
      trigger: '#countdown-section',
      start: 'top 90%',
      once: true,
      onEnter: function () {
        gsap.to('.scroll-indicator', { opacity: 0, duration: 0.4 });
      }
    });
  }

  function setActiveDot(idx) {
    document.querySelectorAll('.dot').forEach(function (d, i) {
      d.classList.toggle('active', i === idx);
    });
  }

  /* ========================================================
     11. NAV DOTS — Click to scroll
     ======================================================== */
  function initNavDots() {
    document.querySelectorAll('.dot').forEach(function (d) {
      d.addEventListener('click', function () {
        var target = document.getElementById(d.dataset.target);
        if (target) target.scrollIntoView({ behavior: 'smooth' });
      });
    });
  }

  /* ========================================================
     12. MUSIC TOGGLE
     ======================================================== */
  function initMusicToggle() {
    var btn = document.getElementById('musicBtn');
    if (!btn) return;
    btn.addEventListener('click', function () {
      if (musicPlaying) {
        stopMusic();
        btn.classList.remove('playing');
      } else {
        startMusic();
        btn.classList.add('playing');
      }
    });
  }

  /* ========================================================
     13. INIT
     ======================================================== */
  function init() {
    document.body.style.overflow = 'hidden';

    initStarfield();
    initNavDots();
    initMusicToggle();

    // Run intro
    setTimeout(animateIntro, 300);

    // Enter button
    var enterBtn = document.getElementById('enterBtn');
    if (enterBtn) {
      enterBtn.addEventListener('click', function handler() {
        enterBtn.removeEventListener('click', handler);
        openCard();
      });
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
